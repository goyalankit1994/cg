package comm.cg.collection;

import java.util.Iterator;
import java.util.TreeSet;


public class TreeStudent {

	public static void main(String[] args) {
		TreeSet<Student> t = new TreeSet<Student>();
	   t.add(new Student(10,"kishan"));
	   t.add(new Student(3,"ankit"));
	   t.add(new Student(9,"yuvraj"));
	   Iterator keyref = t.iterator();
	while(keyref.hasNext())
		{
			System.out.println(keyref.next());
		}
	}

}
