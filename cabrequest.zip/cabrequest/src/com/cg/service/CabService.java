package com.cg.service;


import com.cg.bean.CabRequest;
import com.cg.exception.CabException;


public interface CabService {
	public CabRequest addCabRequestDetails(CabRequest cabRequest) throws CabException;
	public CabRequest getRequestDetails(int requestId) throws CabException;
	public int getRequestId(CabRequest cabs) throws CabException ; 
	

}
