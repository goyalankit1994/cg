package lab8;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class ReadFromFile {
	static Scanner input;

	public static void main(String[] args) {
		try {
			input = new Scanner(new FileReader("numbers.txt")).useDelimiter(",");
			while (input.hasNext())
			{
				int x = input.nextInt();
				if(x%2==0)
				{
				System.out.print(x);
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		}
	}
}
