package comm.cg.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class SortClient {

	public static void main(String[] args) {
	TreeSet<Employee> set = new TreeSet<Employee>(new SortEmp());    //genric is mandatory
//	set.add(new Employee(104,"Riya"));       //for employee class
//	set.add(new Employee(101,"Ram"));
//	set.add(new Employee(105,"Siya"));
//	System.out.println(set);
//	set.add(new WageEmp(104,"Riya",1,22));    // for WAGE emp class
//	set.add(new WageEmp(101,"Ram",20,2));
//	set.add(new WageEmp(105,"Siya",15,3));
//	System.out.println(set);
Hashtable<Integer,String> t = new Hashtable<Integer,String>();
t.put(10,"ankit");
t.put(5, "honey");
t.put(15, "dubey");
ArrayList<Integer> list = Collections.list(t.keys());
Collections.sort(list);
Iterator it = list.iterator();
	while(it.hasNext())
		{
		Integer i =(Integer)it.next();
		System.out.print(i+" = ");
		System.out.print(t.get(i));
		System.out.println();
		
		}
	
	}

}
