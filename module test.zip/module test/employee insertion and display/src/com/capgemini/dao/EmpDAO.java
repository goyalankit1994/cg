package com.capgemini.dao;

import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;

public interface EmpDAO {

	boolean saveEmp(Emp emp);

	Emp getEmp() throws EmpException;

}
