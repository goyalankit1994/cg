package com.cg.eis.service;

import java.util.Map;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	Map<Integer, Employee> addEmployee(Employee emp);

	boolean printEmployeeBasedOnInsuranceScheme(Map<Integer, Employee> empMap,
			String insuranceScheme);

	Map<Integer, Employee> deleteEmployee(int id, Map<Integer, Employee> empMap);

	void sortEmployeeOnSalary(Map<Integer, Employee> empMap);

}



