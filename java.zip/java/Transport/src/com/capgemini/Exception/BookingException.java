package com.capgemini.Exception;

	public class BookingException extends Exception {
		String message;
		public BookingException(String message)
		{
			this.message=message;
		}
		@Override
		public String getMessage() {
			// TODO Auto-generated method stub
			return message;
		}
	}
		

