package com.cg.DthRecharge.pl;


import java.util.Scanner;

import com.cg.DthRecharge.Exception.DthException;
import com.cg.DthRecharge.Service.DthService;
import com.cg.DthRecharge.Service.DthServiceImpl;
import com.cg.DthRecharge.dto.DthRechargeBean;


public class Client {
	static DthService service = new DthServiceImpl();

	public static void main(String[] args) {
		int choice = 0;
		try (Scanner sc = new Scanner(System.in)) {
			do {
				System.out.println("1-get record by id");
				System.out.println("2-RECHARGE");
				System.out.println("enter your choice");
				choice = sc.nextInt();
				switch (choice) {
				case 1:
					System.out.println("enter dth id");
					int id = sc.nextInt();
					try {
						DthRechargeBean record = service.getRecord(id);
						System.out.println(record);
					} catch (DthException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					break;
				case 2:
				try
				{
					
					service.Recharge();
					System.out.println("recharge sucessful");
				}
				catch(DthException e)
				{
					System.out.println(e.getMessage());
				}
					break;
				}
			} while (choice != 0);
		}
	}

}

