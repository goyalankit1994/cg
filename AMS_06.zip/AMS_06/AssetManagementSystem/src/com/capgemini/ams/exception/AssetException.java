package com.capgemini.ams.exception;

public class AssetException extends Exception{

	private String message;

	public AssetException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
