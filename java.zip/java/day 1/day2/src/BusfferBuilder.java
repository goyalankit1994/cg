
public class BusfferBuilder {

	public static void main(String[] args) {
 StringBuffer ref = new StringBuffer("hello");
 System.out.println("before ref = "+ref);
 ref.append("world");
 System.out.println("after ref="+ref);
 ref.reverse();
 System.out.println("ref after revrse =" +ref);
 

	}

}
