package lab9;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class Person {
	String firstName;
	 String lastName;
	 char gender;
	public Person() {
		firstName = "Ankit";
		lastName = "Goyal";
		gender = 'M';
	
	}
	public Person(String firstName, String lastName) {

		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + "]";
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}

	
}