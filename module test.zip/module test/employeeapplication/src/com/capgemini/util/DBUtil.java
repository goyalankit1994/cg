package com.capgemini.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.exception.EmpException;

public class DBUtil {

	static Connection conn;
	static Logger logger = Logger.getLogger(DBUtil.class);

	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			logger.error( Messages.CLASS_NOT_FOUND_ERROR + e);
			System.out.println( Messages.CLASS_NOT_FOUND_ERROR);
		}
	}
	
	/**
	 * This create an connection to database and returns it
	 * @return connecton to databse
	 * @throws EmpException
	 */

	public static Connection getConnection() throws EmpException {
		try {
			if (conn == null || conn.isClosed()) {
				conn = DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
				logger.info("Connection Established");
			}
		} catch (SQLException e) {
			logger.error(Messages.DB_CONN_ERROR + e);
			throw new EmpException(Messages.DB_CONN_ERROR);
		}
		return conn;
	}
}
