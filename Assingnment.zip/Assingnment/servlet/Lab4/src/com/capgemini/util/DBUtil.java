package com.capgemini.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {

	static DataSource dataSource;
	
	public static DataSource getDataSource() {
		if (dataSource == null){
			try {
				InitialContext context = new InitialContext();
				dataSource = (DataSource) context.lookup("java:/OracleDS");
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return dataSource;
	}

}
