package comm.cg.interfaces;

public class Serivceimpl implements Service { //more than 1 interface can be implemented by putting ,
	                                                                   //and another sequence name
@Override
	public int add(int x, int y) {
		// TODO Auto-generated method stub
		return x+y;
	}

	@Override
	public int sub(int x, int y) {
		// TODO Auto-generated method stub
		return x-y;
	}
	public int multiply(int x, int y)
	{
		return x*y;
	}
public static int showVar()
{
	//Service.var=88;
	return Service.var;
}
}
