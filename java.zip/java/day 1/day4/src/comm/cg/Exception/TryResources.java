package comm.cg.Exception;

import java.util.Scanner;

public class TryResources {

	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in))
		
		{
			System.out.println("enter string");
		String str = sc.next();
		System.out.println(str);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}

}
