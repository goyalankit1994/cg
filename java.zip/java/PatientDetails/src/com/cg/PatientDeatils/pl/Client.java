package com.cg.PatientDeatils.pl;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.PatientDetails.Exception.PatientException;
import com.cg.PatientDetails.Service.PatientService;
import com.cg.PatientDetails.Service.PatientServiceImpl;
import com.cg.PatientDetails.dto.PatientBean;

public class Client {
	static PatientService service = new PatientServiceImpl();

	public static void main(String[] args) 
	{
		int choice = 0;
		try (Scanner sc = new Scanner(System.in)) {
			do {
				System.out.println("1-insert");
				System.out.println("2-get record by id");
				System.out.println("3-get all record");
				System.out.println("enter your choice");
				choice = sc.nextInt();
				switch (choice) {
				case 1:
					System.out.println("enter name::");
					String name = sc.next();
					System.out.println("enter address");
					String address = sc.next();
					System.out.println("enter phonenumber");
					String phone = sc.next();
					PatientBean bean = new PatientBean();
					bean.setPname(name);
					bean.setAddress(address);
					bean.setMobilenumber(phone);
					if (service.validatePatient(bean)) //to validate
					{
						try {
							boolean flag = service.insertDetails(bean);
							if (flag)
								System.out.println("successfiuly inserted");
						} catch (PatientException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
					}  //end if for validate
					else
					{
						System.out.println("Invalid Values");
					}
					break;
				case 2:
					System.out.println("enter patient id");
					int id = sc.nextInt();
					try {
						PatientBean record = service.getRecord(id);
						System.out.println(record);
					} catch (PatientException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					break;
				case 3:
					try {
						ArrayList<PatientBean> List = service.getAllRecord();
						for (PatientBean obj : List) {
							System.out.println(obj);
						}
					} catch (PatientException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());

					}
					break;

				}
			} while (choice != 0);
		}
	}

}
