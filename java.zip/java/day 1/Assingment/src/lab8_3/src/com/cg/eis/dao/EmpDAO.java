package com.cg.eis.dao;

import com.cg.eis.bean.Employee;

public interface EmpDAO {
	boolean writeEmployee(Employee emp);

	}

