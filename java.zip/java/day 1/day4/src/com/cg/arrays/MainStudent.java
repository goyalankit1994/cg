package com.cg.arrays;

import java.util.Arrays; // (declaration : for eachloop :variable argument:sorting)

public class MainStudent {
static public int add(int x,int ...arr)   // variable argument
{
	int sum =0;
	for(int var:arr)
	{
		sum = sum+var;
	}
	sum = sum+x;
	return sum;
}
	public static void main(String[] args) {
	int res = add(2,3,4,5); // calling variable argument
	int res1=add(2,7,8);//calling variable argument
	System.out.println(res);
	System.out.println(res1);
		Student []stu = new Student[3];
System.out.println(stu[0]);
		stu[0]=new Student(1,"a");
		stu[1] = new Student(1,"b");
		stu[2]=new Student(3,"c");
		for(Student var:stu)
		{
			System.out.println(var);
		}
		int[]arr = {1,89,3,56,23};
		System.out.println("before sorting");
		for(int var:arr)
		{
			System.out.println(var);
		}
		Arrays.sort(arr);
		System.out.println("after sort");
		for(int var:arr)
		{
			System.out.println(var);
		}
	}

}
