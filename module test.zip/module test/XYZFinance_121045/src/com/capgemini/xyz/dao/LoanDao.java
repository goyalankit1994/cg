package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.FinanceException;
import com.capgemini.xyz.util.DBUtil;
import com.capgemini.xyz.util.Messages;

public class LoanDao implements ILoanDao {

	Connection conn;
	private String insertCustQuery = "insert into customer values(cust_seq.NEXTVAL,?,?,?,?)";
	private String selectCustIdQuery = "select cust_seq.CURRVAL from dual";
	private String insertLoanQuery = "insert into loan values(loan_seq.NEXTVAL,?,?,?)";
	private String selectLoanIdQuery = "select loan_seq.CURRVAL from dual";

	Logger logger = Logger.getLogger(LoanDao.class);

	@Override
	public long insertCust(Customer customer) throws FinanceException {
		long custId = 0;
		conn = DBUtil.getConnection();
		try {
			PreparedStatement insertCustStmt = conn
					.prepareStatement(insertCustQuery);
			insertCustStmt.setString(1, customer.getCustName());
			insertCustStmt.setString(2, customer.getAddress());
			insertCustStmt.setString(3, customer.getEmail());
			insertCustStmt.setLong(4, customer.getMobile());
			int rows = insertCustStmt.executeUpdate();
			if (rows > 0) {
				Statement getCustIdStmt = conn.createStatement();
				ResultSet custIdRs = getCustIdStmt
						.executeQuery(selectCustIdQuery);
				if (custIdRs.next()) {
					custId = custIdRs.getLong(1);
					logger.info(Messages.INSERTION_SUCCESSFUL_CUSTOMER);
				}
			}
		} catch (SQLException e) {
			logger.error(Messages.ERROR_INSERTING_VALUES_CUSTOMER);
		} finally {
			try {
				conn.close();
				logger.info(Messages.CONNECTION_TERMINATED);
			} catch (SQLException e) {
				logger.error(Messages.CONNECTION_CANNOT_BE_TERMINATED);
				throw new FinanceException(
						Messages.CONNECTION_CANNOT_BE_TERMINATED);
			}
		}
		return custId;
	}

	@Override
	public long applyLoan(Loan loan) throws FinanceException {
		long loanId = 0;
		conn = DBUtil.getConnection();
		try {
			PreparedStatement insertLoanStmt = conn
					.prepareStatement(insertLoanQuery);
			insertLoanStmt.setDouble(1, loan.getLoanAmount());
			insertLoanStmt.setLong(2, loan.getCustId());
			insertLoanStmt.setInt(3, loan.getDuration());
			int rows = insertLoanStmt.executeUpdate();
			if (rows > 0) {
				Statement getLoanIdStmt = conn.createStatement();
				ResultSet loanIdRs = getLoanIdStmt
						.executeQuery(selectLoanIdQuery);
				if (loanIdRs.next()) {
					loanId = loanIdRs.getLong(1);
					logger.info(Messages.INSERTION_SUCCESSFUL_LOAN);
				}
			}
		} catch (SQLException e) {
			logger.error(Messages.ERROR_INSERTING_VALUES_LOAN);
		} finally {
			try {
				conn.close();
				logger.info(Messages.CONNECTION_TERMINATED);
			} catch (SQLException e) {
				logger.error(Messages.CONNECTION_CANNOT_BE_TERMINATED);
				throw new FinanceException(
						Messages.CONNECTION_CANNOT_BE_TERMINATED);
			}
		}
		return loanId;
	}
}
