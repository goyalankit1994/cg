package com.cg.transportdetails.dao;

import java.util.List;

import com.cg.transportdetails.dto.BookingBean;
import com.cg.transportdetails.dto.TruckBean;
import com.cg.transportdetails.exception.TransportException;

public interface TransportDetailsDao {

	List<TruckBean> retrieveTransportDetails() throws TransportException;
	int bookTrucks(BookingBean bookingBean) throws TransportException;
}
