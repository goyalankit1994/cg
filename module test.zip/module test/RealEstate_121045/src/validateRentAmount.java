import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.cg.frs.service.FlatRegisterationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;


public class validateRentAmount {

	String rent;
	IFlatRegisterationService flatRegisteration;
	@Before
	public void setUp() throws Exception {
		rent = "2500";
		flatRegisteration = new FlatRegisterationServiceImpl();
	}

	@Test
	public void test() {
		boolean isValid = flatRegisteration.validateDesiredRentAmount(rent);
		assertTrue(isValid);
	}

}
