package com.capgemini.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.dao.ITruckDao;
import com.capgemini.dao.TruckDao;
import com.capgemini.service.ITruckService;
import com.capgemini.service.TruckService;

public class TransportTestCase {
	ITruckService service;
	ITruckDao dao;
	@Before
	public void init()
	{
		service = new TruckService();
		dao = new TruckDao();
	service.setDao(dao);
	}

	@Test
	public void testRetrieveTruckDetails()throws BookingException{
		assertNotNull(dao.retrieveTruckDetails());
	}

	@Test
	public void testBookTrucks() throws BookingException {
		BookingBean bean= new BookingBean();
		bean.setCustid("1004");
		bean.setCustMobile(823916112);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		System.out.println("enter date ");
		String input = "2016-10-15";
		LocalDate date = LocalDate.parse(input, format);
		bean.setDateoftransport(date);
		bean.setNooftrucks(1);
		bean.setTruckid(1002);
		
		assertNotEquals(0, dao.bookTrucks(bean));
	}
}


