package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmpService {
	Character getScheme(double salary, String designation);

	boolean writeEmployee(Employee emp);

}
