package comm.cg.exception6_2;

public class CurrentAccount extends Account {
	public CurrentAccount() {
		super();
		overdraft=20000;
	}
	
	public CurrentAccount(double bal,Person p) 
	{
		super(bal,p);
		overdraft=20000;
	}

	private double overdraft;

	public double getOverdraft() {
		return overdraft;
	}

	public void setOverdraft(double overdraft) {
		this.overdraft = overdraft;
	}
	
	@Override
	public void withdraw(double amount)
	{
		
		if(amount<getBalance())
			this.setBalance(getBalance()-amount);
		else if(amount<getBalance()+overdraft)
			{
			this.setBalance(0);
			overdraft=overdraft-(amount-getBalance());
			}
		else
			System.out.println("Not enough balance");
	}
}