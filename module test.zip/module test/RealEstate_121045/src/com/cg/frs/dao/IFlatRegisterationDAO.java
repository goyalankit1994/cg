package com.cg.frs.dao;

import java.util.List;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegisterationException;

public interface IFlatRegisterationDAO {

	List<Integer> getOwnerID() throws FlatRegisterationException;

	boolean registerFlat(FlatRegistrationDTO flat) throws FlatRegisterationException;

}
