package lab1;
import java.util.Scanner;

public class PersonDetails {


	public static void main(String[] args)
	{
		String fname;
	    String lname;
	    String gender;
	    int age;
	    float weight;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		fname=sc.nextLine();
		System.out.println("enter lname");
		lname=sc.nextLine();
		System.out.println("enter Gender");
		gender=sc.nextLine();
		System.out.println("enter age");
		age=sc.nextInt();
		System.out.println("enter Weight");
		weight=sc.nextFloat();
		System.out.println("Person Details");
		System.out.println("-------------------------------------------");
		System.out.println("name:" +fname);
		System.out.println("lname:" +lname);
		System.out.println("gender :" +gender);
		System.out.println("age:" +age);
		System.out.println("weight:" +weight);
		sc.close();
		
	}

	
}
