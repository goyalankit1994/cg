package com.capgemini.service;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EmpServiceImplTest {

	String salary;
	EmpService eService;
	
	@Before
	public void setUp() throws Exception {
		eService = new EmpServiceimpl(); 
		salary = "36000.000";
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testvalidateSalary() {
		boolean valid;
		valid = eService.validateSalary(salary);
		assertTrue(valid);
		System.out.println(valid);
	}
}
