/**
 * 
 */
package com.capgemini.bean;

/**
 * @author angoyal
 *
 */
public class TruckBean {
	private int truckId;
	private String trucktype;
	private String origin;
	private String destination;
	private float charges;
	private int availablenos;
	public TruckBean()
	{
		
	}
	public int getTruckId() {
		return truckId;
	}
	public void setTruckId(int truckId) {
		this.truckId = truckId;
	}
	public String getTrucktype() {
		return trucktype;
	}
	public void setTrucktype(String trucktype) {
		this.trucktype = trucktype;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public float getCharges() {
		return charges;
	}
	public void setCharges(float charges) {
		this.charges = charges;
	}
	@Override
	public String toString() {
		return "TruckBean [truckId=" + truckId + ", trucktype=" + trucktype
				+ ", origin=" + origin + ", destination=" + destination
				+ ", charges=" + charges + ", availablenos=" + availablenos
				+ "]";
	}
	public int getAvailablenos() {
		return availablenos;
	}
	public void setAvailablenos(int availablenos) {
		this.availablenos = availablenos;
	}
	

}
