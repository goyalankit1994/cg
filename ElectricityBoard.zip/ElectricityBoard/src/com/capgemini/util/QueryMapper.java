package com.capgemini.util;

public interface QueryMapper {

	String GET_ALL_CONSUMERS = "select * from consumers";
	String SEARCH_CONSUMER = "select * from consumers where consumer_num = ?";
	String GET_BILL_DETAILS = "select bill.bill_num,cons.consumer_num,cons.consumer_name,cons.address,bill.cur_reading,bill.unitConsumed,bill.netAmount,bill.bill_date from Consumers cons,billDetails bill where cons.consumer_num = bill.consumer_num and cons.consumer_num = ?";
	String GENERATE_NEXT_BILL = "insert into billdetails values(seq_bill_num.NEXTVAL,?,?,?,?,sysdate)";
	String GET_BILL_NUMBER = "select seq_bill_num.CURRVAL from dual";
}
