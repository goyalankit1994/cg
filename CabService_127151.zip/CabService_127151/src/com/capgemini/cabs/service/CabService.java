package com.capgemini.cabs.service;


import java.util.regex.Pattern;

import com.capgemini.cabs.dao.CabRequestDAO;
import com.capgemini.cabs.dao.ICabRequestDAO;
import com.capgemini.cabs.dto.CabsRequests;
import com.capgemini.cabs.exception.CabsException;

public class CabService implements ICabService{

	ICabRequestDAO dao;				//Reference of ICabRequestDAO interface
	
	public  CabService() 
	{
		dao=new CabRequestDAO();	//Object of CabRequestDAO
	}
	
	public void setDao(ICabRequestDAO dao)
	{
		this.dao=dao;
	}
	
	
	@Override
	public int addCabRequestDetails(CabsRequests cabRequest) throws CabsException {
		// TODO Auto-generated method stub
		
		return dao.addCabRequestDetails(cabRequest);
	}

	@Override
	public CabsRequests getRequestDetails(int requestId) throws CabsException {
		// TODO Auto-generated method stub
		return dao.getRequestDetails(requestId);
	}

	
	public boolean validation(CabsRequests input)
	{
		
		boolean nameflag=true,phoneflag=true,pinflag=true;
		
		String namePatt="[A-Z]{1}[a-zA-z]{1,20}";
		boolean nameMatch=Pattern.matches(namePatt, input.getCustomerName());

		
		if(!nameMatch)		//Validating Name Input
		{
			System.out.println("Name must contain only character and first character is capital. Please Enter valid name.");
			nameflag=false;
		}
		
		String phonePatt="[7-9]{1}[0-9]{9}";
		boolean match=Pattern.matches(phonePatt, input.getPhoneNumber());
		
		if(!match)			//Validating Phone Input pattern
		{
			System.out.println("Phone number should contain only number and it must be 10 digits and start with 7,8 or 9.");
			phoneflag=false;
		}
		
		String pinPatt="[0-9]{6}";
		boolean pinMatch=Pattern.matches(pinPatt, input.getPincode());
		
		if(!pinMatch)//Validating Pin Input Pattern
		{
			System.out.println("Pin code should contain 6 number.");
			pinflag=false;
		}
		
		return (nameflag&phoneflag&pinflag);
	}
	
}
