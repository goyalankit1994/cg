package com.cg.onlineshopping.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.onlineshopping.bean.Customer;
import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.bean.Purchase;
import com.cg.onlineshopping.dao.ShoppingDao;
import com.cg.onlineshopping.dao.ShoppingDaoImpl;
import com.cg.onlineshopping.exception.ShoppingException;

public class ShoppingServiceImpl implements ShoppingService{

	ShoppingDao dao;
	
	public ShoppingServiceImpl()
	{
		dao = new ShoppingDaoImpl();
	}
	@Override
	public ArrayList<Product> getProducts(Customer bean) throws ShoppingException {
		// TODO Auto-generated method stub
		return dao.getProducts(bean);
	}

	@Override
	public HashMap<LocalDate,Product> purchaseProduct(int prodId, int custId)
			throws ShoppingException {
		// TODO Auto-generated method stub
		return dao.purchaseProduct(prodId,custId);
	}

}
