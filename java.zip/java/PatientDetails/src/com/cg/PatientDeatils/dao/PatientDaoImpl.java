package com.cg.PatientDeatils.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



import org.apache.log4j.Logger;

import com.cg.PatientDeatils.dbutil.DbUtil;
import com.cg.PatientDetails.Exception.PatientException;
import com.cg.PatientDetails.dto.PatientBean;
import com.cg.patient.logger.MyLogger;

public class PatientDaoImpl implements PatientDao {
	Logger logger = MyLogger.getLoggerInsatnce();
	Connection con;
	public PatientDaoImpl()
	{
	con =  DbUtil.getConnection();
	if(con!=null)
	{
		logger.info("obtained connection");
	}
	}
	
	public boolean insertDetails(PatientBean obj) throws PatientException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try
		{
			String sql = "INSERT INTO PatientDetails VALUES(patient_id_seq.NEXTVAL,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, obj.getPname());
			pstmt.setString(2, obj.getAddress());
			pstmt.setString(3, obj.getMobilenumber());
			int row = pstmt.executeUpdate();
			if(row ==0)
				throw new PatientException("unable to insert");
			else
				logger.info("inserted record"+obj);
				flag = true;
		}
		catch(SQLException e)
		{
			logger.error("Exception occured"+e.getMessage());
			throw new PatientException(e.getMessage());
		}
		return flag;
	}

	
	public PatientBean getRecord(int patientid) throws PatientException {
		// TODO Auto-generated method stub
		PatientBean bean = null;
		try
		{
		String sql = "SELECT * FROM PatientDetails WHERE id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
//		System.out.println("Enter Id ");
		pstmt.setInt(1, patientid);
		ResultSet result = pstmt.executeQuery();
		bean = new PatientBean();
		if(result.next())
		{
			bean = new PatientBean();
			bean.setpId(result.getInt(1));
			bean.setPname(result.getString(2));
			bean.setAddress(result.getString(3));
			bean.setMobilenumber(result.getString(4));
			logger.info("fetch record"+bean);
			
		}
		else
			throw new PatientException("Patient with id"+patientid+ "not found");
		}
		catch(SQLException e)
		{
			logger.error("exception occured during get by id"+e.getMessage());
			throw new PatientException(e.getMessage());
		}
		return bean;
	}

	
	public ArrayList<PatientBean> getAllRecord() throws PatientException {
		// TODO Auto-generated method stub
		ArrayList<PatientBean> list = null;
		try
		{
			String sql = "SELECT * FROM PatientDetails";
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			list = new ArrayList<PatientBean>();
			while(result.next())
			{
				PatientBean bean = new PatientBean();
				bean.setpId(result.getInt(1));
				bean.setPname(result.getString(2));
				bean.setAddress(result.getString(3));
				bean.setMobilenumber(result.getString(4));
			list.add(bean);	
			logger.info("fetched parentdetails"+bean);
			}
			if(list.size() == 0)
			{
				throw new PatientException("no record found");
			}
		}
		catch(SQLException e)
		{
			logger.error("exception occured during get by id"+e.getMessage());
			System.out.println(e.getMessage());
		}
		return list;
	}

}
