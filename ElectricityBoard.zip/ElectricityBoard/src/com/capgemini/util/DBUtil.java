package com.capgemini.util;

import java.util.ResourceBundle;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.capgemini.exception.EBillException;

public class DBUtil {

	static DataSource dataSource;
	static Logger logger = Logger.getLogger(DBUtil.class);
	
	public static DataSource getDataSource() throws EBillException{
		if (dataSource == null){
			InitialContext context;
			try {
				context = new InitialContext();
				ResourceBundle bundle = ResourceBundle.getBundle("jdbc");
				dataSource = (DataSource) context.lookup(bundle.getString("jndi"));
				logger.info("DataSource Created");
			} catch (NamingException e) {
				logger.error("Error Creating DataSource" + e);
				throw new EBillException("Error Creating DataSource",e);
			}
			
		}
		return dataSource;
	}
}
