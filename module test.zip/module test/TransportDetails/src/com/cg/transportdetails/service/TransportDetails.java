package com.cg.transportdetails.service;

import java.util.List;
//import java.util.ArrayList;


import com.cg.transportdetails.dao.TransportDetailsDao;
import com.cg.transportdetails.dto.BookingBean;
import com.cg.transportdetails.dto.TruckBean;
import com.cg.transportdetails.exception.TransportException;

public interface TransportDetails {
	
	List<TruckBean> retrieveTransportDetails() throws TransportException;
	int bookTrucks(BookingBean bookingBean) throws TransportException;
	void setDao(TransportDetailsDao dao);
	boolean validation(String bean);

}
