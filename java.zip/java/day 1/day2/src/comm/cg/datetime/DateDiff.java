package comm.cg.datetime;

import java.time.LocalDate;
import java.time.Period;

public class DateDiff {

	public static void main(String[] args) {
		LocalDate today =  LocalDate.now();
		LocalDate date = LocalDate.of(2017, 04, 12);
		 Period diff = today.until(date); // diff betweem 2 date
		 System.out.println("diff in date are " +diff.getDays()+ "days" +diff.getMonths() +"months"+diff.getYears()+"years");
		// TODO Auto-generated method stub

	}

}
