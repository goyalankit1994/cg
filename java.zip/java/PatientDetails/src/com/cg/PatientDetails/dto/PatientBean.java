package com.cg.PatientDetails.dto;

public class PatientBean {
	private int pId;
	private String pname;
	private String address;
	private String mobilenumber;
	public PatientBean()
	{
		
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	@Override
	public String toString() {
		return "PatientBean [pId=" + pId + ", pname=" + pname + ", address="
				+ address + ", mobilenumber=" + mobilenumber + "]";
	}
	

}
