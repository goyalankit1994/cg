package com.cg.arrays;

public class ArrayDemo {

	public static void main(String[] args) {
	int arr[] = {1,2,3,4,5};
	//or(2 method)
	int []ptr = new int[3];
	ptr[0]=12;
	ptr[1]=13;
	ptr[4]=14;
for(int i=0;i<arr.length;i++)
	System.out.println("arr["+i+"] = "+arr[i]);   //toprint
System.out.println("printing value using for each ");
 for(int var :ptr)
 {
	 System.out.println(var);
 }
	}

}
