package lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Warranty {

	public static void main(String[] args) {
DateTimeFormatter format= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Purchase Date :");
		String input1=sc.next();
		LocalDate date1=LocalDate.parse(input1, format);
		System.out.println("Enter warrantee Date :");
		long month=sc.nextLong(); //for months
		long year=sc.nextLong(); //for years
		date1=date1.plusMonths(month);
		date1=date1.plusYears(year);
		System.out.println(date1);
	}

}	

	