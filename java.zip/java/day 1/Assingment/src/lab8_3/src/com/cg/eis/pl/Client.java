package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.bean.EmployeeException;
import com.cg.eis.service.EmpService;
import com.cg.eis.service.EmpServiceImpl;

public class Client {
	static EmpService eService = new EmpServiceImpl();
	static boolean saved = false;

	public static void main(String[] args) {
	
		Employee emp = new Employee();
		Scanner input = new Scanner(System.in);

		System.out.println("Enter Employee Details : ");
		System.out.println("Enter ID :");
		emp.setId(input.nextInt());
		System.out.println("Enter Name : ");
		emp.setName(input.next());
		System.out.println("Enter Designation : ");
		emp.setDesignation(input.next());
		while (true) {
			System.out.println("Enter Salary : ");
			try {
				emp.setSalary(input.nextDouble());
				break;
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
		emp.setInsuranceScheme(eService.getScheme(emp.getSalary(),
				emp.getDesignation()));
		System.out.println("\n********Entered Employee Details**********");
		System.out.println("\nID : " + emp.getId());
		System.out.println("\nName : " + emp.getName());
		System.out.println("\nDesignation : " + emp.getDesignation());
		System.out.println("\nSalary : " + emp.getSalary());
		if (emp.getInsuranceScheme() != 'N')
			System.out.println("\nScheme : " + emp.getInsuranceScheme());
		else
			System.out.println("\nScheme : No Scheme");
		
		saved = eService.writeEmployee(emp);
		if (saved){
			System.out.println("Emp Saved");
		} else {
			System.out.println("Emp Not Saved");
		}
		input.close();
	}
}
