package com.cg.PatientDetails.Service;

import java.util.ArrayList;

import com.cg.PatientDeatils.dao.PatientDao;
import com.cg.PatientDetails.Exception.PatientException;
import com.cg.PatientDetails.dto.PatientBean;

public interface PatientService {
	public  boolean validatePatient(PatientBean bean);
	public boolean insertDetails(PatientBean obj) throws PatientException ;
public PatientBean getRecord(int patientid)
throws PatientException;
public ArrayList<PatientBean>getAllRecord()
throws PatientException;
public void setDao(PatientDao dao);
}
