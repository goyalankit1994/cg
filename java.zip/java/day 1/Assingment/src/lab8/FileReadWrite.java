package lab8;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReadWrite 
{
	
	static BufferedReader br;
	static BufferedWriter bw;
	private static String readFileName = "readfile.txt";
	private static String WriteFileName = "writefile.txt";
	public static void main(String[] args) {
		try {
			br = new BufferedReader(new FileReader(readFileName));
			bw = new BufferedWriter(new FileWriter(WriteFileName));
			
			String line = null;
			while ((line = br.readLine()) != null) {
				StringBuffer lineBuffer = new StringBuffer();
				lineBuffer.append(line);
				lineBuffer.reverse();
				bw.write(lineBuffer.toString());
				bw.newLine();
				System.out.println(line);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		} finally{
			try {
				br.close();
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
	}


}


