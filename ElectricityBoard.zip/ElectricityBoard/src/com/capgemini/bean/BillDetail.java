package com.capgemini.bean;

import java.time.LocalDate;
import java.util.Date;

public class BillDetail {
	private int billNumber;
	private Consumer consumer;
	private int currentReading;
	private int unitConsumed;
	private double netAmount;
	private Date billDate;

	public BillDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BillDetail(Consumer consumer, int currentReading, int unitConsumed,
			double netAmount) {
		super();
		this.consumer = consumer;
		this.currentReading = currentReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
	}

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	public Consumer getConsumer() {
		return consumer;
	}

	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	public int getCurrentReading() {
		return currentReading;
	}

	public void setCurrentReading(int currentReading) {
		this.currentReading = currentReading;
	}

	public int getUnitConsumed() {
		return unitConsumed;
	}

	public void setUnitConsumed(int unitConsumed) {
		this.unitConsumed = unitConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public String getBillDate() {
		int month = billDate.getMonth();
		if (month == 0)
			return "JANUARY";
		else if (month == 1)
			return "FEBRUARY";
		else if (month == 2)
			return "MARCH";
		else if (month == 3)
			return "APRIL";
		else if (month == 4)
			return "MAY";
		else if (month == 5)
			return "JUNE";
		else if (month == 6)
			return "JULY";
		else if (month == 7)
			return "AUGUST";
		else if (month == 8)
			return "SEPTEMBER";
		else if (month == 9)
			return "OCTOBER";
		else if (month == 10)
			return "NOVEMBER";
		else
			return "DECEMBER";
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	@Override
	public String toString() {
		return "\nBillDetail [billNumber=" + billNumber + ", consumer="
				+ consumer + ", currentReading=" + currentReading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ ", billDate=" + billDate + "]";
	}
}
