
public class CalMul {
	public int multiply(int x,int y)
	{
	return x*y;	
	}

}
