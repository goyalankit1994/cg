package com.capgemini.ams.service;

import com.capgemini.ams.dao.IManagerDAO;
import com.capgemini.ams.dao.ManagerDAOImpl;
import com.capgemini.ams.exception.AssetException;

public class ManagerServiceImpl implements IManagerService{
	
	IManagerDAO managerDAO;
	
	public void setDao(ManagerDAOImpl managerDao) {
		
		this.managerDAO = managerDao; 
		
	}
	
	public ManagerServiceImpl()
	{
		managerDAO = new ManagerDAOImpl();
	}
	
	
	@Override
	public int raiseRequest(int assetId, int quantity, int mgrCode, int empNum) throws AssetException{
		// TODO Auto-generated method stub
		return managerDAO.raiseRequest(assetId, quantity, mgrCode, empNum);
	}

}
