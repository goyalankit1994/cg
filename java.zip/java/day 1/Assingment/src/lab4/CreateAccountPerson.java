package lab4;

public class CreateAccountPerson {

	public static void main(String[] args) {

		Person p = new Person("smith", 21);
		Person p1 = new Person("Kathy", 21);
		Account acc = new Account(p, 2000);
		Account acc1 = new Account(p1, 3000);
		acc.Deposit(2000);
		acc1.withdraw(2000);
		System.out.println("Available Balance in smith account  is "
				+ acc.getBalance());
		System.out.println("Available Balance kathy account is "
				+ acc1.getBalance());
		System.out.println(acc);
		System.out.println(acc1);

	}

}
