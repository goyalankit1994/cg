package com.cg.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.dto.BillDetails;
import com.cg.dto.EbillBean;
import com.cg.exception.EbillException;

public interface EbillDao {
	public List<EbillBean> getAllConsumer() throws SQLException;

	public EbillBean searchConsumer(int con_nu) throws EbillException;

	public List<BillDetails> getBillDetails(int cnum) throws EbillException;

	public int generateNextBill(BillDetails nextBill) throws EbillException;
}


