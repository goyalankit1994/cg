package com.capgemini.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.jstl.core.Config;

import com.sun.net.httpserver.Filter.Chain;
import com.sun.org.apache.bcel.internal.generic.INSTANCEOF;

public class MyFilter implements Filter {
	
	FilterConfig config;
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		long before = System.currentTimeMillis();
		arg2.doFilter(arg0, arg1);
		long after = System.currentTimeMillis();
		String name="";
		if (arg0 instanceof HttpServletRequest){
			name = ((HttpServletRequest) arg0).getRequestURI();
		}
		config.getServletContext().log(name + ":" + (after - before) + "ms");
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		config = arg0;
	}

}
