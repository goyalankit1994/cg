import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.frs.service.FlatRegisterationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;


public class validateFlatType {

	String flatType;
	IFlatRegisterationService flatRegisteration;
	
	@Before
	public void setUp() throws Exception {
		flatType = "3";  //Test Value Goes Here
		flatRegisteration = new FlatRegisterationServiceImpl();
	}

	@Test
	public void test() {
		boolean isValid = flatRegisteration.validateFlatType(flatType);
		assertTrue(isValid);
	}

}
