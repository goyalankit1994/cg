package comm.cg.collection;

import java.util.Comparator;

public class SortEmp implements Comparator<Object> {
	@Override
	public int compare(Object arg0 , Object arg1){
	int diff =0;
	if(arg0 instanceof Employee &&  arg1 instanceof Employee)
	{
		Employee ref1 = (Employee)arg0;
		Employee ref2 = (Employee)arg1;
		diff = ref1.getId()-ref2.getId();
	}
if(arg0 instanceof WageEmp && arg1 instanceof WageEmp)
{
	WageEmp ref1 = (WageEmp)arg0;
	WageEmp ref2 = (WageEmp)arg1;
	diff = ref1.getId()-ref2.getId();
}
return diff;
}
}