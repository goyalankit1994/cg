package com.cg.PatientDeatils.dao;

import java.util.ArrayList;

import com.cg.PatientDetails.Exception.PatientException;
import com.cg.PatientDetails.dto.PatientBean;

public interface PatientDao {
		public boolean insertDetails(PatientBean obj) throws PatientException ;
	public PatientBean getRecord(int patientid)
	throws PatientException;
	public ArrayList<PatientBean>getAllRecord()
	throws PatientException;
}

