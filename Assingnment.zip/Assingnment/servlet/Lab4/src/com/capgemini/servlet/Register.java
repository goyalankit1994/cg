package com.capgemini.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.bean.Bean;
import com.capgemini.service.IService;
import com.capgemini.service.ServiceImpl;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	
	IService service = new ServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StringBuffer skills = new StringBuffer();
		for (String skill : request.getParameterValues("skills")) {
			skills.append(skill + ",");
		}
		Character gender;
		if (request.getParameter("gender").equalsIgnoreCase("male"))
			gender = 'M';
		else
			gender = 'F';
		Bean bean = new Bean(request.getParameter("firstname"), request.getParameter("lastname"), request.getParameter("password"), gender, skills.toString(), request.getParameter("city"));
		boolean isAdded = service.insert(bean);
		if (isAdded){
			request.setAttribute("bean", bean);
			request.getRequestDispatcher("ShowRegisteration").forward(request, response);
		} else{
			response.sendRedirect("FailureRegisteration");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
