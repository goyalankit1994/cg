package com.cg.electricitybill.logger;

public class MyLogger {

}
