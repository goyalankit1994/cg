package com.capgemini.service;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.bean.BillDetail;
import com.capgemini.bean.Consumer;
import com.capgemini.dao.EBillDAO;
import com.capgemini.dao.EBillDAOImpl;
import com.capgemini.exception.EBillException;

public class EBillServiceImpl implements EBillService {

	EBillDAO eBillDao;
	private final double perUnitCharge = 5;
	
	public EBillServiceImpl() throws EBillException {
		eBillDao = new EBillDAOImpl();
	}



	@Override
	public List<Consumer> getAllConsumer() throws EBillException {
		try {
			return eBillDao.getAllConsumer();
		} catch (SQLException e) {
			throw new EBillException("Error in reading Consumer");
		}
	}



	@Override
	public Consumer searchConsumer(int consumerNumber) throws EBillException {
		return eBillDao.searchConsumer(consumerNumber);
	}



	@Override
	public List<BillDetail> getBillDetails(int cnum) throws EBillException {
		return eBillDao.getBillDetails(cnum);
	}



	@Override
	public int calculateUnitConsumed(int lastMonthMeterReading,
			int currentMonthMeterReading) throws EBillException {
		if (lastMonthMeterReading > currentMonthMeterReading)
			throw new EBillException("Current reading Cannot be less than last Month reading");
		return (currentMonthMeterReading - lastMonthMeterReading);
	}



	@Override
	public double calculateNetAmount(int unitConsumed) {
		
		return (unitConsumed * perUnitCharge);
	}



	@Override
	public int generateNextBill(BillDetail nextBill) throws EBillException {
		
		return eBillDao.generateNextBill(nextBill);
	}

}
