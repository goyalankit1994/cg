package file;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class WriteFile {

	public static void main(String[] args) {
		File file = new File("demo.txt");
		FileOutputStream fout = null;
		BufferedOutputStream bout  = null;
		DataOutputStream  dout = null;
		
		try (BufferedReader reader =  new BufferedReader(new InputStreamReader(System.in)))
		{ 
			if(!file.exists())
		
		{
			boolean flag = file.createNewFile();
			if(flag)
			{
			fout = new  FileOutputStream("demo.txt"); // towrite byte by byte in a file
		 bout = new  BufferedOutputStream(fout);    // writes chunks of byte
		 dout = new DataOutputStream(bout);          // datatypes to byte
			
		String input = reader.readLine();
		dout.writeBytes(input);
		dout.flush();
			}
		}
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
	finally
	{ 
		try{
		dout.close();
		bout.close();
		fout.close();
	} 
		catch (IOException e)
	{
		System.out.println(e.getMessage());
	}
	}
	}
}
	


