package com.capgemini.ams.dao;


import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.exception.AssetException;

public interface IAdminDAO {

	boolean addAsset(Asset asset)throws AssetException;

	boolean updateAsset(int assetId, int quantity) throws AssetException;

	boolean allocateAsset(int requestId, LocalDate releaseDate)throws AssetException;

	boolean updateStatus(int requestId) throws AssetException;

	boolean generateReport() throws AssetException;

}
