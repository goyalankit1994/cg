package com.cg.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.TraineeBean;
import com.cg.dao.TraineeDao;
import com.cg.exception.TraineeException;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	private TraineeDao Dao;

	@Override
	public TraineeBean addTraineeDetails(TraineeBean bean)
			throws TraineeException {
		// TODO Auto-generated method stub
		return Dao.addTraineeDetails(bean);
	}

	@Override
	public Boolean removeTrainee(int id) throws TraineeException {
		// TODO Auto-generated method stub
		return Dao.removeTrainee(id);
	}

	@Override
	public TraineeBean getDetails(int id) throws TraineeException {
		// TODO Auto-generated method stub
		return Dao.getDetails(id);
	}

	@Override
	public ArrayList<TraineeBean> getallTraineeDetails()
			throws TraineeException {
		// TODO Auto-generated method stub
		return Dao.getallTraineeDetails();
	}

	@Override
	public boolean modifyTrainee(int id, TraineeBean trainee)
			throws TraineeException {
		// TODO Auto-generated method stub
		return Dao.modifyTrainee(id, trainee);
	}

	
	
	
	

}
