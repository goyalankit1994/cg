package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;









import com.cg.bean.CabRequest;
import com.cg.exception.CabException;
import com.cg.service.CabService;

@Controller
public class MyController {
	@Autowired
	CabRequest cabreq;
	@Autowired
	CabService service;
	ArrayList<String> pincodeList;
	@RequestMapping(value="/showForm")
	public String display(Model model)
	{
		model.addAttribute("cabreq1",cabreq);
		 pincodeList =new ArrayList<String>();
			
			pincodeList.add("411013");
			pincodeList.add("450156");
			pincodeList.add("412012");
			pincodeList.add("800023");
			pincodeList.add("542014");
			pincodeList.add("657845");
			model.addAttribute("list",pincodeList);
		
		  return "cabbooking";
		}
	@RequestMapping(value="/insertCabs")
	public String insertSuccess(@ModelAttribute("cabreq1")@Valid CabRequest cabs,BindingResult result,Model model) throws CabException
	{
		if(result.hasErrors())
		{
			System.out.println("error in validation");
			model.addAttribute("list",pincodeList);
			return "cabbooking" ; 
		}
			else
			{
				System.out.println("inserted successfully");
				service.addCabRequestDetails(cabs);
				int id = service.getRequestId(cabs);
				model.addAttribute("requestId", id);
				
				return "success";
			}
		
		
	}
	@RequestMapping(value="/fetch")
	public String fetchByID(Model model){
		try
		{
			model.addAttribute("cabs",cabreq);
		}
		catch(DataAccessException dataAccessException)   //pincode 
		{
			model.addAttribute("msg","No record found");
			return "error";
		}
		return "fetchByID";
		
	}
	@RequestMapping(value="/fetchSuccess")
	public String fetchSuccess(Model model,CabRequest cabs) throws CabException
	{
		try
		{
			cabs=service.getRequestDetails(cabs.getRequestId());
			model.addAttribute("details",cabs);
			System.out.println("fetched succesfully!");
			return "details";
		}
		catch (CabException e) {
			model.addAttribute("msg",e.getMessage());
			return "error";
			
		}
		
		
		
	}
	@RequestMapping(value="/home")
	public String goHome(){
		
		return "index";
		
	}
	
	
}
