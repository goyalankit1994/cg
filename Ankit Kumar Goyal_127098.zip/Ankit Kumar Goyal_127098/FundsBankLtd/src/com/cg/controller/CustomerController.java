package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.ComplaintBean;
import com.cg.exception.BankException;
import com.cg.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ComplaintBean req;
	@Autowired
	ICustomerService service;
	ArrayList<String> category;
	//transferring from index page to Raise Complaint
	@RequestMapping(value="/showForm")
	public String display(Model model)
	{
		model.addAttribute("req1",req);
		 category =new ArrayList<String>();    // Drop down for category
			
			category.add("Internet Banking");
			category.add("General Banking");
			category.add("Others");
			
			model.addAttribute("list",category);     //saving category array list in list
		
		  return "RaiseComplaint";        // redirect to RaiseComplaint page
		}
	// to insert details 
	@RequestMapping(value="/insertDetails")
	public String insertSuccess(@ModelAttribute("req1")@Valid ComplaintBean bean,BindingResult result,Model model) throws BankException
	{
		if(result.hasErrors())     //checking validation
		{
			System.out.println("error in validation");   //
			model.addAttribute("list",category);
			return "RaiseComplaint" ;                    //if error exist then redirect to same page
		}
		else
		{
			System.out.println("inserted successfully");
			service.raiseCustomerComplaint(bean);      // calling method for insertion
			int id = service.getComplaintId(bean);     
			model.addAttribute("complaintId", id);     // fetching complaint id to display
			
			return "Success";             //redirect to success page if inserted successfully
			
		}
	}
			
	// transfering of index page to complaint details
	@RequestMapping(value="/fetch")
	public String delteTraineeForm(Model model)
	{
		model.addAttribute("req2", req);
		return "complaintdetails" ;   //redirect to complaint Details
	}
	// to fetch from database
	@RequestMapping(value="/fetchsuccess")
	public String reteriveSucess(Model model,ComplaintBean bean1) throws BankException
	{ 
		bean1=service.checkComplaintStatus(bean1.getComplaintid());    // calling method for fetch
		model.addAttribute("getcomplaint",bean1);                      // storing fetch details in get complaint
		System.out.println("fetched succesfully!");
		return "complaintdetails";                                     // redirect to complaint details
	}
	
	
	
	
	
}
