package com.cg.onlineshopping.filter;

import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.logger.MyLogger;



/**
 * Servlet Filter implementation class OnlineFilter
 */
@WebFilter(filterName="/OnlineFilter",urlPatterns={"/*"})
public class OnlineFilter implements Filter {

    /**
     * Default constructor. 
     */
    public OnlineFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		chain.doFilter(request, response);
		HttpServletRequest req = (HttpServletRequest)request;
		String qStr = req.getParameter("action");
		if("product".equals(qStr))
		{
			HttpSession session = req.getSession(false);
			HashMap<LocalDate,Product>map= (HashMap<LocalDate, Product>) session.getAttribute("map");
			Logger logger = MyLogger.getLoggerInstance();
			logger.info("list printed by controller");
			logger.info(map);
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
