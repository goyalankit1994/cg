package com.cg.electricitybill.bean;

public class ConsumersBean {
	private int consumer_num;
	private String consumner_name;
	private String address;
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public String getConsumner_name() {
		return consumner_name;
	}
	public void setConsumner_name(String consumner_name) {
		this.consumner_name = consumner_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "ConsumersBean [consumer_num=" + consumer_num
				+ ", consumner_name=" + consumner_name + ", address=" + address
				+ "]";
	}
	public ConsumersBean(int consumer_num, String consumner_name, String address) {
		super();
		this.consumer_num = consumer_num;
		this.consumner_name = consumner_name;
		this.address = address;
	}
	public ConsumersBean() {
		// TODO Auto-generated constructor stub
	}
	

}
