package com.capgemini.ams.DButil;

public interface QueryMapper {
	
	String VALIDATE_USERNAME="SELECT username FROM user_master WHERE username=?";
	String VALIDATE_PASSWORD="SELECT username FROM user_master WHERE userpassword=?";
	String VALIDATE_ASSETID="SELECT assetid FROM asset WHERE assetid=?";
	String GET_USERTYPE="SELECT usertype FROM user_master WHERE username=? AND userpassword=?";
	String GET_ALL_ASSETS ="SELECT * FROM asset";
	String ADD_ASSETS = "INSERT INTO ASSET VALUES(seq_assetId.nextval,?,?,?)";
	String RAISE_REQUEST = "INSERT INTO assetRequest VALUES(seq_assetReqId.nextval,?,?,?,?,?,'NOT ALLOCATED',?)";
	String UPDATE_ASSET="UPDATE asset SET quantity=? WHERE assetid = ?";
	String GET_ASSET_DETAILS = "SELECT * FROM asset WHERE assetid = ?";
	String GET_EMP_NUM = "SELECT empNum FROM user_master WHERE username = ? AND userpassword = ?";
	String GET_REQUEST_ID = "SELECT seq_assetReqId.currval FROM DUAL";
	String GET_ASSET_QUANTITY= "SELECT quantity FROM asset WHERE assetId= ?";
	String GET_ALL_REQUESTS = "SELECT * FROM assetRequest";
	String VALIDATE_REQUEST_ID = "SELECT requestId FROM assetRequest WHERE requestId = ?";
	String ASSET_ALLOCATE = "INSERT INTO assetAllocation VALUES(seq_allocationid.nextval,?,?,sysdate,?)";
	String GET_REQUEST_DETAILS = "SELECT * FROM assetRequest WHERE requestId = ?";
	String UPDATE_STATUS = "UPDATE assetRequest SET status='Allocated' WHERE requestId = ?";
	String GET_REQUEST_QUANTITY = "SELECT quantity FROM assetRequest WHERE requestId = ?";
	String GET_ALL_ASSET_ALLOCATION_RECORDS = "SELECT * FROM assetAllocation";
	
}
