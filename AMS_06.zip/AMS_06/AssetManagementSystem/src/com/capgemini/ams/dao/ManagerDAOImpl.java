 package com.capgemini.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.ams.DButil.DBUtil;
import com.capgemini.ams.DButil.QueryMapper;
import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.exception.AssetException;

public class ManagerDAOImpl implements IManagerDAO {
	
	Connection con;
	
	public ManagerDAOImpl()
	{
		con = DBUtil.getConnection();
	}

	@Override
	public int raiseRequest(int assetId, int quantity, int mgrCode, int empNum) throws AssetException {
		// TODO Auto-generated method stub
		int requestId = 0;
		
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.RAISE_REQUEST);
		
			Asset asset = new Asset();
			asset = getAssetDetails(assetId);
			
			pstmt.setInt(1, assetId);
			pstmt.setInt(2, mgrCode);
			pstmt.setString(3, asset.getAssetName());
			pstmt.setString(4, asset.getAssetDesc());
			pstmt.setInt(5, quantity);
			pstmt.setInt(6, empNum);
			
			int rows = pstmt.executeUpdate();
			
			if(rows != 0 )
			{
				requestId = getRequestId();
			}
			else
			{
				throw new AssetException("Asset request raised for "+asset.getAssetName()+" is unsuccessful");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch bloc
			throw new AssetException("SQL Exception : "+e.getMessage());
		}
		
		
		return requestId;
	}

	private int getRequestId() throws AssetException {
		// TODO Auto-generated method stub
		int requestId = 0;
		try {
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(QueryMapper.GET_REQUEST_ID);
			
			if(result.next())
			{
				requestId = result.getInt(1);
			}
			else
			{
				throw new AssetException("Asset request not found for the request id");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AssetException("SQL Exception : "+e.getMessage());
		}
		
		return requestId;
	}

	private Asset getAssetDetails(int assetId) throws AssetException {
		// TODO Auto-generated method stub
		Asset asset = new Asset();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.GET_ASSET_DETAILS);
			
			pstmt.setInt(1, assetId);
			
			ResultSet result = pstmt.executeQuery();
			
			if(result.next())
			{
				asset.setAssetId(result.getInt("ASSETID"));
				asset.setAssetName(result.getString("ASSETNAME"));
				asset.setAssetDesc(result.getString("ASSETDES"));
				asset.setQuantity(result.getInt("QUANTITY"));
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AssetException("SQL Exception : "+e.getMessage());
		}
		
		return asset;
	}

}
