package com.capgemini.cabs.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.cab.exception.CabException;
import com.capgemini.cab.service.CabService;
import com.capgemini.cab.service.ICabService;
import com.capgemini.cabs.bean.CabRequest;



public class Client {
	static ICabService service = new CabService();

	public static void main(String[] args) throws SQLException {
		int choice = 0;
		try (Scanner sc = new Scanner(System.in)) 
		{
			System.out.println("1-Raise Cab Request");
			System.out.println("2-View Cab Request Status");
			System.out.println("3-EXIT");
			System.out.println("enter your choice");
			choice = sc.nextInt();
			switch (choice) 
			{
			case 1:
				System.out.println("enter name of the customer::");
				String name = sc.next();
				System.out.println("enter customer phone number");
				String pnumber = sc.next();
				System.out.println("enter pick up address");
				String pickadd = sc.next();
				System.out.println("enter pincode");
				String pcode = sc.next();
				CabRequest req = new CabRequest();
				req.setCname(name);
				req.setPhonenum(pnumber);
				req.setPickupadd(pickadd);
				req.setPincode(pcode);
				try 
				{
					boolean flag = service.isValidEnquiry(req);
					if(flag)
					{
						
							service.addCabRequestDetails(req);
					}
				}
					
				catch (CabException e) 
				{
					System.out.println(e.getMessage());
				}
				
			break;
			case 2:
				int id;
				System.out.println("Enter an id to search");
				id=sc.nextInt();
				try{
				CabRequest cabDetail=service.getRequestDetails(id);
				if(cabDetail==null)
				{
					System.out.println("sorry no details found \n");
				}
				else
				{
					System.out.println(" Name"+cabDetail.getCname());
					System.out.println("phone number"+cabDetail.getPhonenum());
					System.out.println("date "+cabDetail.getDate());
					System.out.println("request status"+cabDetail.getRequeststatus());
					System.out.println("cab number"+cabDetail.getCabnum());
					System.out.println("pick up address"+cabDetail.getPickupadd());
					System.out.println("pin code "+cabDetail.getPincode());
					
					}
				
				}catch(CabException e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
			case 0:
				System.exit(0);
				break;
			}while (choice != 0);
			}
		}
}

			
