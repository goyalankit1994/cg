package com.cg.lab11.service;

import java.util.ArrayList;

import com.cg.lab11.dao.MobileAppDao;
import com.cg.lab11.dto.MobileAppBean;
import com.cg.lab11.dto.PurchaseDetailsBean;
import com.cg.lab11.exception.PurchaseOrderException;

public interface MobileAppService {
	public boolean purchaseMobile(PurchaseDetailsBean bean) throws PurchaseOrderException;
	public boolean updateMobileDb(PurchaseDetailsBean bean) throws PurchaseOrderException;
	public boolean searchMobile(int min, int max) throws PurchaseOrderException;
	public ArrayList<MobileAppBean> getAllMobileRecords() throws PurchaseOrderException;
	public boolean deleteMobile(int mobileId)throws PurchaseOrderException;
	public boolean validation(PurchaseDetailsBean bean)throws PurchaseOrderException;
	public void setDao(MobileAppDao dao);
}
