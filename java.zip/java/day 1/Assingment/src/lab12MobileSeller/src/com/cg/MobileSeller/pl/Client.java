package com.cg.MobileSeller.pl;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.MobileSeller.Exception.MobileException;
import com.cg.MobileSeller.Service.MobileInterface;
import com.cg.MobileSeller.Service.MobileServiceImpl;
import com.cg.MobileSeller.dto.MobileBean;
import com.cg.MobileSeller.dto.PurchaseBean;

public class Client {
	static Scanner scan = new Scanner(System.in);
	static MobileInterface cService = new MobileServiceImpl();
	static boolean execute =false;
	
	/*
	 * main method
	 */
	public static void main(String[] args) {	
		do{System.out.println("Choose option from below");
		System.out.println("1. Insert Purchase Details");
		System.out.println("2. View Mobile Details");
		System.out.println("3. Delete mobile details");
		System.out.println("4. Search mobiles based on price range");
		

		String choice = scan.next();
		executeCaseChoice(choice);
		}while(!execute);
	
			
	}

	/*
	 * method to execute choice entered
	 */
	private static void executeCaseChoice(String choice) {
			PurchaseBean cus= null;
			switch (choice) {
			case "1":
				String phoneno=null;
				String cname=null;
				String mailid=null;
				int mobileId=0;
				
				System.out.println("**Insert purchase details");
				System.out.println("Enter Customer Details:");
				boolean nameValid = false;
				while(!nameValid){
					System.out.println("Enter Name :");
					 cname = scan.next();
					nameValid = cService.validateName(cname);
					if(!nameValid)
						System.out.println("Name should start with uppercase and have alphabets only");
				}
				boolean mailIdValid = false;
				while(!mailIdValid){
					System.out.println("Enter Mail ID :");
					mailid = scan.next();
					mailIdValid = cService.validateMailId(mailid);
					if(!mailIdValid)
						System.out.println("Use correct EmialId format");
				}
				boolean phoneNoValid = false;
				while(!phoneNoValid){
					System.out.println("Enter Phone No :");
					String phoneNo = scan.next();
					phoneNoValid = cService.validatePhoneNo(phoneNo);
					if(!phoneNoValid)
						System.out.println("Enter 10 digit mobile no.");
				}
				Map<Integer, Integer> map= null;
				try {
					map = cService.getMobiles();
				} catch (MobileException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
				}
				System.out.println(map);

				boolean mobileIdValid = false;
				while(!mobileIdValid){
					String temp= null;

					System.out.println("Enter Mobile ID :");
					mobileId = scan.nextInt();
					//mobileIdValid = cService.validateMobileId(temp);
					try {
						mobileIdValid = cService.checkMobileId(mobileId);
					} catch (MobileException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					
					if(!mobileIdValid)
						System.out.println("Enter given mobile ID");
					
				}
				cus = new PurchaseBean(cname,mailid,phoneno,mobileId);
				boolean saved = false;
				
				try {
					saved = cService.saveCust(cus);
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				System.out.println(saved);
				if(saved)
					System.out.println("Details Saved");
				
				else
					System.out.println("Sorry...details could not be saved");
			
				
				break;			
			
			case "2":
				List<MobileBean> mlist = null;
				System.out.println("**View Details**");
				try {
					mlist = cService.getMobList();
				} catch (MobileException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
				}
				System.out.println(mlist);
				break;

			
			case "3":
				System.out.println("**Delete Mobile Details**");
				
				
				System.out.println("Enter MobileID: ");
				int mobileid_delete;
				do{
					try {
						mobileid_delete = Integer.parseInt(scan.next());
						break;
					} catch (InputMismatchException e) {
						System.out.println("Enter Number Only");
						scan.nextLine();
					}
				}while(true);
				
				boolean delete = false;
				try {
					delete = cService.deleteMobile(mobileid_delete);
				}catch (Exception e) {
					System.out.println(e.getMessage());
				}
				
				if(delete)
					System.out.println("deleted");
				else
					System.out.println("Sorry...mobile could not be deleted");
			
				break;
			
			case "4":
				
				List<MobileBean> mlist_price = null;
				System.out.println("**View Mobiles based on price range**");
				System.out.println("Enter price range : \n from: ");
				int p1  = scan.nextInt();
				System.out.println("to :");
				int p2 = scan.nextInt();
				try {
					mlist_price = cService.getMobPriceList(p1,p2);
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				System.out.println(mlist_price);
				
				break;
				default:
				System.out.println("Wrong CHOICE !!!");
				break;
			}
	}

}
