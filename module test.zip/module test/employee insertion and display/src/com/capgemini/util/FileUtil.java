package com.capgemini.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.apache.log4j.Logger;

import com.capgemini.exception.EmpException;

public class FileUtil {
	static ObjectOutputStream oos;
	static ObjectInputStream ois;
	FileUtil fUtil;
	static String FileName = "emp.ser";
	static Logger logger = Logger.getLogger(FileUtil.class);
	
	private FileUtil() {
		
	}

	public static ObjectOutputStream getWriter() {
		
		if(oos==null){
			try {
				oos = new ObjectOutputStream(new FileOutputStream(FileName));
			} catch (FileNotFoundException e) {
				logger.error("File Not Found " + e);
			} catch (IOException e) {
				logger.error("IOException " + e);
			}
		}
		return oos;
	}

	public static ObjectInputStream getReader() throws EmpException {
		if (ois == null){
			try {
				ois = new ObjectInputStream(new FileInputStream(FileName));
			} catch (FileNotFoundException e) {
				logger.info("File Not Found " + e);
				throw new EmpException("File Not Found");
			} catch (IOException e) {
				logger.info("Cannot create object from file " + e);
				throw new EmpException("Error creating object from file");
			}	
		}
		return ois;
	}

	public static void closeWriter() {
		// TODO Auto-generated method stub
		try {
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void closeReader() {
		// TODO Auto-generated method stub
		try {
			ois.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
