package com.capgemini.cabs.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;


import com.capgemini.cabs.dto.CabsRequests;
import com.capgemini.cabs.service.CabService;
import com.capgemini.cabs.service.ICabService;

public class Client {

	static ICabService service=new CabService();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice=0;
		
		try(BufferedReader scan=new BufferedReader(new InputStreamReader(System.in)))
		{
			
			
			do
			{
				
				System.out.println("1) Raise Cab Request");
				System.out.println("2) View Cab Request Status");
				System.out.println("3) Exit");
				
				System.out.println("Please enter valid choice ");
				choice=Integer.parseInt(scan.readLine());
				
				switch(choice)
				{
				
				case 1:										//To get booking Id and insert customer details
					System.out.println("Enter the name of the customer");
					String name=scan.readLine();
					System.out.println("Enter customer phone number");
					
					String phone=scan.readLine();

					System.out.println("Enter pick up address");
					String address=scan.readLine();
					
					System.out.println("Enter pin code");
					String pin=scan.readLine();
					
					CabsRequests bean=new CabsRequests();	//new CabsRequests bean object is created
					bean.setCustomerName(name);
					bean.setPhoneNumber(phone);
					bean.setAddOfPick(address);
					bean.setPincode(pin);
					bean.setDateOfRequest(LocalDate.now());
					
					boolean flag=service.validation(bean);	//Validation method call to validate input
					if(flag)
					{
					int bookid=service.addCabRequestDetails(bean); //fetching booking id
					System.out.println("your request id is "+bookid);
					System.out.println();
					}
					
					break;
					
				case 2:
					System.out.println("Please Enter your request id:  ");
					int reqId=Integer.parseInt(scan.readLine());
					System.out.println();
					
					CabsRequests details=service.getRequestDetails(reqId);	//Fetching Booking details for given request id
					System.out.println("Name of Customer:   "+details.getCustomerName());
					System.out.println("Request Status:   "+details.getRequestStatus());
					System.out.println("Cab Number:   "+details.getCabNumber());
					System.out.println("Pick up Address:   "+details.getAddOfPick());
					System.out.println();
					break;
					
				case 3:System.exit(0);
									
				
				}
				
				System.out.println("Do you want to continue 1.Yes 0.No");
				choice=Integer.parseInt(scan.readLine());
				
			}while(choice!=0);
			
			
			
			
			
			
			
		}
		
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		
		
	}

}
