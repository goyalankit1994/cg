
public class StringFun {

	public static void main(String[] args) {
		String str = "Hello world";
		System.out.println("length=" +str.length());
		System.out.println("char at 3=" +str.charAt(3));
		System.out.println("index of 1 = " +str.indexOf("1"));
		System.out.println("last index of 1 = " +str.lastIndexOf("1"));
		System.out.println("substring from 0 to 5=" +str.substring(0,5));
		System.out.println("replace" +str.replace("l","a"));
		System.out.println("replace all=" +str.replaceAll("l","a"));
		System.out.println("lower=" +str.toLowerCase());
		System.out.println("upper=" +str.toUpperCase());
		System.out.println("concat=" +str.concat(" hi"));
		
		
		
		
		
		
		
		
		
		

	}

}
