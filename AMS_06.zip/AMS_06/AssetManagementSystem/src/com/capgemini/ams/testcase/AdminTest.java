package com.capgemini.ams.testcase;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.dao.AdminDAOImpl;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.AdminServiceImpl;

public class AdminTest {

	AdminServiceImpl adminService;
	AdminDAOImpl adminDao;
	
	@Before
	public void init()
	{
		adminService = new AdminServiceImpl();
		adminDao = new AdminDAOImpl();
		
		adminService.setDao(adminDao);
		
	}
	@Test
	public void testAddAsset() throws AssetException {
		
		Asset asset = new Asset();
		
		asset.setAssetName("Monitor");
		asset.setAssetName("Dell");
		asset.setQuantity(10);
		assertEquals(true, adminService.addAsset(asset));
	}
	
	@Test
	public void testAddAssetFail() throws AssetException {
		
		Asset asset = new Asset();
		
		asset.setAssetName("Monitor");
		asset.setAssetName("22");
		asset.setQuantity(-1);
		assertNotEquals(true, adminService.addAsset(asset));
	}

	@Test
	public void testUpdateAsset()throws AssetException {
		
		assertEquals(true, adminService.updateAsset(1002, 4));
	}
	
	@Test
	public void testUpdateAssetFail()throws AssetException {
		
		assertEquals(false, adminService.updateAsset(0122, 4));
	}
	
	@Test
	public void testAllocateAsset() throws AssetException{

		assertEquals(true,adminService.allocateAsset(1000033, LocalDate.parse("12/07/2017")));
	}
	
	@Test
	public void testAllocateAssetFail() throws AssetException{

		assertNotEquals(true,adminService.allocateAsset(1000033, LocalDate.parse("12-jun-2107")));
	}

	@Test
	public void testUpdateStatus() throws AssetException{
		
		assertEquals(true, adminService.updateStatus(1000033));
	}

	@Test
	public void testUpdateStatusFail() throws AssetException{
		
		assertEquals(false, adminService.updateStatus(0000123));
	}
	
	@Test
	public void testGenerateReport() throws AssetException{
		assertEquals(true, adminService.generateReport());
	}
	
	@Test
	public void testGenerateReportFail() throws AssetException{
		assertNotEquals(false, adminService.generateReport());
	}
	
}
