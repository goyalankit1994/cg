package com.capgemini.ams.bean;


import java.time.LocalDate;

public class Employee {
	
	private int empNum;
	private String empName;
	private String job;
	private int mgrCode;
	private LocalDate hireDate;
	private int deptId;			//Referred from Department bean
	
	public Employee() {
		super();
	}
	
	public int getEmpNum() {
		return empNum;
	}
	public void setEmpNum(int empNum) {
		this.empNum = empNum;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getMgrCode() {
		return mgrCode;
	}
	public void setMgrCode(int mgrCode) {
		this.mgrCode = mgrCode;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
}
