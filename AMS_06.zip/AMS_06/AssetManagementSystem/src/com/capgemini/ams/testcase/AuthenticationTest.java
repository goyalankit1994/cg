package com.capgemini.ams.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.ams.dao.AuthenticationDAOImpl;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.AuthenticationServiceImpl;

public class AuthenticationTest {
	
	AuthenticationServiceImpl authService;
	AuthenticationDAOImpl authDao;

	@Before
	public void init()
	{
		authService = new AuthenticationServiceImpl();
		authDao = new AuthenticationDAOImpl();
		
		authService.setDao(authDao);
	}
	
	@Test
	public void testValidateUserName() throws AssetException {

		assertNotEquals(false, authService.validateUserName("Ayushi"));
		
	}
	@Test
	public void testValidateUserNameFail() throws AssetException {

		assertEquals(false, authService.validateUserName("Pravin"));
		
	}

	@Test
	public void testValidatePassword() throws AssetException {

		assertNotEquals(false, authService.validatePassword("Ayushi"));	
	}
	
	@Test
	public void testValidatePasswordFail() throws AssetException {

		assertNotEquals(false, authService.validatePassword("Pravin"));	
	}

	@Test
	public void testGetUserType() throws AssetException {
		
		assertEquals("Admin", authService.getUserType("Ayushi","Ayushi"));
		
	}

	@Test
	public void testGetUserTypeFail() throws AssetException {
		
		assertNotEquals("Manager", authService.getUserType("Ayushi","Ayushi"));
		
	}

	@Test
	public void testGetMgrCode() throws AssetException {
		
		assertEquals(100002, authService.getMgrCode("Pooja", "Pooja"));
		
	}
	
	@Test
	public void testGetMgrCodeFail() throws AssetException {
		
		assertNotEquals(100005, authService.getMgrCode("Pooja", "Pooja"));
	}

}
