
public class CalDiv {
	public int divide(int x,int y)
	{
	return x/y;	
	}

}
