package com.capgemini.ams.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.ams.dao.ManagerDAOImpl;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.ManagerServiceImpl;

public class ManagerTest {
	
	ManagerServiceImpl managerService;
	ManagerDAOImpl managerDao;
	
	@Before
	public void init()
	{
		managerService = new ManagerServiceImpl();
		managerDao = new ManagerDAOImpl();
		
		managerService.setDao(managerDao);
	}
	
	@Test
	public void testRaiseRequest() throws AssetException {
		
		assertNotEquals(false, managerService.raiseRequest(1002, 2, 100002, 100004));
	}
	
	@Test
	public void testRaiseRequestFail() throws AssetException {
		
		assertNotEquals(false, managerService.raiseRequest(0123, 2, 100002, 100004));
	}

}
