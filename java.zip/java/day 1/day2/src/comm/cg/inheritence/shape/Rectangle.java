package comm.cg.inheritence.shape;

public class Rectangle extends Shape
{
private double length;
private double breath;
public Rectangle()
{
	
}
public Rectangle(double length,double breath)
{
	this.length=length;
	this.breath=breath;
}
@Override
public String toString() {
	return "Rectangle [length=" + length + ", breath=" + breath + "]";
}
public double getLength() {
	return length;
}
public void setLength(double length) {
	this.length = length;
}
public double getBreath() {
	return breath;
}
public void setBreath(double breath) {
	this.breath = breath;
}
@Override
public double calArea()
{

	return  this.length*this.breath;
	}
}
