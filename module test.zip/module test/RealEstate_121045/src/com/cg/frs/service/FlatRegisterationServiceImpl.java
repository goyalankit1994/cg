package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dao.FlatRegisterationDAO;
import com.cg.frs.dao.IFlatRegisterationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegisterationException;

/**
 * 
 * @author Dushyant
 * @version 1.0
 * This is the service layer class
 *
 */
public class FlatRegisterationServiceImpl implements IFlatRegisterationService {

	IFlatRegisterationDAO flatRegisterationDao = new FlatRegisterationDAO();

	
	/**
	 * Validate Flattype i.s. 1 or 2
	 */
	@Override
	public boolean validateFlatType(String flatType) {
		return flatType.matches("[1-2]{1}");
	}

	/**
	 * validate flat area
	 */
	@Override
	public boolean validateFlatArea(String flatArea) {
		return flatArea.matches("[0-9]{1,4}");
	}

	/**
	 * validate rent amount
	 */
	@Override
	public boolean validateDesiredRentAmount(String desiredRentAmount) {
		return desiredRentAmount.matches("[0-9]{1,8}([.][0-9]{1,2})?");
	}

	/**
	 * validate deposite amount and check whether deposite is greater than rent
	 */
	@Override
	public boolean validateDesiredDepositeAmount(String desiredDepositeAmount, Double desiredRentAmount) {
		boolean isValid = false;
		if(desiredDepositeAmount.matches("[0-9]{1,8}([.][0-9]{1,2})?") && Double.parseDouble(desiredDepositeAmount) >= desiredRentAmount){
			isValid = true;
		}
		return isValid;
	}

	/**
	 * validate owner id from the database
	 */
	@Override
	public boolean validateOwnerID(String ownerID, List<Integer> ownerIDList) {
		boolean isValid = false;
		try {
			int ownerIDInt = Integer.parseInt(ownerID);
			
			if (ownerIDList.contains(ownerIDInt))
				isValid = true;
			return isValid;
		} catch (NumberFormatException e) {
			return isValid;
		}
	}

	/**
	 * Takes flat info and pass it to DAO layer to added to databse
	 */
	@Override
	public boolean registerFlat(FlatRegistrationDTO flat) throws FlatRegisterationException {
		return flatRegisterationDao.registerFlat(flat);
	}

	
	/**
	 * Display all owner id by using DAO layer
	 */
	@Override
	public List<Integer> getAllOwnerIds() throws FlatRegisterationException {
		return flatRegisterationDao.getOwnerID();
	}
}
