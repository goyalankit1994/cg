package lab1;

public class EnumPerson {

	private String firstName;
	private String lastName;
	private String gender;
	private String  mobileNumber;
	
	public EnumPerson()
	{
		firstName="Ankit";
		lastName="Goyal";
		gender="male";
		mobileNumber="8239161121";
	}
	
	public EnumPerson(String firstName, String lastName, String gender,String mobileNumber) {
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.mobileNumber=mobileNumber;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	
	public void printDetails(){
		System.out.println("Person Details:\n");
		System.out.println("__________________\n");
		System.out.println("First Name: "+firstName);
		System.out.println("Last Name: "+lastName);
		System.out.println("Gender: "+gender);
		System.out.println("Mobile Number: "+mobileNumber);
	}

}

