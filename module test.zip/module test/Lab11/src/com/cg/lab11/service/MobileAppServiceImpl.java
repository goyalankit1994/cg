package com.cg.lab11.service;

import java.time.LocalDate;

import java.util.ArrayList;
import java.sql.Date;
import java.util.regex.Pattern;

import com.cg.lab11.dao.MobileAppDao;
import com.cg.lab11.dao.MobileDaoImpl;
import com.cg.lab11.dto.MobileAppBean;
import com.cg.lab11.dto.PurchaseDetailsBean;
import com.cg.lab11.exception.PurchaseOrderException;

public class MobileAppServiceImpl implements MobileAppService {

	MobileAppDao mobdao;
	public MobileAppServiceImpl()
	{
		mobdao=new MobileDaoImpl();
	}
	@Override
	public boolean purchaseMobile(PurchaseDetailsBean bean) throws PurchaseOrderException {
		// TODO Auto-generated method stub
		return mobdao.purchaseMobile(bean);
	}

	@Override
	public boolean updateMobileDb(PurchaseDetailsBean bean) throws PurchaseOrderException {
		// TODO Auto-generated method stub
		return mobdao.updateMobileDb(bean);
	}

	@Override
	public boolean searchMobile(int min, int max) throws PurchaseOrderException {
		// TODO Auto-generated method stub
		return mobdao.searchMobile(min,max);
	}

	@Override
	public ArrayList<MobileAppBean> getAllMobileRecords()
			throws PurchaseOrderException {
		// TODO Auto-generated method stub
		return mobdao.getAllMobileRecords();
	}
	@Override
	public boolean deleteMobile(int mobileId) throws PurchaseOrderException {
		// TODO Auto-generated method stub
		return mobdao.deleteMobile(mobileId);
	}
	@Override
	public boolean validation(PurchaseDetailsBean bean)
			throws PurchaseOrderException {
		String mailPattern="([0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,4})";
		String namePattern="[A-Z]{1}[a-zA-Z\\s]{1,20}";
		String mobPattern="[7-9]{1}[0-9]{9}";
		String mobIdPattern="[0-9]{4}";
		Date purchase_date= Date.valueOf(LocalDate.now());
		
		Pattern patternMail=Pattern.compile(mailPattern);
		Pattern patternName= Pattern.compile(namePattern);
		Pattern patternMob = Pattern.compile(mobPattern);
		Pattern patternMobId=Pattern.compile(mobIdPattern);
		System.out.println("HI "+purchase_date);
		System.out.println("BI "+bean.getPurchaseDate());
		System.out.println();
		if(!patternMail.matches(mailPattern, bean.getMailid()))
			System.out.println("MAIL ID NOT VALID");
		else if(!patternMob.matches(mobPattern, bean.getMobilenumber()))
				System.out.println("NOT VALID MOBILE NUMBER");
		else if(!patternMobId.matches(mobIdPattern, String.valueOf(bean.getMobileid())))
			System.out.println("Not Valid Mobile ID");
		else if(!patternName.matches(namePattern, bean.getCname()))
			System.out.println("NOT VALID NAME ");
		else if(purchase_date.compareTo(bean.getPurchaseDate())!=0)
				System.out.println("Date Should Be current Date ");
		else
			return true;
		
		
		return false;
	}
	@Override
	public void setDao(MobileAppDao dao) {
		// TODO Auto-generated method stub
		this.mobdao = dao;
		
	}
    
}
