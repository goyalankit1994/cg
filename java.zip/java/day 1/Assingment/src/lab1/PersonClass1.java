package lab1;

public class PersonClass1 {
	private String fname;
	private String lname;
	private String gender;
	public PersonClass1()
	{
		fname="ankit";
		lname="goyal";
		gender="male";
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public PersonClass1(String name1,String name2,String name3)
	{
		fname =name1;
		lname = name2;
		gender=name3;
		
	}
}
