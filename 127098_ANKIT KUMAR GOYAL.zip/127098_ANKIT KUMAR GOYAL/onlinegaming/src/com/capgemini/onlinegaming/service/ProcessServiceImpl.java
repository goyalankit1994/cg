package com.capgemini.onlinegaming.service;

import java.util.List;

import com.capgemini.onlinegaming.bean.GameBean;
import com.capgemini.onlinegaming.bean.UsersBean;
import com.capgemini.onlinegaming.dao.ProcessDao;
import com.capgemini.onlinegaming.dao.ProcessDaoImpl;
import com.capgemini.onlinegaming.exception.GameException;


public class ProcessServiceImpl implements ProcessService {
ProcessDao dao;
	
	public ProcessServiceImpl()
	{
		dao = new ProcessDaoImpl();
	}

	@Override
	public long insertUser(UsersBean bean) throws GameException {
		
		return dao.insertUser(bean);
	}

	@Override
	public List<GameBean> getAllRecord() throws GameException {
		// TODO Auto-generated method stub
		return dao.getAllRecord();
	}

	@Override
	public int CalculateleftBalance(int cardBalance, int gameAmount)
			throws GameException {
		if(cardBalance<gameAmount) throw new GameException("insufficient balance");
		return (cardBalance-gameAmount);
	}
	

}
