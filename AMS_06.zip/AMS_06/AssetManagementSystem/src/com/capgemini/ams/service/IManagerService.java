package com.capgemini.ams.service;

import com.capgemini.ams.exception.AssetException;

public interface IManagerService {

	int raiseRequest(int assetId, int quantity, int mgrCode, int empNum) throws AssetException;

}
