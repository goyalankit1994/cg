package com.capgemini.cab.dao;

import java.sql.SQLException;

import com.capgemini.cab.exception.CabException;
import com.capgemini.cabs.bean.CabRequest;
public interface ICabRequestDAO {
	Boolean addCabRequestDetails(CabRequest cabRequest) throws CabException,
	SQLException ;
	CabRequest getRequestDetails(int requestId) throws CabException ,SQLException;
}
