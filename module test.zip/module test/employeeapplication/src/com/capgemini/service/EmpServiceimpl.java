package com.capgemini.service;

import java.util.List;
import java.util.Properties;

import com.capgemini.dao.EmpDAO;
import com.capgemini.dao.EmpDAOJdbcimpl;
import com.capgemini.dao.EmpDAOimpl;
import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;
import com.capgemini.util.Config;

public class EmpServiceimpl implements EmpService {
	
	EmpDAO eDao;
	Config config = new Config();
	
	public EmpServiceimpl() {
		Properties props = config.getProps();
		String choice = (String) props.get("CHOICE");
		System.out.println(choice);
		if(choice.equals("DATABASE"))
			eDao = new EmpDAOJdbcimpl();
		else
			eDao = new EmpDAOimpl();
	}

	@Override
	public boolean validateName(String name) {
		
		return name.matches("[A-Z][A-Za-z]*");
	}

	@Override
	public boolean saveEmp(Emp emp) throws EmpException {
		boolean saved = false;
		saved = eDao.saveEmp(emp);
		return saved;
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		return eDao.getEmpList();
	}

	@Override
	public void closeReaderWriter() throws EmpException {
		eDao.closeReaderWriter();
	}

	@Override
	public boolean deleteEmp(int id) {
		return eDao.deleteEmp(id);
	}

	@Override
	public boolean validateDesignation(String designation) {
			return designation.matches("([A-Za-z][\\s][A-Za-z])+");
	}

	@Override
	public boolean validateSalary(String next) {
		if ( next.matches("[0-9]{1,8}([.][0-9]{1,2})?"))
			return true;
		else
			return false;
	}
}
