package lab9;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestCase {
	Person person = new Person("Ankit","goyal");
	@Before
	public void setUp() throws Exception {
	System.out.println("Before Test");
	}


	@Test
	public void testGetFirstName() {
		String firstName = null;
		firstName = person.getFirstName();
		assertEquals("Ankit",firstName);
		System.out.println(firstName);
		}

	@Test
	public void testSetFirstName() {
		String firstName="Ankit";
		person.setFirstName(firstName);
		assertEquals("Ankit", person.getFirstName());
	}

	

	@Test
	public void testGetLastName() {
		String LastName = null;
		LastName = person.getLastName();
		assertEquals("goyal",LastName);
		System.out.println(LastName);
		}
	

	@Test
	public void testSetLastName() {
	String LastName = "goyal";
	person.setLastName(LastName);
	assertEquals("goyal",person.getLastName());
	
	}

}
