package lab7;

import java.util.ArrayList;
import java.util.Collections;

public class ProductNamesArrayList {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		list.add("soap");
		list.add("cake");
		list.add("apple");
		list.add("bottle");
		list.add("pencil");

		System.out.println("Before sorting");
		for (String str1 : list) {
			System.out.println(str1);}
			Collections.sort(list);
			System.out.println("AFTER SORT");
			for (String str : list) {
				System.out.println(str);
			

		}
	}
}
