package com.cg.transportdetails.pl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;








import javax.naming.TimeLimitExceededException;
import javax.swing.text.DateFormatter;

import com.cg.transportdetails.dto.BookingBean;
import com.cg.transportdetails.dto.TruckBean;
import com.cg.transportdetails.exception.TransportException;
import com.cg.transportdetails.service.TransportDetails;
import com.cg.transportdetails.service.TransportDetailsServiceImpl;

public class Client {

	static TransportDetails tsd=new TransportDetailsServiceImpl();
	public static void main(String[] args) {
		int choice =0;
//		Scanner sc = new Scanner(System.in);
		try(BufferedReader read=new BufferedReader(new InputStreamReader(System.in)))
		{
				do
				{
					System.out.println("1. Book Truck");
					System.out.println("2. Exit");
					System.out.println("enter your choice");
					choice = Integer.parseInt(read.readLine());
					switch(choice)
					{
					
					case 1:
							List<TruckBean> list = new ArrayList<TruckBean>();
							
							System.out.println("Enter the Customer Id ");
							String custId=read.readLine();
							if(tsd.validation(custId))
							{
								BookingBean bean = new BookingBean();
								bean.setCustId(custId);
								list=tsd.retrieveTransportDetails();
								for(TruckBean obj:list)
									System.out.println(obj);
								System.out.println("Enter the Truck ID ");
								bean.setTruckId(Integer.parseInt(read.readLine()));
								System.out.println("Enter Number Of Turcks");
								bean.setNoOfTruck(Integer.parseInt(read.readLine()));
								System.out.println("Enter Customer Mobile ");
								bean.setCustMobile(Long.parseLong(read.readLine()));
								//System.out.println("Date of transportaion");
								DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
								System.out.println("enter date ");
								String input = read.readLine();
								LocalDate date = LocalDate.parse(input, format);
								bean.setDateOfTransport(date);
	//							if(tsd.validation(bean))
	//							{
								int id=tsd.bookTrucks(bean);
								if(id!=0)
									System.out.println("Thanku Booking ID is "+bean.getTruckId());
								else
									throw new TransportException("Validation not sucess");
							}
							else 
								System.out.println("CustomerId not Valid");
							break;
					case 2:
							break;
						
					}
				}while(choice!=0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
  }
}
