import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;


public class LamdaClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Supplier<String>ref = ()->"Hello World";
System.out.println(ref.get());
//String str = "Hello";
Predicate<String>pre = (str)->(str.length()>0);// return boolean
System.out.println(pre.test("Hello"));
Consumer<String>con=(str)->System.out.println(str);// return string
con.accept("Capgemini");
Function<String,Integer>fun = (str)->(str.length()); // taking string return integer
System.out.println(fun.apply("Capgemini"));
	}

}
