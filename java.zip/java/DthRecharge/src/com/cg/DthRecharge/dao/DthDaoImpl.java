package com.cg.DthRecharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.DthRecharge.Exception.DthException;
import com.cg.DthRecharge.dbutil.DbUtil;
import com.cg.DthRecharge.dto.DthRechargeBean;



public class DthDaoImpl implements DthDao{
	Connection con;
	public DthDaoImpl()
	{
	con =  DbUtil.getConnection();
	}
	
	public DthRechargeBean getRecord(int userid) throws DthException {
		DthRechargeBean bean = null;
		try
		{
		String sql = "SELECT * FROM Dth WHERE userid = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1,userid);
		ResultSet result = pstmt.executeQuery();
		bean = new DthRechargeBean();
		if(result.next())
		{
			bean = new DthRechargeBean();
			bean.setUserid(result.getInt(1));
			bean.setName(result.getString(2));
			bean.setBalance(result.getInt(3));
			bean.setMobileno(result.getString(4));
			
		}
		else
			throw new DthException("Dth with id"+userid+ "not found");
		}
		catch(SQLException e)
		{
			throw new DthException(e.getMessage());
		}
		return bean;
	}


	@Override
	public boolean Recharge() throws DthException {
		try
		{
		String sql="Update dth set balance = balance-? where userid = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		Scanner sc=new Scanner(System.in);
		System.out.println("enter recharge amount");
		int amount = sc .nextInt();
		System.out.println("enter user id");
		int id=sc.nextInt();
		int c = CheckBalance(id);
		if(c<amount)
		{
			System.out.println("recharge amount is more than balance");
		}
		else
		{
		pstmt.setInt(2,id);
		pstmt.setInt(1,amount);
		int row = pstmt.executeUpdate();
		if(row== 0)
		{
			throw new DthException("unable to update");
		}
			}}
		
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		return false;
	
	}
	@Override
	public int CheckBalance(int userid) throws DthException {
		DthRechargeBean bean =null;
		int c=0;
		try
		{
			String sql="select balance from dth where userid =?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,userid);
			ResultSet result = pstmt.executeQuery();
			if(result.next())
			{
				bean = new DthRechargeBean();
				c=result.getInt(1);
			}
			else
			{
				throw new DthException("user id not found");
				}
		}
		catch(SQLException e )
		{
			System.out.println(e.getMessage());
		}
		return c;
	}
}
	
	
	
	

