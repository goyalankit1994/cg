package com.capgemini.dao;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.apache.log4j.Logger;

import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;
import com.capgemini.util.FileUtil;

public class EmpDAOimpl implements EmpDAO {

	Logger logger = Logger.getLogger(EmpDAOimpl.class);
	
	@Override
	public boolean saveEmp(Emp emp){
		boolean saved = false;
		ObjectOutputStream fUtil = FileUtil.getWriter();
		try {
			fUtil.writeObject(emp);
			saved = true;
			logger.info("Saved Objects : " + emp);
			
		} catch (IOException e) {
			//e.printStackTrace();
			logger.error("Failed to write object" + e);
		}
		finally{
			FileUtil.closeWriter();
		}
		return saved;
	}

	@Override
	public Emp getEmp() throws EmpException {
		Emp e = null;
		ObjectInputStream ois = FileUtil.getReader();
		try {
			e = (Emp) ois.readObject();
			logger.info("Object Read" + e);
		} catch (ClassNotFoundException e2) {
			//e2.printStackTrace();
			logger.info("Failed to read object " + e2);
			throw new EmpException("File Not Found");
		} catch (IOException e2) {
			throw new EmpException("Error creating Emp object from file");
		}
		finally{
			FileUtil.closeReader();
		}
		return e;
	}

}
