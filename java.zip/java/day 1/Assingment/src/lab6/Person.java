package lab6;

public class Person {
	String fname;
	String lname;
	String gender;
	String mobileno;

	public Person(String fname, String lname, String gender, String mobileno)
			throws PersonException {
		if (fname.equals(""))
			throw new PersonException("first name is empty");
		else
			this.fname = fname;
		if (lname.equals(""))
			throw new PersonException("last name is empty");
		else
			this.lname = lname;
		this.gender = gender;
		this.mobileno = mobileno;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	@Override
	public String toString() {
		return "Person [fname=" + fname + ", lname=" + lname + ", gender="
				+ gender + ", mobileno=" + mobileno + "]";
	}

}
