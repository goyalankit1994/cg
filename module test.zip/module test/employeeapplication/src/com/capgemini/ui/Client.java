package com.capgemini.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.exception.EmpException;
import com.capgemini.service.EmpService;
import com.capgemini.service.EmpServiceimpl;
import com.capgemini.to.Emp;

public class Client {

	static Scanner scan = new Scanner(System.in);
	static EmpService eService = new EmpServiceimpl();
	static boolean execute = true;

	public static void main(String[] args) {

		while (execute) {
			System.out.println("\nChoose option from below");
			System.out.println("1. save employee");
			System.out.println("2. Display Employee");
			System.out.println("3. Delete Employee");
			System.out.println("4. Exit");
			String choice = scan.next();
			executeCaseChoice(choice);
		}
	}

	private static void executeCaseChoice(String choice) {
		// TODO Auto-generated method stub
		Emp emp = null;
		switch (choice) {
		case "1":
			System.out.println("***Save an Employee**");
			System.out.println("Enter Employee Details : ");
			System.out.println("Enter ID :");
			int id;

			String name = null;
			String designation = null;
			Double salary = null;
			do {
				scan.nextLine();
				try {
					id = Integer.parseInt(scan.next());
					break;
				} catch (NumberFormatException e) {
					System.out.println("Enter Number Only");
					// scan.nextLine();
				}
			} while (true);

			boolean isValid = false;
			while (!isValid) {
				System.out.println("Enter Name :");
				scan.nextLine();
				name = scan.next();
				isValid = eService.validateName(name);
				if (!isValid)
					System.out
							.println("Name should start with uppercase and have alphabets only");

			}

			isValid = false;
			while (!isValid) {
				System.out.println("Enter Designation");
				scan.nextLine();
				designation = scan.nextLine();
				isValid = eService.validateDesignation(designation);
				if (!isValid)
					System.out.println("No Space and Numbers Allowed");
			}

			isValid = false;
			while (!isValid) {
				String next;
				System.out.println("Enter Salary : ");
				scan.nextLine();
				next = scan.next();
				isValid = eService.validateSalary(next);
				if (!isValid)
					System.out.println("Enter Valid Salary");
				else
					salary = Double.parseDouble(next);
			}
			// System.out.println("<ID> <Name> <Designaion> <Salary>");
			emp = new Emp(id, name, designation, salary);
			boolean saved = false;
			try {
				saved = eService.saveEmp(emp);
			} catch (EmpException e1) {
				// TODO Auto-generated catch block
				System.out.println(e1.getMessage());
			}
			if (saved) {
				System.out.println("Emp Saved");
				saved = false;
			} else
				System.out.println("Sorry...Emp could not be saved");
			break;

		case "2":
			List<Emp> emplist = null;
			try {
				emplist = eService.getEmpList();
			} catch (EmpException e) {
				System.out.println(e.getMessage());
				break;
			}
			System.out.println("\n\n******Employee Details******\n" + emplist);
			break;

		case "3":
			System.out.println("***Delete Employee Details**");
			System.out.println("Enter Employee Details : ");
			System.out.println("Enter ID :");
			do {
				try {
					id = Integer.parseInt(scan.next());
					break;
				} catch (NumberFormatException e) {
					System.out.println("Enter Number Only");
					// scan.nextLine();
				}
			} while (true);

			saved = eService.deleteEmp(id);

			if (saved) {
				System.out.println("Employee Deleted");
			} else{
				System.out.println("No Record Found with EmpID : " + id);
			}

			break;

		case "4":
			System.out.println("Thank for using this application");
			execute = false;
			try {
				eService.closeReaderWriter();
			} catch (EmpException e) {
				System.out.println(e.getMessage());
			}
			break;

		default:
			System.out.println("invalid choice");
			break;
		}
	}

}
