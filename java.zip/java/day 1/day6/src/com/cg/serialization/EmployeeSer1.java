package com.cg.serialization;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException; 
import java.io.ObjectOutputStream;

public class EmployeeSer1 {

	public static void main(String[] args) {
		FileOutputStream fout =null;
		ObjectOutputStream bout = null;
		File file = new File("serl.txt");
		try
		{
			fout = new FileOutputStream(file);
			bout = new ObjectOutputStream(fout);
			Employee emp = new Employee(101,"parag",50000);
			bout.writeObject(emp);
			bout.flush();
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			try{
				bout.close();
				fout.close();
				
			}
			catch(IOException e)
			{
				System.out.println(e.getMessage());
			}
		}

	}

}
