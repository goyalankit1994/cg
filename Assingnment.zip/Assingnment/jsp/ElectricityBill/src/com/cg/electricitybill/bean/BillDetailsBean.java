package com.cg.electricitybill.bean;

import java.util.Date;

public class BillDetailsBean {
	private int bill_num;
	private ConsumersBean con_num;
	private double curr_reading;
	private double unit_consumed;
	private double net_amount ;
	private Date bill_date;
	public int getBill_num() {
		return bill_num;
	}
	public void setBill_num(int bill_num) {
		this.bill_num = bill_num;
	}
	public ConsumersBean getCon_num() {
		return con_num;
	}
	public void set(ConsumersBean con_num) {
		this.con_num = con_num;
	}
	public double getCurr_reading() {
		return curr_reading;
	}
	public void setCurr_reading(double curr_reading) {
		this.curr_reading = curr_reading;
	}
	public double getUnit_consumed() {
		return unit_consumed;
	}
	public void setUnit_consumed(double unit_consumed) {
		this.unit_consumed = unit_consumed;
	}
	public double getNet_amount() {
		return net_amount;
	}
	public void setNet_amount(double net_amount) {
		this.net_amount = net_amount;
	}
	public Date getBill_date() {
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}
	@Override
	public String toString() {
		return "BillDetailsBean [bill_num=" + bill_num + ", con_num=" + con_num
				+ ", curr_reading=" + curr_reading + ", unit_consumed="
				+ unit_consumed + ", net_amount=" + net_amount + ", bill_date="
				+ bill_date + "]";
	}
	public BillDetailsBean() {
		super();
	}
	

}
