package day1;

public class employee {

}
