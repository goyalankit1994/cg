package com.cg.dao;

import com.cg.bean.ComplaintBean;
import com.cg.exception.BankException;



public interface ICustomerDao {
	public ComplaintBean raiseCustomerComplaint(ComplaintBean bean) throws BankException;
	public ComplaintBean checkComplaintStatus(int complaintid) throws BankException;
	public int getComplaintId(ComplaintBean bean) throws BankException;
	

}
