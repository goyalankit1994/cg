package com.cg.tatasky.service;

import com.cg.tatasky.dto.TataSkyBean;
import com.cg.tatasky.exception.TataSkyException;

public interface TataSkyService {
	
	public TataSkyBean getRecord(int patientId)
			throws TataSkyException;
	
	public boolean rechargeTatasky(int id, int amount) throws TataSkyException;

}
