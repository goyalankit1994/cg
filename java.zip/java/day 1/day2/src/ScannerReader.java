import java.util.Scanner;
public class ScannerReader {

	public static void main(String[] args) {
		String str = "Hello all welcome";
		Scanner sc =  new Scanner(str);
	long len = str.length();
	int i =0;
		while(i<len)
		{
		System.out.println(sc.next());
		i++;
		}
	}

}
