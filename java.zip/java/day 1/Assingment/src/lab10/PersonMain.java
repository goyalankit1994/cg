package lab10;

import java.util.Properties;

public class PersonMain {
	static Config config=new Config();
	public static void main(String[] args) {
		Properties props = config.getProps();
		String choice =(String)props.get("Id");
		Person p = new Person(Integer.parseInt(choice),(String)props.get("Name"));
		System.out.println(p);
		

	}

}
