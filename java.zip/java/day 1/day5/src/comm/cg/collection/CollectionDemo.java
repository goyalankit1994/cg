package comm.cg.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

public class CollectionDemo {

	public static void main(String[] args) {
	HashMap set = new HashMap();
	//HashSet set = new HashSet();
		//TreeSet set = new TreeSet(); //  will sort element
		//ArrayList set = new ArrayList(); // not sorted but orderd
		//Vector set = new Vector(); //orderd but not sorted
//	set.add(10); // set.add(new Integer(11))
//	set.add(5);
//	set.add(15);
//	set.add(01);      //treeset.,hashset,arraylist,vector set
//	set.add(100);
	set.put(1,"abc");
	set.put(2,"xyz");   //input for all hashmap,treemap
	set.put(3, "lmn");
	System.out.println(set);
	Set keys = set.keySet();
	Iterator keyref = keys.iterator();
	while (keyref.hasNext())
	{
		Integer key = (Integer)keyref.next();
		String val = (String) set.get(key);
		System.out.println("key =" + key + " & " + " value ="+ val);
	}
//	while
//	Iterator ref = set.iterator();
//	while(ref.hasNext())
//	{
//		System.out.println(ref.next());
//	}
	}

}
