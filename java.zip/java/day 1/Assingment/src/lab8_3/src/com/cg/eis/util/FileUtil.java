package com.cg.eis.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtil {
BufferedWriter bw;
	
	public BufferedWriter getBufferedWriter() {
		if ( bw == null){
			try {
				bw = new BufferedWriter(new FileWriter("Employee.txt",true));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bw;
	}

}

