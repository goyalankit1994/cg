package com.capgemini.ams.service;

import java.util.ArrayList;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.dao.IAMSDao;
import com.capgemini.ams.exception.AssetException;

public interface IAMSService {

	ArrayList<Asset> showAllAssets() throws AssetException;

	boolean validateAssetId(int assetId) throws AssetException;

	boolean checkQuantity(int quantity, int assetId) throws AssetException;

	ArrayList<AssetRequest> showAllRequests() throws AssetException;

	boolean validateRequestId(int requestId)throws AssetException;
	
	AssetRequest getRequestDetails(int requestId) throws AssetException;

	Asset getAssetDetailsById(int assetid)throws AssetException;

	boolean checkAssetId(int assetId) throws AssetException;

	boolean checkValidQuant(int quantity) throws AssetException;

	boolean validateEmpNum(int empNum) throws AssetException;

	boolean validateName(String assetName);

	boolean validateAssetDesc(String assetDesc);
	
}
