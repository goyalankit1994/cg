package com.cg.tatasky.exception;

@SuppressWarnings("serial")
public class TataSkyException extends Exception {
String msg;
	public TataSkyException(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return msg;
	}
	
}
