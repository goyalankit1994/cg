package com.cg.MobileSeller.Exception;

public class MobileException extends Exception {
	String message;
	public MobileException(String message)
	{
		this.message=message;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}

	}
