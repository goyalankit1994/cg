package com.cg.onlineshopping.bean;

public class Customer {

	private String custName;
	private int custId;
	
	public Customer()
	{
		
	}
	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", custId=" + custId + "]";
	}
	
}
