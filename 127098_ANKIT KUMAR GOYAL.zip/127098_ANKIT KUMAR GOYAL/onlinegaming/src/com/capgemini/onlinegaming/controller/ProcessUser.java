package com.capgemini.onlinegaming.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.onlinegaming.bean.GameBean;
import com.capgemini.onlinegaming.bean.UsersBean;
import com.capgemini.onlinegaming.exception.GameException;
import com.capgemini.onlinegaming.service.ProcessService;
import com.capgemini.onlinegaming.service.ProcessServiceImpl;


/**
 * Servlet implementation class ProcessUser
 */
@WebServlet("/ProcessUser")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
ProcessService service;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessUser() {
    	service = new ProcessServiceImpl();
       
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		String qStr = request.getParameter("action");
		if("home".equals(qStr))
		{
			UsersBean bean = new UsersBean();
			bean.setName(request.getParameter("name"));
			bean.setAddress(request.getParameter("address"));
			int amt = Integer.parseInt(request.getParameter("amount"));
			int amount = amt-100 ; 
			bean.setCard_amt(amount);
			long user;
			try
			{
				user=service.insertUser(bean);
				session.setAttribute("users", user);
					RequestDispatcher dispatch = request.getRequestDispatcher("play.jsp");
					dispatch.forward(request, response);
			}
			catch(GameException e)
			{
				response.sendRedirect("topup.jsp");
			}
		
		}
		String qStr1 = request.getParameter("action");
		if("play".equals("action"))
		{
			response.sendRedirect("Success.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		String qStr = request.getParameter("action");
		if("home".equals(qStr))
		{
			try
			{
				List<GameBean>list=service.getAllRecord();
				if(list.size()!=0)
				{
					System.out.println(list);
					request.setAttribute("map", list);
					RequestDispatcher dispatch = 
							request.getRequestDispatcher("play.jsp");
					dispatch.forward(request, response);
				}
				
			}
			catch(GameException e)
			{
				response.sendRedirect("topup.jsp");
			}
			
		}
	}

}
