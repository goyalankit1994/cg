package comm.cg.collection;

public class Student implements Comparable {
	int id;
	String name;
	Student(int id,String name)
	{
		this.id = id;
		this.name=name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
public int compareTo(Object arg0)     // to comapre or sort with respect to id 
{
	int diff= 0;
	if(arg0 instanceof Student)
	{
		Student ref = (Student)arg0;
		diff = this.id - ref.id;
	}
	return diff;
}
//	public int compareTo(Object arg0)  //to sort with respect to names
//	{
//		int diff= 0;
//		if(arg0 instanceof Student)
//		{
//			Student ref = (Student)arg0;
//			diff = this.name .compareTo(ref.name);
//		}
//		return diff;
//	}
}
