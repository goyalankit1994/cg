package com.capgemini.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;
import com.capgemini.util.FileUtil;

public class EmpDAOimpl implements EmpDAO {

	private BufferedWriter bw;
	private BufferedReader br;
	Logger logger = Logger.getLogger(EmpDAOimpl.class);
	
	@Override
	public boolean saveEmp(Emp emp) throws EmpException{
		boolean saved = false;
		bw = FileUtil.getBufferedWriter();
		try {
			bw.write(emp.getId() + "," + emp.getName() + "," + emp.getDesignation() + "," + emp.getSalary());
			bw.newLine();
			bw.flush();
			saved = true;
			logger.info("Saved Objects : " + emp);
			
		} catch (IOException e) {
			//e.printStackTrace();
			logger.error("Failed to write object" + e);
		}
		return saved;
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		List<Emp> elist = new ArrayList<Emp>();
		br = FileUtil.getBufferedReader();
		String record = null;
		try {
			while((record = br.readLine()) != null){
				String[] values = record.split(",");
				Emp emp = new Emp(Integer.parseInt(values[0]), values[1],values[2], Double.parseDouble(values[3]));
				logger.info("Object Read" + emp);
				elist.add(emp);
				logger.info("Object "+ emp + " added to " + elist);
			}
		} catch (IOException e2) {
			throw new EmpException("Error creating Emp object from file");
		}
		return elist;
	}

	@Override
	public void closeReaderWriter() throws EmpException {
		try {
			bw.close();
			logger.info("Writer Closed");
		} catch (IOException e) {
			logger.error("Writer cannot be closed" + e);
			throw new EmpException("Writer cannot be closed");
		}
		try {
			br.close();
			logger.info("Reader Closed");
		} catch (IOException e) {
			logger.error("Reader cannot be closed" + e);
			throw new EmpException("Reader cannot be closed");
		}
	}

	@Override
	public boolean deleteEmp(int id) {
		// TODO Auto-generated method stub
		return false;
	}
}
