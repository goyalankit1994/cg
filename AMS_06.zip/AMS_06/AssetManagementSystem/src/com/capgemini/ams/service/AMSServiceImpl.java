package com.capgemini.ams.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.dao.AMSDaoImpl;
import com.capgemini.ams.dao.IAMSDao;
import com.capgemini.ams.exception.AssetException;

public class AMSServiceImpl implements IAMSService{
	
	IAMSDao amsDao;
	
	
	public void setDao(IAMSDao amsDao) {
		// TODO Auto-generated method stub
		this.amsDao = amsDao;
	}
	
	public AMSServiceImpl() {
		// TODO Auto-generated constructor stub
		amsDao  = new AMSDaoImpl();
	}
	
	@Override
	public ArrayList<Asset> showAllAssets() throws AssetException{
		// TODO Auto-generated method stub
		return amsDao.showAllAssets();
	}

	@Override
	public boolean validateAssetId(int assetId) throws AssetException {
		// TODO Auto-generated method stub
		return amsDao.validateAssetId(assetId);
	}

	@Override
	public boolean checkQuantity(int quantity, int assetId)
			throws AssetException {
		// TODO Auto-generated method stub
		return amsDao.checkQuantity( quantity, assetId);
	}

	@Override
	public ArrayList<AssetRequest> showAllRequests() throws AssetException {
		// TODO Auto-generated method stub
		return amsDao.showAllRequests();
	}

	@Override
	public boolean validateRequestId(int requestId) throws AssetException {
		// TODO Auto-generated method stub
		return amsDao.validateRequestId(requestId);
	}

	@Override
	public AssetRequest getRequestDetails(int requestId) throws AssetException {
		// TODO Auto-generated method stub
		return amsDao.getRequesDetails(requestId);
	}

	@Override
	public Asset getAssetDetailsById(int assetid) throws AssetException {
		// TODO Auto-generated method stub
		return amsDao.getAssetDetailsById(assetid);
	}

	@Override
	public boolean checkAssetId(int assetId) throws AssetException {
		// TODO Auto-generated method stub
	
		String strAssetId = String.valueOf(assetId);
		
		return strAssetId.matches("[0-9]{4}");
	}

	@Override
	public boolean checkValidQuant(int quantity) throws AssetException {
		// TODO Auto-generated method stub

		String strQuant = String.valueOf(quantity);
		
		return strQuant.matches("[0-9]{1,8}");
	}

	@Override
	public boolean validateEmpNum(int empNum) throws AssetException {
		// TODO Auto-generated method stub
		String strEmpNum = String.valueOf(empNum);
		
		return strEmpNum.matches("[0-9]{6}");
	}

	@Override
	public boolean validateName(String assetName) {
		// TODO Auto-generated method stub
		return assetName.matches("[A-Za-z]{2,25}");
	}

	@Override
	public boolean validateAssetDesc(String assetDesc) {
		// TODO Auto-generated method stub
		return assetDesc.matches("[A-Za-z]{2,25}");
	}

	
	
}
