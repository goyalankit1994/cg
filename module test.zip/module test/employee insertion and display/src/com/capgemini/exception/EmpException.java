package com.capgemini.exception;

public class EmpException extends Exception {

	public EmpException(String string) {
		super(string);
	}
	
}
