package com.capgemini.ams.service;

import com.capgemini.ams.exception.AssetException;

public interface IAuthenticationService {

	boolean validateUserName(String userName) throws AssetException;

	boolean validatePassword(String password) throws AssetException;

	String getUserType(String userName, String password) throws AssetException;

	int getMgrCode(String userName, String password) throws AssetException;
}
