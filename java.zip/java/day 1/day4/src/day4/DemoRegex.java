package day4;

import java.util.Scanner;
import java.util.regex.Pattern;

public class DemoRegex {

	public static void main(String[] args) {
		String pattern2 = "[a-z]{5}";
		String input = "hello";
		System.out.println(Pattern.matches(pattern2,input));
		String pattern1 = "[.//s/.//s]";
		String data = "hello how";
		System.out.println(Pattern.matches(pattern1,data));
		 String name = null;
		 Scanner sc =  new Scanner(System.in);
		 System.out.println("enter name");
		 
		 name = sc.next();
		 String patt = "[A-Z]{1}[a-z]{5}";
		 Pattern pattern = Pattern.compile(patt);
		 boolean match = Pattern.matches(patt, name);
		 if(match)
			 System.out.println("valide name");
		 else
			 System.out.println("not valid");

	}

}
