package com.cg.dto;

import java.sql.Date;

public class BillDetails {
	int bill_nu;
	int consu_num;
	int cur_reading;
	int unit_consumed;
	double net_amount;
	Date billdate;
	
	public  BillDetails(int bill_nu,int consu_num,int cur_reading,int unit_consumed,double net_amount,Date billdate)
	{
		this.bill_nu=bill_nu;
		this.consu_num = consu_num;
		this.cur_reading = cur_reading;
		this.unit_consumed = unit_consumed;
		this.net_amount = net_amount;
		this.billdate = billdate;
	}

	public int getBill_nu() {
		return bill_nu;
	}

	public void setBill_nu(int bill_nu) {
		this.bill_nu = bill_nu;
	}

	public int getConsu_num() {
		return consu_num;
	}

	public void setConsu_num(int consu_num) {
		this.consu_num = consu_num;
	}

	public int getCur_reading() {
		return cur_reading;
	}

	public void setCur_reading(int cur_reading) {
		this.cur_reading = cur_reading;
	}

	public int getUnit_consumed() {
		return unit_consumed;
	}

	public void setUnit_consumed(int unit_consumed) {
		this.unit_consumed = unit_consumed;
	}

	public double getNet_amount() {
		return net_amount;
	}

	public void setNet_amount(double net_amount) {
		this.net_amount = net_amount;
	}

	public Date getBilldate() {
		return billdate;
	}

	public void setBilldate(Date billdate) {
		this.billdate = billdate;
	}

	@Override
	public String toString() {
		return "BillDetails [bill_nu=" + bill_nu + ", consu_num=" + consu_num
				+ ", cur_reading=" + cur_reading + ", unit_consumed="
				+ unit_consumed + ", net_amount=" + net_amount + ", billdate="
				+ billdate + "]";
	}

}
