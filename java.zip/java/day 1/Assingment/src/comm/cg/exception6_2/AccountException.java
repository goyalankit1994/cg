package comm.cg.exception6_2;

public class AccountException extends Exception {

	String message;
	public AccountException(String msg)
	{
		this.message = msg;
	}
	public String getMessage() {
		return message;
	}
}

