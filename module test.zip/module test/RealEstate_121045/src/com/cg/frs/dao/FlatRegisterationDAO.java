package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegisterationException;
import com.cg.frs.util.DBUtil;
import com.cg.frs.util.Messages;

/**
 * 
 * @author Dushyant
 * @version 1.0
 * This DAO class for the Real Estate Project
 */

public class FlatRegisterationDAO implements IFlatRegisterationDAO {

	Connection conn;
	private String selectOwnerIDQuery = "select owner_id from flat_owners";
	private String insertRegisterFlatQuery = "insert into flat_registration values(flat_reg_no_seq.NEXTVAL,?,?,?,?,?)";
	Logger logger = Logger.getLogger(FlatRegisterationDAO.class);

	/**
	 * Return all owners id
	 */
	@Override
	public List<Integer> getOwnerID() throws FlatRegisterationException {
		conn = DBUtil.getConnection();
		List<Integer> ownerIDList = new ArrayList<Integer>();
		int flag = 0;
		try {
			Statement getOwnerStmt = conn.createStatement();
			ResultSet ownerIDRs = getOwnerStmt.executeQuery(selectOwnerIDQuery);
			while (ownerIDRs.next()){
				if ( flag == 0)
					flag = 1;
				ownerIDList.add(ownerIDRs.getInt(1));
			}
			if ( flag == 0 ){
				throw new FlatRegisterationException(Messages.NO_OWNER_ID_EXIST);
			}
			else{
				logger.info(Messages.OWNER_ID_READ_SUCCESSFUL);
			}
		} catch (SQLException e) {
			logger.error(Messages.ERROR_READING_VALUES + e);
			throw new FlatRegisterationException(Messages.ERROR_READING_VALUES);
		} finally {
			try {
				conn.close();
				logger.info(Messages.CONNECTION_TERMINATED);
			} catch (SQLException e) {
				logger.error(Messages.CONNECTION_CANNOT_BE_TERMINATED + e);
				throw new FlatRegisterationException(Messages.CONNECTION_CANNOT_BE_TERMINATED);
			}
		}
		return ownerIDList;
	}

	/**
	 * this insert values to database
	 */
	
	@Override
	public boolean registerFlat(FlatRegistrationDTO flat) throws FlatRegisterationException {
		boolean isAdded = false;
		conn = DBUtil.getConnection();
		try {
			PreparedStatement registerFlatPrepStmt = conn.prepareStatement(insertRegisterFlatQuery);
			registerFlatPrepStmt.setInt(1, flat.getOwnerID());
			registerFlatPrepStmt.setInt(2, flat.getFlatType());
			registerFlatPrepStmt.setInt(3, flat.getFlatArea());
			registerFlatPrepStmt.setDouble(4, flat.getRentAmount());
			registerFlatPrepStmt.setDouble(5, flat.getDepositeAmount());
			int rows = registerFlatPrepStmt.executeUpdate();
			if (rows>0){
				isAdded = true;
				logger.info(Messages.INSERTION_SUCCESSFUL);
			}
		} catch (SQLException e) {
			logger.error(Messages.ERROR_INSERTING_VALUES);
			throw new FlatRegisterationException(Messages.ERROR_INSERTING_VALUES);
		} finally {
			try {
				conn.close();
				logger.info(Messages.CONNECTION_TERMINATED);
			} catch (SQLException e) {
				logger.error(Messages.CONNECTION_CANNOT_BE_TERMINATED + e);
				throw new FlatRegisterationException(Messages.CONNECTION_CANNOT_BE_TERMINATED);
			}
		}
		return isAdded;
	}
}
