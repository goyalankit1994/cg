package comm.cg.exception6_2;

public class SavingAccount extends Account {
final double minBal=500;
	
	
	public SavingAccount(double bal,Person p)
	{
		super(bal,p);
	}
	
	
	@Override
	public void withdraw(double amount)
	{
		
		if(amount<getBalance()-minBal)
			this.setBalance(getBalance()-amount);
		else
			System.out.println("Not enough balance");
	}
}
