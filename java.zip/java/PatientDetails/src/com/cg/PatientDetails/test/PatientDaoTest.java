package com.cg.PatientDetails.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.PatientDeatils.dao.PatientDao;
import com.cg.PatientDeatils.dao.PatientDaoImpl;
import com.cg.PatientDetails.Exception.PatientException;
import com.cg.PatientDetails.Service.PatientService;
import com.cg.PatientDetails.Service.PatientServiceImpl;
import com.cg.PatientDetails.dto.PatientBean;

public class PatientDaoTest {
static PatientService service;
static PatientDao dao;
@Before
public void init()
{
	service = new PatientServiceImpl();
	dao = new PatientDaoImpl();
	service.setDao(dao);
}


	@Test
	public void testInsertDetails() {
		PatientBean bean = new PatientBean();
		bean.setPname("abc");
		bean.setAddress("mumbai");
		bean.setMobilenumber("8239161121");
		try
		{
		assertEquals(true,service.insertDetails(bean));
		}
		catch(PatientException e)
		{
			System.out.println(e.getMessage());
		}
	
	}

	@Test
	public void testGetRecord() throws PatientException {
		assertNotNull(service.getRecord(1001));
		
	}

	@Test
	public void testGetAllRecord() throws PatientException {
		assertNotEquals(0,service.getAllRecord().size());
	}

}
