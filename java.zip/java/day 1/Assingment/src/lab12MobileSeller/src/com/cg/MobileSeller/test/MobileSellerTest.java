package com.cg.MobileSeller.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.MobileSeller.Exception.MobileException;
import com.cg.MobileSeller.Service.MobileInterface;
import com.cg.MobileSeller.Service.MobileServiceImpl;
import com.cg.MobileSeller.dao.MobileDao;
import com.cg.MobileSeller.dao.MobileDaoImpl;
import com.cg.MobileSeller.dto.PurchaseBean;

public class MobileSellerTest {
	MobileDao dao;
	MobileInterface service;
	@Before
	public void init()
	{
		dao= new MobileDaoImpl();
		service = new MobileServiceImpl();
		service.setDao(dao);
		
	}
	@Test
	public void testSaveCust()
	{
		PurchaseBean bean = new PurchaseBean();
		bean.setCname("Ankit");
		bean.setMailid("goyalankit1994@gmail.com");
		bean.setMobileId(5452);
		bean.setPhoneno("8239161121");
		try {
			assertEquals(true,service.saveCust(bean));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testCheckMobileId() throws MobileException {
		assertNotEquals(false,service.getMobiles());
	}

}
