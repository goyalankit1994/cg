package com.capgemini.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class validateNameTest {

	String str;
	EmpService eService = new EmpServiceimpl();
	
	@Before
	public void setUp() throws Exception {
		str = "aviral";
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Test Done");
	}

	@Test
	public void test() {
		assertTrue(eService.validateName(str));
	}

}
