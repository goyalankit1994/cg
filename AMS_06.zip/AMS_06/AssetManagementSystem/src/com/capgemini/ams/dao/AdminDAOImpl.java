package com.capgemini.ams.dao;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.omg.CORBA.Request;

import com.capgemini.ams.DButil.DBUtil;
import com.capgemini.ams.DButil.QueryMapper;
import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetAllocation;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

public class AdminDAOImpl implements IAdminDAO {

	Connection con;
	Logger logger = Logger.getLogger(AdminDAOImpl.class);
	
	public AdminDAOImpl() {
		// TODO Auto-generated constructor stub
		con = DBUtil.getConnection();
	}

	@Override
	public boolean addAsset(Asset asset) throws AssetException {
		boolean flag = false;
		// TODO Auto-generated method stub
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.ADD_ASSETS);
			
			pstmt.setString(1, asset.getAssetName());
			pstmt.setString(2, asset.getAssetDesc());
			pstmt.setInt(3, asset.getQuantity());

			int rows = pstmt.executeUpdate();
			
			if (rows != 0) 
			{
				flag = true;
				logger.info("Asset "+asset.getAssetName()+" added successfully");
			} 
			else 
			{
				flag=false;
				logger.error("Asset "+asset.getAssetName()+" insertion unsuccessful");
				throw new AssetException("Assert not inserted");
			}
			
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			logger.error("SQL query execution failed");
			throw new AssetException("SQLException :" + e.getMessage());
		}

		return flag;
	}

	@Override
	public boolean updateAsset(int assetId, int quantity) throws AssetException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try {
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.UPDATE_ASSET);
			pstmt.setInt(1, quantity);
			pstmt.setInt(2, assetId);
			
			ResultSet result=pstmt.executeQuery();
			if(result.next())
			{
				flag=true;
				logger.info("Asset quantity for asset id "+assetId+" updated to "+quantity);
			}
			else
			{
				flag=false;
				logger.error("Quantity updation of asset id"+assetId+" failed");
				throw new AssetException("Updation Unsuccessful.");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution failed");
			throw new AssetException("SQLException : " +e.getMessage());
		}
		return flag;
	}

	@Override
	public boolean allocateAsset(int requestId,LocalDate releaseDate) throws AssetException {
		// TODO Auto-generated method stub
		boolean flag = false;
		
			try {
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.ASSET_ALLOCATE);
				AssetRequest request = getAssetRequest(requestId);
				
				pstmt.setInt(1, request.getAssetId());
				pstmt.setInt(2, request.getEmpNum());
				pstmt.setDate(3, Date.valueOf(releaseDate));
				
				int rows = pstmt.executeUpdate();
				
				if(rows!=0)
				{
					flag= true;
					logger.info("Asset successfully allocated to request id "+requestId);
				}
				else
				{
					flag = false;
					logger.error("Asset allocation unsuccessful for request id "+requestId);
					throw new AssetException("Asset Allocation Failed");
				}	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error("SQL query execution fail");
				throw new AssetException("SQLException : " +e.getMessage());
			}
		return flag;
	}

	private AssetRequest getAssetRequest(int requestId) throws AssetException{
		// TODO Auto-generated method stub
		AssetRequest request;
		try {
			
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.GET_REQUEST_DETAILS);
			pstmt.setInt(1, requestId);
			
			ResultSet result = pstmt.executeQuery();
			
			if(result.next())
			{
				request = new AssetRequest();
				request.setAssetId(result.getInt("ASSETID"));
				request.setEmpNum(result.getInt("EMPNUM"));
			}
			else
			{
				logger.error("Could not fetch the request for request id "+requestId);
				throw new AssetException("Asset request not found");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException : " +e.getMessage());
		}
		return request;
	}

	@Override
	public boolean updateStatus(int requestId) throws AssetException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try {
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.UPDATE_STATUS);
			pstmt.setInt(1, requestId);
			
			ResultSet result=pstmt.executeQuery();
			if(result.next())
			{
				flag=true;
				logger.info("Status of request id "+requestId+" changed to 'Allocated'");
			}
			else
			{
				flag=false;
				throw new AssetException("Status updation failed.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException : " +e.getMessage());
		}
		return flag;
	}

	@Override
	public boolean generateReport() throws AssetException {
		// TODO Auto-generated method stub
		boolean flag = false;
		
		ArrayList<AssetAllocation> assetAllocationList = new ArrayList<AssetAllocation>();
		
		try 
		{
			
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(QueryMapper.GET_ALL_ASSET_ALLOCATION_RECORDS);
			
			while(result.next())
			{
				AssetAllocation obj = new AssetAllocation();
				
				obj.setAllocationId(result.getInt("ALLOCATIONID"));
				obj.setAssetId(result.getInt("ASSETID"));
				obj.setEmpNum(result.getInt("EMPNUM"));
				obj.setAllocationDate(LocalDate.parse(result.getDate("ALLOCATION_DATE").toString()));
				obj.setReleaseDate(LocalDate.parse(result.getDate("RELEASE_DATE").toString()));
				
				assetAllocationList.add(obj);
			}
			
			exportToCSV(assetAllocationList);
			flag = true;
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException : " +e.getMessage());
		}
		return flag;
	}

	private void exportToCSV(ArrayList<AssetAllocation> assetAllocationList) throws AssetException{
		// TODO Auto-generated method stub
		
		try {
			
			FileWriter fos = new FileWriter("Asset_Allocation.csv");
			
			
			fos.write("AllocationId,AssetId,EmpNum,AllocationDate,ReleaseDate \n");
			
			for(AssetAllocation assetAllcoation : assetAllocationList)
			{
				fos.write(String.valueOf(assetAllcoation.getAllocationId()));
				fos.write(",");
				
				fos.write(String.valueOf(assetAllcoation.getAssetId()));
				fos.write(",");
				
				fos.write(String.valueOf(assetAllcoation.getEmpNum()));
				fos.write(",");
				
				fos.write(String.valueOf(assetAllcoation.getAllocationDate()));
				fos.write(",");
				
				fos.write(String.valueOf(assetAllcoation.getReleaseDate()));
				fos.write("\n");
				
				fos.flush();
				
			}
			fos.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File operation Exception"+e.getMessage());
		}

	}

}
