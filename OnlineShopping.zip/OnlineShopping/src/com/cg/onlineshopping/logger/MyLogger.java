package com.cg.onlineshopping.logger;

import java.io.IOException;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class MyLogger {
	static Logger logger = Logger.getLogger(MyLogger.class);
	static
	{
		SimpleLayout layout = new SimpleLayout();
		try {
		FileAppender appender = new FileAppender(layout,"P://module3/OnlineShopping/log.txt");
		logger.addAppender(appender);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
static public Logger getLoggerInstance()
{
	return logger;
}
}

