package com.capgemini.onlinegaming.dao;

import java.util.List;

import com.capgemini.onlinegaming.bean.GameBean;
import com.capgemini.onlinegaming.bean.UsersBean;
import com.capgemini.onlinegaming.exception.GameException;

public interface ProcessDao {
	long insertUser(UsersBean bean) throws GameException;
	public List<GameBean> getAllRecord() throws GameException;
	

}
