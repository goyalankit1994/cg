import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.frs.dao.FlatRegisterationDAO;
import com.cg.frs.dao.IFlatRegisterationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegisterationException;
import com.cg.frs.service.FlatRegisterationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;


public class RegisterFlatDaoTest {

	FlatRegistrationDTO flat;
	IFlatRegisterationDAO flatRegisterationDao;
	
	@Before
	public void setUp() throws Exception {
		flat = new FlatRegistrationDTO(1,2,6500,25000,50000);
		flatRegisterationDao = new FlatRegisterationDAO();
	}

	@Test
	public void test() throws FlatRegisterationException {
		boolean isValid = flatRegisterationDao.registerFlat(flat);
		assertTrue(isValid);
	}
}
