import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.FinanceException;
import com.capgemini.xyz.service.LoanService;

/**
 * 
 */

/**
 * @author Dushyant
 * @version 1.0
 * JUnit test for insertCust() in DAO layer
 *
 */
public class insertCustTest {

	Customer customer;
	ILoanDao loadDao;
	@Before
	public void setUp() throws Exception {
		
		//Valid Input
		customer = new Customer("Aviral","Mumabi",789456123); 
		
		//inValid Input
		//customer = new Customer("Mumabi",789456123);
		
		loadDao = new LoanDao();
	}

	@Test
	public void test() throws FinanceException {
		long id = loadDao.insertCust(customer);
		if ( id != 0){
			assertTrue(true);
		}
		else {
			assertTrue(false);
		}
	}

}
