package com.cg.eis.service;

import java.io.BufferedWriter;
import java.io.IOException;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmpDAO;
import com.cg.eis.util.FileUtil;

public class EmpDAOImpl implements EmpDAO {
	BufferedWriter bw;
	FileUtil fUtil;
	
	@Override
	public boolean writeEmployee(Employee emp) {
		fUtil = new FileUtil();
		boolean saved = false;
		bw = fUtil.getBufferedWriter();
		try {
			bw.write(emp.toString());
			bw.newLine();
			bw.close();
			saved = true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return saved;
	}

}
