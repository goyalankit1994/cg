package com.cg.tatasky.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.tatasky.dbutil.DbUtil;
import com.cg.tatasky.dto.TataSkyBean;
import com.cg.tatasky.exception.TataSkyException;

public class TataSkyDaoImpl implements TataSkyDao {
	
	Connection con;
	
	 public TataSkyDaoImpl() {
		// TODO Auto-generated constructor stub
		 con = DbUtil.getConnection();
	 }
	@Override
	public TataSkyBean getRecord(int userId) throws TataSkyException {
		// TODO Auto-generated method stub
		TataSkyBean bean= null;
		try
		{
//			System.out.println("hi");
			String sql = "SELECT * FROM tatasky WHERE USERId=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, userId);
			ResultSet result = pstmt.executeQuery();
//			System.out.println(result.next());
			if(result.next())
			{
				bean = new TataSkyBean();
				bean.setUserId(result.getInt(1));
				bean.setUserName(result.getString(2));
				bean.setMobileNumber(result.getString(3));
				bean.setBalance(result.getInt(4));
			}
			else
				throw new TataSkyException("Tata Sky Exception ");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
//			System.out.println(e.getMessage());
			
			
			 
			
		}
		return bean;
	}

	@Override
	public boolean rechargeTatasky(int id, int amount)throws TataSkyException {
		// TODO Auto-generated method stub
		
		boolean flag = false;
		try{
		String sql1="select balance from tatasky where userId=?";
		PreparedStatement pstmt1=con.prepareStatement(sql1);
		pstmt1.setInt(1, id);
		ResultSet res=pstmt1.executeQuery();
		
//			throw new TataSkyException("USESR ID NOT PRESENT");
			if(res.next())
			{
			int chkbal=res.getInt(1);
			if(chkbal<amount)
				System.out.println("BALANCE IS LOW ! YOUR BALANCE IS "+chkbal);
//		Scanner sc =new Scanner(System.in);
			else{
		String sql="Update tatasky set balance=balance-? where userId=?";
		
		PreparedStatement pstmt =con.prepareStatement(sql);
		System.out.println("Enter amount ");
//		int amt=sc.nextInt();
		pstmt.setInt(1, amount);
		pstmt.setInt(2, id);
		//ResultSet result= pstmt.executeQuery();
		
		int row1=pstmt.executeUpdate();
		//System.out.println("first     ");
		if(row1!=0)
			{System.out.println("Successfully Updated");
			flag = true;}
		else
			{
			System.out.println("Error");
			flag = false;
			}
//		sc.close();
		}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return flag;
			
	
	}
}
