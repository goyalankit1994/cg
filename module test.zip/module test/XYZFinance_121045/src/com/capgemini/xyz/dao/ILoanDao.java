package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.FinanceException;

public interface ILoanDao {

	long insertCust(Customer customer) throws FinanceException;

	long applyLoan(Loan loan) throws FinanceException;

}
