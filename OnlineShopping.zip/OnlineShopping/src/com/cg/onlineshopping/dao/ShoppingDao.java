package com.cg.onlineshopping.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.onlineshopping.bean.Customer;
import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.bean.Purchase;
import com.cg.onlineshopping.exception.ShoppingException;

public interface ShoppingDao {

	ArrayList<Product>getProducts(Customer bean)throws ShoppingException;  //to fetch
	HashMap<LocalDate,Product> purchaseProduct(int prodId,int custId)throws ShoppingException; //insert from database
	
}
