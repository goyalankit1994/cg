package com.cg.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;





import com.cg.contactbook.dbutil.DBUtil;
import com.cg.contactbook.dto.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.logger.MyLogger;

public class ContactBookDaoImpl implements ContactBookDao
{
	Logger logger = MyLogger.getLoggerInstance();
	Connection con;
	public ContactBookDaoImpl()
	{
		con = DBUtil.getConnection();
		if(con!=null)
		{
			logger.info("obtained connection");
		}
	}

	@Override
	public void addEnquiry(EnquiryBean enqry) throws ContactBookException,
			SQLException 
	{
		// TODO Auto-generated method stub
		Connection con = null;
		
		String query = "INSERT INTO enquiry VALUES(?,?,?,?,?,?)";
		try
		{	
			int id = ContactBookDaoImpl.getId();
			con=DBUtil.getConnection();
		
			PreparedStatement pt=con.prepareStatement(query);
			pt.setInt(1, id);
			pt.setString(2, enqry.getFname());
			pt.setString(3,enqry.getLname());
			pt.setString(4, enqry.getContactno());
			pt.setString(5, enqry.getpDomain());
			pt.setString(6, enqry.getpLocation());
			logger.info("inserted record"+enqry);
			pt.executeUpdate();
			
		
			System.out.println("  "+enqry.getFname()+" "+id+" ");
		}
		catch(ContactBookException | SQLException e)
		{
			logger.error("Exception occured"+e.getMessage());
			e.printStackTrace();
		}
	}



	@Override
	public EnquiryBean getEnquiryDetails(int Enquiryid)
			throws ContactBookException {
		// TODO Auto-generated method stub
		
		Connection con = null;
		EnquiryBean enqry = null;
		
		String queryThree="Select firstname,lastname,contactno,domain,city from enquiry where enqryid=?";
		
		try
		{
			con = DBUtil.getConnection();
			PreparedStatement ptsm=con.prepareStatement(queryThree);
			ptsm.setInt(1,Enquiryid);
			ResultSet res = ptsm.executeQuery();
			
			while(res.next())
			{
				enqry=new EnquiryBean();
				enqry.setFname(res.getString("firstname"));
				enqry.setLname(res.getString("lastname"));
				enqry.setContactno(res.getString("contactno"));
				enqry.setpDomain(res.getString("domain"));
				enqry.setpLocation(res.getString("city"));
				logger.info("fetch record"+enqry);
				
				
			}
			
		}
		catch(SQLException e)
		{
			logger.error("exception occured during get by id"+e.getMessage());
			e.printStackTrace();
		}
		return enqry;
	}
	public static int getId() throws ContactBookException,SQLException
	{
		// TODO Auto-generated method stub
		Connection con = null;
		String querySequence = "SELECT enqry.nextval from dual";
		int enqid=0;
		Statement st;
		try
		{
			con=DBUtil.getConnection();
			st=con.createStatement();
			ResultSet res=st.executeQuery(querySequence);
			
			while(res.next())
			{
				enqid=res.getInt(1);
				
			}
		}
		catch(SQLException e)
		{
			
			e.printStackTrace();
		}
		return enqid;
	}
}
