package com.capgemini.exception;

import javax.naming.NamingException;

public class EBillException extends Exception {

	public EBillException(String message) {
		super(message);
	}

	public EBillException(String message, Throwable cause) {
		super(message, cause);
		
	}
	
	
}
