package classesandobject;

public class Employee {
	static int cnt;
	private int empid;
	private String empname;
	//default constructor
	public Employee()
	{
		this.empid = 1;
		this.empname = "ankit";
		cnt++;
	}
	//parameterised constructor
	public Employee(int id,String name)
	{
		this.empid =empid;
		this.empname = empname;
		cnt++;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public static int getcnt()
	{
return cnt;
	}
	public static Employee CreateEmployee()
	{
		if(cnt==0)
		{
	return new Employee();
	}
		else
		{
			return null;
		}
}
}