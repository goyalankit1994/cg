package com.capgemini.service;

import com.capgemini.bean.Bean;

public interface IService {

	boolean insert(Bean bean);

}
