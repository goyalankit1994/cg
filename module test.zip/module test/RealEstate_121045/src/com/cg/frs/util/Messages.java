package com.cg.frs.util;


public class Messages {
	public static final String DB_CONN_ERROR = "Error connecting to Database";
	public static final String CLASS_NOT_FOUND_ERROR = "Class Driver cannot be loaded";
	public static final String CONNECTION_CANNOT_BE_TERMINATED = "Connecton Cannot be Terminated";
	public static final String NO_OWNER_ID_EXIST = "No Owner ID Exist in Database";
	public static final String CONNECTION_ESTABLISHED = "Connection Created";
	public static final String ERROR_INSERTING_VALUES = "Error Inserting Values";
	public static final String INTEGRITY_VOILATON_ERROR = "Integrity Voilation Error";
	public static final String ERROR_READING_VALUES = "Error Reading Values";
	public static final String INSERTION_SUCCESSFUL = "Flat Registered Successfully";
	public static final String OWNER_ID_READ_SUCCESSFUL = "Owner ID read successfully";
	public static final String CONNECTION_TERMINATED = "Connection Terminated";
}
