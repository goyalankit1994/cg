package comm.cg.collection;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class TreeDemo {

	public static void main(String[] args) {
		TreeMap map = new TreeMap();
		map.put("a", 1.5f);
		map.put("b",1.6f);
		map.put("c", 1.2f);
		System.out.println(map);
		Set keys = map.keySet();
		Iterator keyref = keys.iterator();
		while (keyref.hasNext())
		{
			String key = (String)keyref.next();
			float val = (float) map.get(key);
			System.out.println("key =" + key + " & " + " value ="+ val);
		}

	}

}
