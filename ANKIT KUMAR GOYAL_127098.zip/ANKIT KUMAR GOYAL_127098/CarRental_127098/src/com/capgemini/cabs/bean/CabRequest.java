package com.capgemini.cabs.bean;

import java.time.LocalDate;

public class CabRequest {
	private int request_id;
	private String cname;
	private String phonenum;
	private LocalDate date;
	private String requeststatus;
	private String cabnum;
	private String pickupadd;
	private String pincode;
	public CabRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CabRequest [request_id=" + request_id + ", cname=" + cname
				+ ", phonenum=" + phonenum + ", date=" + date
				+ ", requeststatus=" + requeststatus + ", cabnum=" + cabnum
				+ ", pickupadd=" + pickupadd + ", pincode=" + pincode + "]";
	}
	public int getRequest_id() {
		return request_id;
	}
	public void setRequest_id(int request_id) {
		this.request_id = request_id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getRequeststatus() {
		return requeststatus;
	}
	public void setRequeststatus(String requeststatus) {
		this.requeststatus = requeststatus;
	}
	public String getCabnum() {
		return cabnum;
	}
	public void setCabnum(String cabnum) {
		this.cabnum = cabnum;
	}
	public String getPickupadd() {
		return pickupadd;
	}
	public void setPickupadd(String pickupadd) {
		this.pickupadd = pickupadd;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	
	
	

}

