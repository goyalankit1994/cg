package com.cg.dto;

public class EbillBean {
	int con_num;
	String con_name;
	String con_add;
	public EbillBean()
	{
		
	}
	
	public EbillBean(int con_num, String con_name, String con_add) {
		super();
		this.con_num = con_num;
		this.con_name = con_name;
		this.con_add = con_add;
	}

	public int getCon_num() {
		return con_num;
	}
	public void setCon_num(int con_num) {
		this.con_num = con_num;
	}
	public String getCon_name() {
		return con_name;
	}
	public void setCon_name(String con_name) {
		this.con_name = con_name;
	}
	public String getCon_add() {
		return con_add;
	}
	public void setCon_add(String con_add) {
		this.con_add = con_add;
	}
	@Override
	public String toString() {
		return "EbillBean [con_num=" + con_num + ", con_name=" + con_name
				+ ", con_add=" + con_add + "]";
	}
	

}
