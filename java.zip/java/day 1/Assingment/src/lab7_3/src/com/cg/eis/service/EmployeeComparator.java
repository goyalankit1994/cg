package com.cg.eis.service;

import java.util.Comparator;

import com.cg.eis.bean.Employee;

public  class EmployeeComparator implements Comparator<Employee> {
public int compare(Employee e1, Employee e2) {
	
		return (int)(e1.getSalary() - e2.getSalary());
	}

}
