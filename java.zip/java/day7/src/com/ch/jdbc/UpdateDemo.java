package com.ch.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class UpdateDemo {

	public static void main(String[] args) {
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "system";
		String pass = "sys";
		Connection con =DriverManager.getConnection(url,user,pass);
		String sql = "UPDATE  Emp SET name = ? where id=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		String name = sc.next();
		System.out.println("Enter id");
		int id = sc.nextInt();
		pstmt.setString(1,name);
		pstmt.setInt(2,id);
		int row = pstmt.executeUpdate();
		if(row>0)
		{
			System.out.println("no of row updated  are "+row);
		}
			
		
		//ResultSet result =  stmt.executeQuery(sql);
}
	catch(Exception e)
	{
	e.printStackTrace();
	}

}
}
	


	


