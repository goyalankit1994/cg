package com.cg.contactbook.logger;

import java.io.IOException;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

import com.cg.contactbook.logger.MyLogger;

public class MyLogger 
{
	
	static Logger logger = Logger.getLogger(MyLogger.class);
	
	static
	{
		Layout layout = new SimpleLayout();
		Appender appender = null;
		try 
		{
			appender = new FileAppender(layout, "log1.txt");
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.addAppender(appender);
	}

	public static Logger getLoggerInstance()
	{
		return logger;
	}
}
