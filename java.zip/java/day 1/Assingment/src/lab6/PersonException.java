package lab6;

public class PersonException extends Exception {
	String message;

	public PersonException(String msg) {
		this.message = msg;
	}

	public String getMessage() {
		return message;
	}

}
