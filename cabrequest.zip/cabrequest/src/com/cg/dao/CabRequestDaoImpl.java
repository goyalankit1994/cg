package com.cg.dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.bean.CabRequest;
import com.cg.exception.CabException;


@Repository
public class CabRequestDaoImpl implements CabRequestDao {
	@PersistenceContext
	private EntityManager entityManager;
	

	@Override
	public CabRequest addCabRequestDetails(CabRequest cabRequest) throws CabException {
		if(cabRequest.getPincode().equals("411013")){
			cabRequest.setCabNumber("MH-24 5078");
		}else if(cabRequest.getPincode().equals("450156")){
			cabRequest.setCabNumber("MH-14 8888");
		}
		else if(cabRequest.getPincode().equals("412012")){
			cabRequest.setCabNumber("MH-14 9999");
		}
		else if(cabRequest.getPincode().equals("800023")){
			cabRequest.setCabNumber("MH-28 0007");
		}
		else if(cabRequest.getPincode().equals("542014")){
			cabRequest.setCabNumber("MH-75 2694");
		}else if(cabRequest.getPincode().equals("657845")){
			cabRequest.setCabNumber("MH-18 4545");
		}
		cabRequest.setDateOfRequest(LocalDate.now());
		cabRequest.setRequestStatus("Accepted");
		entityManager.persist(cabRequest);
		entityManager.flush();
		System.out.println("dao:"+cabRequest);
		
		return cabRequest;
		
	}

	@Override
	public CabRequest getRequestDetails(int requestId) throws CabException {
		CabRequest bean =  new CabRequest();
		bean=entityManager.find(CabRequest.class, requestId);
		System.out.println("getdetails"+bean);
		if(bean==null)
		{
			throw new CabException("ID not found,please enter a valid id.");
		}
		return bean;
	}

	@Override
	public int getRequestId(CabRequest cabs) throws CabException {
		int requestId= cabs.getRequestId();
		System.out.println("requestId generated is:"+requestId);
		return requestId;
	}

}
