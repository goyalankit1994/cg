package lab4;

public class SavingAccount extends Account {
	final double minBal=500;
	
	 
	public SavingAccount(double balance,Person accholder)
	{
		this.accholder=accholder;
		this.balance=balance;
		//super(p,bal);
	}
	
	
	@Override
	public void withdraw(double amount)
	{
		
		if(amount<getBalance()-minBal)
			this.setBalance(getBalance()-amount);
		else
			System.out.println("Not enough balance");
	}
}



