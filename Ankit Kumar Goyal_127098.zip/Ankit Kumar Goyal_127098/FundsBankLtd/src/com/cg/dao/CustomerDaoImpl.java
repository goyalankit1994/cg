package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.bean.ComplaintBean;
import com.cg.exception.BankException;
@Repository
public class CustomerDaoImpl implements ICustomerDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public ComplaintBean raiseCustomerComplaint(ComplaintBean bean)
			throws BankException {
		if(bean.getCategory().equals("Internet Banking")){
			bean.setPriority("high");
		}else if(bean.getCategory().equals("General Banking")){
			bean.setPriority("medium");
		}
		else if(bean.getCategory().equals("Others")){
			bean.setPriority("low");
		}
		bean.setStatus("open");
		entityManager.persist(bean);
		entityManager.flush();
		System.out.println("dao:"+bean);
		
		return bean;
	}

	@Override
	public ComplaintBean checkComplaintStatus(int complaintid)
			throws BankException {
		ComplaintBean bean1 =  new ComplaintBean();
		bean1=entityManager.find(ComplaintBean.class, complaintid);
		System.out.println("getdetails"+bean1);
		if(bean1==null)
		{
			throw new BankException("ID not found,please enter a valid id.");
		}
		return bean1;
	}

	@Override
	public int getComplaintId(ComplaintBean bean) throws BankException {
		int complaintid= bean.getComplaintid();
		System.out.println("ComplaintId generated is:"+complaintid);
		return complaintid;
	}
	
	
}

