package com.capgemini.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.log4j.Logger;

import com.capgemini.exception.EmpException;

public class FileUtil {
	static BufferedWriter bw;
	static BufferedReader br;
	FileUtil fUtil;
	static String FileName = "emp.ser";
	static Logger logger = Logger.getLogger(FileUtil.class);
	
	private FileUtil() {
		
	}

	public static BufferedWriter getBufferedWriter() throws EmpException {
		
		if(bw==null){
			try {
				bw = new BufferedWriter(new FileWriter(FileName,true));
			} catch (IOException e) {
				logger.error(Messages.FILE_CANNOT_READ_ERROR + e);
				throw new EmpException( Messages.FILE_CANNOT_READ_ERROR);
			}
		}
		return bw;
	}

	public static BufferedReader getBufferedReader() throws EmpException {
		if (br == null){
			try {
				br = new BufferedReader(new FileReader(FileName));
			} catch (FileNotFoundException e) {
				logger.info( Messages.FILE_NOT_FOUND_ERROR + e);
				throw new EmpException( Messages.FILE_NOT_FOUND_ERROR);
			}
		}
		return br;
	}
}
