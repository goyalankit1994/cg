package lab1;


public class CreatePerson {

	public static void main(String[] args)
	{
		PersonClass1 sc=new PersonClass1();
		System.out.println("name="+sc.getFname());
		System.out.println("last name = "+sc.getLname());
		System.out.println("gender="+sc.getGender());
		
		PersonClass1 ref = new PersonClass1("kishan","purohit","male");
		System.out.println("name ="+ref.getFname());
		System.out.println("last name="+ref.getLname());
		System.out.println("gender ="+ref.getGender());
		
		

	}

}
