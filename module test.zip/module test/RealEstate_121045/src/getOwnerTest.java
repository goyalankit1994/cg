import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cg.frs.dao.FlatRegisterationDAO;
import com.cg.frs.dao.IFlatRegisterationDAO;
import com.cg.frs.exception.FlatRegisterationException;


public class getOwnerTest {

	IFlatRegisterationDAO flatRegisterationDao;
	List<Integer> idList;
	
	@Before
	public void setUp() throws Exception {
		flatRegisterationDao = new FlatRegisterationDAO();
	}

	@Test
	public void test() throws FlatRegisterationException {
		idList = flatRegisterationDao.getOwnerID();
		assertNotNull(idList);
	}

}
