package com.cg.pojo;

public class LoginValidator {
	public static boolean validate(String user,String passwd)
	{
		boolean flag = false;
		if(user.equals("ankit")&&passwd.equals("1234"))
		{
			flag = true;
		}
		else
		{
			flag=false;
		}
			return flag;
	}

}



