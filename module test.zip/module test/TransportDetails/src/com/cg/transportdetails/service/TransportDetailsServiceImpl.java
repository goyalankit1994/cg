package com.cg.transportdetails.service;

import java.util.regex.Pattern;

import com.cg.transportdetails.dao.TransportDetailsDao;
import com.cg.transportdetails.dao.TransportDetailsDaoImpl;
import com.cg.transportdetails.dto.BookingBean;
import com.cg.transportdetails.dto.TruckBean;
import com.cg.transportdetails.exception.TransportException;

public class TransportDetailsServiceImpl implements TransportDetails {

	TransportDetailsDao dao=new TransportDetailsDaoImpl();
	
	@Override
	public java.util.List<TruckBean> retrieveTransportDetails()
			throws TransportException {
		// TODO Auto-generated method stub
		return dao.retrieveTransportDetails();
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws TransportException {
		// TODO Auto-generated method stub
		return dao.bookTrucks(bookingBean);
	}
	
	public void setDao(TransportDetailsDao dao)
	{
		this.dao=dao;
	}

	public boolean validation(String bean) {
		// TODO Auto-generated method stub
		String idPattern = "[A-Z]{1}[0-9]{6}";
		if(!Pattern.matches(idPattern, bean))
		{
			System.out.println("invalid customer id");
			return false;
		}
		return true;
	}
	
}
