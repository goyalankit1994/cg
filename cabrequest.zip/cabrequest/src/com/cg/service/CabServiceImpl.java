package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.CabRequest;
import com.cg.dao.CabRequestDao;
import com.cg.exception.CabException;
@Service
@Transactional
public class CabServiceImpl implements CabService {
	@Autowired
	private CabRequestDao cabDao;

	@Override
	public CabRequest addCabRequestDetails(CabRequest cabRequest) throws CabException {
		// TODO Auto-generated method stub
		return cabDao.addCabRequestDetails(cabRequest);
	}

	@Override
	public CabRequest getRequestDetails(int requestId) throws CabException {
		// TODO Auto-generated method stub
		return cabDao.getRequestDetails(requestId);
	}

	@Override
	public int getRequestId(CabRequest cabs) throws CabException {
		// TODO Auto-generated method stub
		return cabDao.getRequestId(cabs);
	}
	

}
