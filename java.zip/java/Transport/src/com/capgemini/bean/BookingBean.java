/**
 * 
 */
package com.capgemini.bean;

import java.time.LocalDate;

/**
 * @author angoyal
 *
 */
public class BookingBean {
private int bookingid;
private String custid;
private long  custMobile;
private int truckid;
private int nooftrucks;
private LocalDate dateoftransport;
public BookingBean()
{
		
}
public int getBookingid() {
	return bookingid;
}
public void setBookingid(int bookingid) {
	this.bookingid = bookingid;
}
public String getCustid() {
	return custid;
}
public void setCustid(String custid) {
	this.custid = custid;
}
public long getCustMobile() {
	return custMobile;
}
public void setCustMobile(long custMobile) {
	this.custMobile = custMobile;
}
public int getTruckid() {
	return truckid;
}
public void setTruckid(int truckid) {
	this.truckid = truckid;
}
public int getNooftrucks() {
	return nooftrucks;
}
public void setNooftrucks(int nooftrucks) {
	this.nooftrucks = nooftrucks;
}
public LocalDate getDateoftransport() {
	return dateoftransport;
}
public void setDateoftransport(LocalDate dateoftransport) {
	this.dateoftransport = dateoftransport;
}
@Override
public String toString() {
	return "BookingBean [bookingid=" + bookingid + ", custid=" + custid
			+ ", custMobile=" + custMobile + ", truckid=" + truckid
			+ ", nooftrucks=" + nooftrucks + ", dateoftransport="
			+ dateoftransport + "]";
}


}
