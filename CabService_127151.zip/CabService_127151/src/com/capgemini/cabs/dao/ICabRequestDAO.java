package com.capgemini.cabs.dao;

import com.capgemini.cabs.dto.CabsRequests;
import com.capgemini.cabs.exception.CabsException;

public interface ICabRequestDAO {

	//Declaration of Method
	public int addCabRequestDetails(CabsRequests cabRequest) throws CabsException;
	public CabsRequests getRequestDetails(int requestId) throws CabsException;
	
}
