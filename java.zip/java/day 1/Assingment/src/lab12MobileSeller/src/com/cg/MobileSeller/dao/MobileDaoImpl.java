package com.cg.MobileSeller.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.cg.MobileSeller.Exception.MobileException;
import com.cg.MobileSeller.dbutil.DButil;
import com.cg.MobileSeller.dto.MobileBean;
import com.cg.MobileSeller.dto.PurchaseBean;
import com.cg.MobileSeller.logger.MyLogger;

public class MobileDaoImpl implements MobileDao {
	Logger logger = MyLogger.getLoggerInsatnce();
	Connection con;
	public MobileDaoImpl()
	{
		con = DButil.getConnection();
		if(con!=null)
		{
			logger.info("obtained connection");
		}
	}
	Map<Integer, Integer> map= new HashMap<Integer, Integer>();
	DButil dbutil = new DButil();
	Connection conn = null;
	String insertQuery="insert into purchasedetails(purchaseid, cname, mailid, phoneno, purchasedate, mobileid) values(purchaseid_SEQ.NEXTVAL,?,?,?,sysdate,?)";
	String getMobileQuery="select mobileid,quantity from mobiles where quantity > 0 ";
	String updateMobileQuery="update mobiles set quantity =quantity-1 where mobileid=?";
	String viewDetailsQuery="select * from mobiles";
	String deleteQuery= "delete from  mobiles  where mobileid=?";
	String viewMobilesPriceQuery= "select * from mobiles where price between ? and ?";

	@Override
	public boolean saveCust(PurchaseBean cus) throws MobileException {
		boolean saved = false;
		try {
			conn= dbutil.getConnection();
			conn.setAutoCommit(false);
			Statement stmt= conn.createStatement();
			ResultSet rs= stmt.executeQuery(getMobileQuery);
			conn.commit();
			while(rs.next()){
				map.put(rs.getInt(1), rs.getInt(2));
				}
			
			PreparedStatement pstmt= conn.prepareStatement(insertQuery);
			pstmt.setString(1, cus.getCname());
			pstmt.setString(2, cus.getMailid());
			pstmt.setString(3, cus.getPhoneno());
			pstmt.setInt(4,cus.getMobileId());
			//logger.info("inserted record"+cy);
			int rows = pstmt.executeUpdate();
			logger.info("inserted record"+cus);
			System.out.println(rows);
			if(rows >0){
				
				saved= true;
				conn.commit();
				PreparedStatement pstmt1= conn.prepareStatement(updateMobileQuery);
				pstmt1.setInt(1,cus.getMobileId());
				logger.info("update record "+pstmt1);
				pstmt1.executeUpdate();
				conn.commit();
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Exception occured"+e.getMessage());
			throw new MobileException("Purchase details can not be saved");
		}
		
		return saved;
	}
		

	@Override
	public Map<Integer, Integer> getMap() throws MobileException {
		try {
			conn = DButil.getConnection();
			conn.setAutoCommit(false);
			Statement stmt= conn.createStatement();
			ResultSet rs= stmt.executeQuery(getMobileQuery);
			logger.info("inserted record"+map);
			conn.commit();
			while(rs.next()){
				map.put(rs.getInt(1), rs.getInt(2));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("exception occured during get by id"+e.getMessage());
			throw new MobileException("connection to databse is failed");
		}
		return map;
	}
	@Override
	public List<MobileBean> getMobList() throws MobileException {
		List<MobileBean> mlist = new ArrayList <MobileBean>();
		try {
			conn = DButil.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(viewDetailsQuery);
			while (rs.next()) {
				
				MobileBean mob = new MobileBean(); 
					mob.setMobileid(rs.getInt(1));
						mob.setName(rs.getString(2));
						mob.setPrice(rs.getInt(3));
						mob.setQuantity(rs.getString(4));
				
				mlist.add(mob);
				logger.info("fetch record"+mob);
			}
		} catch (SQLException e) {
			logger.error("exception occured during get by id"+e.getMessage());
			throw new MobileException("Could not fetch data");
		}
		return mlist;
		
	}
	

	@Override
	public boolean deleteMobile(int mobileid_delete) throws MobileException {
		boolean delete= false;
		Connection conn = null;

		try {
			conn=DButil.getConnection();
			conn.setAutoCommit(false);
			PreparedStatement pstmt2 = conn.prepareStatement(deleteQuery);
			pstmt2.setInt(1, mobileid_delete);
			logger.info("deleted record"+mobileid_delete);
			int rows= pstmt2.executeUpdate();
			if(rows>0)
				delete= true;
			conn.commit();

		}
		 catch (SQLException e) {
			throw new MobileException("could not delete");
		}

		return delete;
	}	
		

	@Override
	public List<MobileBean> getMobPriceList(int p1, int p2)throws MobileException {
	List<MobileBean> mlist = new ArrayList <MobileBean>();

			
		try {
			conn = DButil.getConnection();
			PreparedStatement pstmt;
			try {
				pstmt = conn.prepareStatement(viewMobilesPriceQuery);
				pstmt.setInt(1,p1);
				pstmt.setInt(2,p2);
				
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					
					MobileBean mob = new MobileBean();
					mob.setMobileid(rs.getInt(1));
					mob.setName(rs.getString(2));
					mob.setPrice(rs.getInt(3));
					mob.setQuantity(rs.getString(4));
					
					mlist.add(mob);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new MobileException("database connection error");
			}
			
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			throw new MobileException("databse connection error");
		}
		return mlist;
		

}


}
