package file;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File file = new File("demo.txt");
FileInputStream fin = null;
BufferedInputStream bin = null;
DataInputStream din = null;

try{
if(file.exists())
{
	if (file.canRead())
	{
		long len = file.length(); // to find length of file
		fin = new FileInputStream(file); // to read byte by write
		bin = new BufferedInputStream(fin); // read chunks byte by byte
		din = new DataInputStream(bin);  // convert byte to valid data types
		int i =0;
		while(i<len)                       // reading 
		{
			System.out.print((char)din.read());
			i++;
		}
		}
}
	}
catch(IOException e)
{
	System.out.println(e.getMessage());
}
	}
	}
