package com.cg.DthRecharge.dao;

import com.cg.DthRecharge.Exception.DthException;
import com.cg.DthRecharge.dto.DthRechargeBean;



public interface DthDao {
	public DthRechargeBean getRecord(int userid)
			throws DthException;
	public boolean Recharge() throws DthException;
	public int CheckBalance (int userid)
	        throws DthException;
}
