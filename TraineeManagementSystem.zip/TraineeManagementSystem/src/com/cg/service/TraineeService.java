package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.TraineeBean;
import com.cg.exception.TraineeException;

public interface TraineeService {
	public TraineeBean addTraineeDetails(TraineeBean bean) throws TraineeException;
	public TraineeBean getDetails(int id) throws TraineeException ;
	public ArrayList<TraineeBean>  getallTraineeDetails() throws TraineeException;
	boolean modifyTrainee(int id, TraineeBean trainee) throws TraineeException;
	Boolean removeTrainee(int id) throws TraineeException;
	
}
