package com.capgemini.onlinegaming.exception;

public class GameException extends Exception {
	String message;
	public GameException(String msg)
	{
		this.message=msg;
	}
	public String getMessage()
	{
		return message;
	}

}
