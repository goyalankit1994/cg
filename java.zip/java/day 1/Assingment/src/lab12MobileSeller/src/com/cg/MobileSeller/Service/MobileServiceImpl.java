package com.cg.MobileSeller.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.MobileSeller.Exception.MobileException;
import com.cg.MobileSeller.dao.MobileDao;
import com.cg.MobileSeller.dao.MobileDaoImpl;
import com.cg.MobileSeller.dto.MobileBean;
import com.cg.MobileSeller.dto.PurchaseBean;

public class MobileServiceImpl implements MobileInterface {
	MobileDao dao;
	
	 public MobileServiceImpl() {
		dao= new MobileDaoImpl();
	}

	@Override
	public boolean validateName(String cname) {
		return cname.matches("[A-Z][A-Za-z]*");
	}

	@Override
	public boolean validateMailId(String mailid) {
		return mailid.matches
				("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		
	}

	@Override
	public boolean validatePhoneNo(String phoneNo) {
		return phoneNo.matches("[7-9][0-9]{9}");
		
	}

	@Override
	public boolean validateMobileId(String temp) {
		// TODO Auto-generated method stub
		return temp.matches("[0-9]{4}");
	}

	@Override
	public boolean saveCust(PurchaseBean cus) throws MobileException {
		boolean saved=false;
		saved= dao.saveCust(cus);
		return saved;
	}

	@Override
	public Map<Integer, Integer> getMobiles() throws MobileException {
		return dao.getMap();
	}

	@Override
	public List<MobileBean> getMobList() throws MobileException {
		return dao.getMobList();
	}

	@Override
	public boolean deleteMobile(int mobileid_delete) throws MobileException {
		// TODO Auto-generated method stub
		return dao.deleteMobile(mobileid_delete);
	}

	@Override
	public List<MobileBean> getMobPriceList(int p1, int p2)
			throws MobileException {
		// TODO Auto-generated method stub
		return  dao.getMobPriceList(p1, p2);
	}

	@Override
	public boolean checkMobileId(int mobileId) throws MobileException {
		boolean valid = false;
		Set <Integer> set = dao.getMap().keySet();
		if(set.contains(mobileId)) {
			valid = true;
		}
		return valid;
	}

	@Override
	public void setDao(MobileDao dao) {
		this.dao=dao;
		
	}
}