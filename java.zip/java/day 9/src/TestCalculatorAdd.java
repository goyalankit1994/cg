import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestCalculatorAdd {
CalAdd ref;
@Before
public void init()
{
	ref = new CalAdd();
}
	@Test
	public void testAdd() {
		assertNotEquals(0,ref.add(7,0));
	}

}
