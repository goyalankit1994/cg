package comm.cg.stringclass;

public class StringDemo {

	public static void main(String[] args) {
		String str1 = new String("abc");
		String str2 = "abc";
		String str3 = "abc";
		String str4 = new String("abc");
	if(str1 == str2 )
		System.out.println("str1 and str2 are equal");
	if(str2 == str3)
		System.out.println("str 2 and str 3 are equal");
	if(str1 == str4)
		System.out.println("str1 and str4 are equal");
	
		// TODO Auto-generated method stub

	}

}
