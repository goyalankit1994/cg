package com.cg.DthRecharge.Service;

import com.cg.DthRecharge.Exception.DthException;
import com.cg.DthRecharge.dao.DthDao;
import com.cg.DthRecharge.dao.DthDaoImpl;
import com.cg.DthRecharge.dto.DthRechargeBean;


public class DthServiceImpl implements DthService {
	
	@Override
	public boolean Recharge() throws DthException {
		// TODO Auto-generated method stub
		return dao.Recharge();
	}
	@Override
	public int CheckBalance(int userid) throws DthException {
		// TODO Auto-generated method stub
		return 0;
	}

	DthDao dao;
	public void setDao(DthDao dao)
	{
		this.dao = dao;
	}
	public DthServiceImpl()
	{
		dao = new DthDaoImpl();
	}

	@Override
	public DthRechargeBean getRecord(int userid) throws DthException {
		// TODO Auto-generated method stub
		return dao.getRecord(userid);
	}

	

}
