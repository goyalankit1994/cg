package lab1;
import java.util.Scanner;
public class PersonMain {

	public static void main(String[] args) {
		String fname;
		String lname;
		String gender;
		String mobileno;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first name");
		fname=sc.nextLine();
		System.out.println("Enter last name");
		lname=sc.nextLine();
		System.out.println("Enter gender");
		gender=sc.nextLine();
		System.out.println("Enter mobile number");
		mobileno=sc.nextLine();
		PersonDetails1 sc1 = new PersonDetails1(fname,lname,gender,mobileno);
		sc1.printdetails();
		sc.close();
		
		
		
		

	}

}
