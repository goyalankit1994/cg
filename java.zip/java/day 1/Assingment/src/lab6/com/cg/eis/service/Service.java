package lab6.com.cg.eis.service;

import lab6.com.cg.eis.service.ServiceInterface;

public class Service implements ServiceInterface {
	public String  getInsuranceScheme(double salary, String designation) {
		if ( salary > 5000 && salary < 20000 && designation.equals("SA"))
			return "C";
		else if ( salary >= 20000 && salary < 40000 && designation.equals("Programmer"))
			return "B";
		else if ( salary >= 40000 && designation.equals("Manager"))
			return "A";
		else if ( salary < 50000 && designation.equals("Clerk"))
			return "no schema";
		else
			return "N";
	}

}

