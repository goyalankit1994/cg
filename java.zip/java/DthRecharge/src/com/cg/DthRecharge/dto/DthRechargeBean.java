package com.cg.DthRecharge.dto;

public class DthRechargeBean {
	int userid;
	String name;
	int balance;
	String mobileno;
	public DthRechargeBean()
	{
		
	}
	@Override
	public String toString() {
		return "DthRechargeBean [userid=" + userid + ", name=" + name
				+ ", balance=" + balance + ", mobileno=" + mobileno + "]";
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

}
