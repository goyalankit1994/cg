package comm.cg.inheritence.shape;
import java.util.Scanner;
public class CreateShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Shape s1 = new Triangle(2,3);
Shape s2= new Rectangle(4,5);
Shape s3 = new Circle(2);
Scanner sc = new Scanner(System.in);
System.out.println("1----traiangle");
System.out.println("2----rectangle");
System.out.println("3----circle");
System.out.println("enter the number of shape whose area need to be calculated");
int choice;
double result;
choice=sc.nextInt();
switch(choice)
{
case 1:
	result = s1.calArea();
	System.out.println("Area of triangle is "+result);
	break;
case 2:
	result = s2.calArea();
	System.out.println("Area of rectangle is "+result);
	break;
case 3:
	result = s3.calArea();
	System.out.println("Area of circle is "+result);
	break;
	default:
		System.out.println("not a valid choice ");
		
}
sc.close();

	}

}
