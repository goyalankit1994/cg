package com.capgemini.xyz.util;


public class Messages {
	public static final String DB_CONN_ERROR = "Error connecting to Database";
	public static final String CLASS_NOT_FOUND_ERROR = "Class Driver cannot be loaded";
	public static final String CONNECTION_CANNOT_BE_TERMINATED = "Connecton Cannot be Terminated";
	public static final String NO_OWNER_ID_EXIST = "No Owner ID Exist in Database";
	public static final String CONNECTION_ESTABLISHED = "Connection Created";
	public static final String ERROR_INSERTING_VALUES_CUSTOMER = "Error Inserting Values for Customer";
	public static final String INTEGRITY_VOILATON_ERROR = "Integrity Voilation Error";
	public static final String ERROR_READING_VALUES = "Error Reading Values";
	public static final String INSERTION_SUCCESSFUL_LOAN = "loan Registered Successful";
	public static final String CONNECTION_TERMINATED = "Connection Terminated";
	public static final String INSERTION_SUCCESSFUL_CUSTOMER = "Customer Registered Successful";
	public static final String ERROR_INSERTING_VALUES_LOAN = "Error Inserting Values for Loan";
}
