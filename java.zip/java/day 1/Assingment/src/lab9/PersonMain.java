package lab9;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		Person p=new Person("Ankit"," Goyal");
		System.out.println("PersonDeatils");
		System.out.println("----------------------");
		System.out.println("first name "+p.getFirstName());
		System.out.println("lastname" +p.getLastName());
		System.out.println("gender is :"+p.getGender());
		
	

	}

}
