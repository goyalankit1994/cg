package com.cg.electricitybill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.electricitybill.bean.BillDetailsBean;
import com.cg.electricitybill.bean.ConsumersBean;
import com.cg.electricitybill.dbutil.DBUtil;
import com.cg.electricitybill.exception.ElectricityException;

public class EBillDaoImpl implements EBillDao {
	Connection con;

	public EBillDaoImpl() {
		con = DBUtil.getConnection();
	}

	@Override
	public List<ConsumersBean> getConsumers() throws ElectricityException {
		List<ConsumersBean> list = new ArrayList<>();
		try {
			String sql = "SELECT * FROM Consumers";
			Statement statement = con.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				ConsumersBean bean = new ConsumersBean();
				bean.setConsumer_num(result.getInt(1));
				bean.setConsumner_name(result.getString(2));
				bean.setAddress(result.getString(3));
				list.add(bean);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public ConsumersBean searchConsumer(int consumer_num)
			throws ElectricityException {

		ConsumersBean bean = null;
		String sql = "SELECT * FROM CONSUMERS WHERE consumer_num=?";
		try {

			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, consumer_num);
			ResultSet result = stmt.executeQuery();
			if (result.next()) {
				bean = new ConsumersBean();
				bean.setConsumer_num(result.getInt(1));
				bean.setConsumner_name(result.getString(2));
				bean.setAddress(result.getString(3));
			} else
				throw new ElectricityException("Invalid consumer id  "
						+ consumer_num);
		} catch (Exception e) {
			throw new ElectricityException(e.getMessage());
		}
		return bean;
	}

	@Override
	public List<BillDetailsBean> getBillDetails(int cnum)
			throws ElectricityException {
		List<BillDetailsBean> billList = new ArrayList<>();
	try
	{
		String sql="select bill.bill_num,cons.consumer_num,cons.consumer_name,cons.address,bill.cur_reading,bill.unitConsumed,bill.netamount"
				+ "bill.bill_date from Consumers cons,"
				+ "billDetails bill where cons.consumer_num = bill.consumer_num and cons.consumer_num = ?";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		preparedStatement.setInt(1,cnum);
		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()){
		BillDetailsBean	bill = new BillDetailsBean();
			bill.setBill_num(resultSet.getInt(1));
			int consumerNumber = resultSet.getInt(2);
			String consumerName = resultSet.getString(3);
			String address = resultSet.getString(4);
			ConsumersBean bean1 = new ConsumersBean(consumerNumber, consumerName,
					address);
			bill.set(bean1);
			bill.setCurr_reading(resultSet.getDouble(5));
			bill.setUnit_consumed(resultSet.getDouble(6));
			bill.setNet_amount(resultSet.getDouble(7));
			bill.setBill_date(resultSet.getDate(8));
			billList.add(bill);
		}
		
	}
	catch(Exception e )
	{
	throw new ElectricityException("Error Fetching Bill Details for Consumer ID : " + cnum);
	}
	return billList;
}
	@Override
	public int generateNextBill(BillDetailsBean nextBill)
			throws ElectricityException {
		try
		{
		String sql ="insert into billdetails values(seq_bill_num.NEXTVAL,?,?,?,?,sysdate)";	
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		preparedStatement.setInt(1, nextBill.getCon_num().getConsumer_num());
		preparedStatement.setDouble(2, nextBill.getCurr_reading());
		preparedStatement.setDouble(3, nextBill.getUnit_consumed());
		preparedStatement.setDouble(4, nextBill.getNet_amount());
		int rows = preparedStatement.executeUpdate();
		if (rows > 0){
			Statement statement = con.createStatement();
			String sql1= "select seq_bill_num.CURRVAL from dual";
			ResultSet resultSet = statement.executeQuery(sql1);
			if (resultSet.next())
				return resultSet.getInt(1);
		}
	} 
		catch (SQLException e) 
		{
		throw new ElectricityException("Error Generating new Bill");
	}
	return 0;
}
}