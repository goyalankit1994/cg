package com.cg.contactbook.dto;

public class EnquiryBean 
{
	private int enqryid;
	private String fname;
	private String lname;
	private String contactno;
	private String pLocation;
	private String pDomain;
	public int getEnqryid() {
		return enqryid;
	}
	public void setEnqryid(int enqryid) {
		this.enqryid = enqryid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getpLocation() {
		return pLocation;
	}
	public void setpLocation(String pLocation) {
		this.pLocation = pLocation;
	}
	public String getpDomain() {
		return pDomain;
	}
	public void setpDomain(String pDomain) {
		this.pDomain = pDomain;
	}
	@Override
	public String toString() {
		return "EnquiryBean [enqryid=" + enqryid + ", fname=" + fname
				+ ", lname=" + lname + ", contactno=" + contactno
				+ ", pLocation=" + pLocation + ", pDomain=" + pDomain + "]";
	}
	public EnquiryBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
