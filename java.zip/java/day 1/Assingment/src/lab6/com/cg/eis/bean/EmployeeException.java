package lab6.com.cg.eis.bean;

public class EmployeeException extends Exception {
	String message;
	public EmployeeException(String msg)
	{
		this.message = msg;
	}
	public String getMessage() {
		return message;
	}
}
