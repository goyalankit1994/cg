package com.cg.contactbook.test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.contactbook.dbutil.DBUtil;
import com.cg.contactbook.exception.ContactBookException;

public class ContactBookTest 
{
	Connection con=null;
	PreparedStatement pt=null;
	PreparedStatement pt1=null;
	
	@Before
	public void insertBefore() throws SQLException,ContactBookException
	{
		String query="insert into enquiry values(?,?,?,?,?,?)";
		con=DBUtil.getConnection();
		pt=con.prepareStatement(query);
		pt.setInt(1, 101);
		pt.setString(2,"Abc");
		pt.setString(3, "Df");
		pt.setString(4,"1234567890");
		pt.setString(5, "Dfdg");
		pt.setString(6, "Erty");
	}
	
	@Before
	public void SearchBefore() throws SQLException,ContactBookException
	{
		String queryThree="Select firstname,lastname,contactno,domain,city from enquiry where enqryid=?";
		
		con=DBUtil.getConnection();
		
		pt1=con.prepareStatement(queryThree);
		pt1.setInt(1, 101);
	}
	
	@Test
	public void test() throws SQLException
	{
		assertEquals("1",Integer.toString(pt.executeUpdate()));
		
		assertEquals("1",Integer.toString(pt1.executeUpdate()));
	}
	
	@After
	public void doAfterClass() throws SQLException
	{
		con.close();
	}

}
