import java.util.Scanner;
public class ScannerDemo {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("nummber");
	int x = sc.nextInt();
	System.out.println("string");
	String str = sc.next(); //doesnt count space
	System.out.println("boolean");
	Boolean flag = sc.nextBoolean();
	System.out.println("x = "+x);
	System.out.println("str is "+str);
	System.out.println("flag = "+flag);

	}

}
