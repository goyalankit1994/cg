package com.cg.DthRecharge.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.DthRecharge.Exception.DthException;
import com.cg.DthRecharge.Service.DthService;
import com.cg.DthRecharge.Service.DthServiceImpl;
import com.cg.DthRecharge.dao.DthDao;
import com.cg.DthRecharge.dao.DthDaoImpl;
import com.cg.DthRecharge.dto.DthRechargeBean;


public class DthRechargeDaoTest {
	static DthService service;
	static DthDao dao;
	@Before
	public void init()
	{
		service = new DthServiceImpl();
		dao = new DthDaoImpl();
		service.setDao(dao);
	}

	@Test
	public void testRecharge() {
		DthRechargeBean bean = new DthRechargeBean();
		bean.setUserid(101);
		bean.setName("ankit");
		bean.setBalance(450);
		bean.setMobileno("8239161121");
		try {
			assertEquals(true,service.Recharge());
		} catch (DthException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testGetRecord() throws DthException {
		assertNotNull(service.getRecord(101));
	}

}
