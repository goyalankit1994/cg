package lab7;

import java.util.Arrays;

public class ProductNames {

	public static void main(String[] args) {
		String []ptr = new String[5];
		ptr[0]="cake";
		ptr[1]="biscuits";
		ptr[2]="medicines";
		ptr[3]="soap";
		ptr[4]="book";
		System.out.println("before sorting");
		 for(String var :ptr)
		 {
			 System.out.println(var);
		 }
		 Arrays.sort(ptr);
		 System.out.println("------------------------------");
		 System.out.println("after sort");
		 for(String var:ptr)
			{
				System.out.println(var);
			}
		 
	}

}
