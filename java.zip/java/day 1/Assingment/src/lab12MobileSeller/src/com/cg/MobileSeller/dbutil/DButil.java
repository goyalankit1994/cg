package com.cg.MobileSeller.dbutil;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DButil {
	static Properties prop = new Properties();
	static String driver;
	static String url;
	static String user;
	static String pass;
	static Connection con;
	static
	{
		try
		{
			prop.load(new FileInputStream("jdbc.properties"));
			driver = prop.getProperty("driver");
			user = prop.getProperty("user");
			pass = prop.getProperty("pass");
			url = prop.getProperty("url");
			Class.forName(driver);
			con = DriverManager.getConnection(url,user,pass);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static Connection getConnection()
	{
		return con;
	}
	}


