package com.capgemini.cab.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.Before;
import org.junit.Test;


import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.dbutil.DBUtill;
import com.capgemini.cab.service.CabService;
import com.capgemini.cab.service.ICabService;
import com.capgemini.cabs.bean.CabRequest;




public class TestCase {
	Connection con=null;
	ICabService service;
	ICabRequestDAO dao;
	@Before
	public void init()
	{
		service = new CabService();
		dao = new CabRequestDAO();
	service.setDao(dao);
	}


	@Test
	public void testAddCabRequestDetails() {
		CabRequest bean= new CabRequest();
		bean.setCname("Ankit");
		bean.setPhonenum("8239161121");
		bean.setPickupadd("vidhyadhar");
		bean.setRequeststatus("accepted");
	}
	

	@Test
	public void testGetRequestDetails() {
		
	}

}
