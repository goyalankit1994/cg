package com.cg.transportdetails.dto;

public class TruckBean {

	private int truckId;
	private String truckType;
	private String origin;
	private String destination;
	private float charges;
	private int availableNos;
	
	
	public int getTruckid() {
		return truckId;
	}


	public void setTruckid(int truckid) {
		this.truckId = truckid;
	}


	public String getTrucktype() {
		return truckType;
	}


	public void setTrucktype(String trucktype) {
		this.truckType = trucktype;
	}


	public String getOrigin() {
		return origin;
	}


	public void setOrigin(String origin) {
		this.origin = origin;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	public float getCharges() {
		return charges;
	}


	public void setCharges(float charges) {
		this.charges = charges;
	}


	public int getAvailableNos() {
		return availableNos;
	}


	public void setAvailableNos(int availableNos) {
		this.availableNos = availableNos;
	}


	@Override
	public String toString() {
		return "TruckBean [truckid=" + truckId + ", trucktype=" + truckType
				+ ", origin=" + origin + ", destination=" + destination
				+ ", charges=" + charges + ", availableNos=" + availableNos
				+ "]";
	}


	public static void main(String[] args) {
		
	}
}
