package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder.In;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.bean.BillDetail;
import com.capgemini.bean.Consumer;
import com.capgemini.exception.EBillException;
import com.capgemini.service.EBillService;
import com.capgemini.service.EBillServiceImpl;
import com.capgemini.util.URLMapper;

@WebServlet("*.bill")
public class EBillController extends HttpServlet {

	EBillService eBillService;
	
	@Override
	public void init() throws ServletException {
		try {
			eBillService = new EBillServiceImpl();
		} catch (EBillException e) {
			ServletException servletException = new ServletException(e.getMessage(),e);
			throw servletException;
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		List<Consumer> consumers;
		
	
		
		switch (action) {
		case "/viewAllConsumers.bill":
			try {
				PrintWriter out = response.getWriter();
				out.print(request.getQueryString());
				consumers = eBillService.getAllConsumer();
				System.out.println(consumers);
				/*request.setAttribute("consumers", consumers);
				request.getRequestDispatcher(URLMapper.SHOW_CONSUMER_LIST).forward(request, response);*/
			} catch (EBillException e) {
				ServletException servletException = new ServletException(e.getMessage(),e);
				throw servletException;
			}
			break;
			
		case "/home.bill":
			response.sendRedirect("index.html");
			break;
			
		case "/searchForm.bill":
			/*request.getRequestDispatcher(URLMapper.SEARCH_CONSUMER).forward(request, response);*/
			//response.sendRedirect(URLMapper.SEARCH_CONSUMER);
			getServletContext().getRequestDispatcher(URLMapper.SEARCH_CONSUMER).forward(request, response);
			break;

		case "/search.bill":
			
			int consumerNumber = Integer.parseInt(request.getParameter("consumerNumber"));
			try {
				Consumer consumer = eBillService.searchConsumer(consumerNumber);
				request.setAttribute("consumer", consumer);
				request.getRequestDispatcher(URLMapper.SHOW_CONSUMER).forward(request, response);
			} catch (EBillException e) {
				ServletException servletException = new ServletException(e.getMessage(),e);
				throw servletException;
			}
			break;
			
		case "/showBillDetails.bill":
			List<BillDetail> bill;
			int cnum = Integer.parseInt(request.getParameter("cnum"));
			try {
				bill = eBillService.getBillDetails(cnum);
				request.setAttribute("bill", bill);
				getServletContext().getRequestDispatcher(URLMapper.SHOW_BILL).forward(request, response);
			} catch (EBillException e) {
				ServletException servletException = new ServletException();
				throw servletException;
			}
			break;
			
		case "/generateNextBillForm.bill" :
			cnum = Integer.parseInt(request.getParameter("cnum"));
			String cname = request.getParameter("cname");
			System.out.println(cname);
			request.setAttribute("cnum", cnum);
			request.setAttribute("cname", cname);
			getServletContext().getRequestDispatcher(URLMapper.GENERATE_NEXT_BILL).forward(request, response);
			break;
			
		case "/generateNextBill.bill":
			int cnum2 = Integer.parseInt(request.getParameter("consumerNumber"));
	        cname = request.getParameter("consumerName");
			try {
				int lastMonthMeterReading = Integer.parseInt(request.getParameter("lastMonthMeterReading"));
				int currentMonthMeterReading = Integer.parseInt(request.getParameter("currentMonthMeterReading"));
				int unitConsumed = eBillService.calculateUnitConsumed(lastMonthMeterReading, currentMonthMeterReading);
				double netAmount = eBillService.calculateNetAmount(unitConsumed);
				Consumer consumer = new Consumer();
				consumer.setConsumerNumber(cnum2);
				consumer.setConsumerName(cname);
				BillDetail nextBill = new BillDetail(consumer, currentMonthMeterReading, unitConsumed, netAmount);
				int billNumber = eBillService.generateNextBill(nextBill);
				if (billNumber != 0){
					request.setAttribute("bill", nextBill);
					getServletContext().getRequestDispatcher(URLMapper.BILL_GENERATED).forward(request, response);
				} else{
					ServletException servletException = new ServletException("Error Generating Bill");
					throw servletException;
				}
			} catch (EBillException e) {
				ServletException servletException = new ServletException(e.getMessage() + cnum2, e);
				throw servletException;
			}
			break;
		default:
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
