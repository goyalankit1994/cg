package com.capgemini.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TruckBean;
import com.capgemini.dao.ITruckDao;


public interface ITruckService {
	List<TruckBean> retrieveTruckDetails() throws BookingException;
	int bookTrucks(BookingBean bookingBean) throws BookingException;
	
	void setDao(ITruckDao Dao);
	boolean Validation(String bean);
	public void closeconn() throws BookingException;
	boolean validatemobilenumber(String num);
	public boolean validateDate(LocalDate date);
	

}
