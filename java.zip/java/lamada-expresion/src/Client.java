
public class Client {

	public static void main(String[] args) {
MaxFinder ref =  (num1,num2)->num1>num2?num1:num2;
	int max = ref.maximum(34, 89);
System.out.println("maximum = "+max);

	}

}
