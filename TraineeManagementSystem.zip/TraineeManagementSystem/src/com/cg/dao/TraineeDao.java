package com.cg.dao;


import java.util.ArrayList;

import com.cg.bean.TraineeBean;
import com.cg.exception.TraineeException;

public interface TraineeDao {
	public TraineeBean addTraineeDetails(TraineeBean bean) throws TraineeException;
	public TraineeBean getDetails(int id) throws TraineeException ;
	public ArrayList<TraineeBean>  getallTraineeDetails() throws TraineeException;
	boolean modifyTrainee(int id, TraineeBean trainee) throws TraineeException;
	boolean removeTrainee(int id) throws TraineeException;
}
