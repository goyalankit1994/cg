package com.cg.tatasky.service;

import com.cg.tatasky.dao.TataSkyDao;
import com.cg.tatasky.dao.TataSkyDaoImpl;
import com.cg.tatasky.dto.TataSkyBean;
import com.cg.tatasky.exception.TataSkyException;

public class TataSkyServiceImpl implements TataSkyService {

	TataSkyDao tsd;
	public TataSkyServiceImpl() {
		// TODO Auto-generated constructor stub
		tsd=new TataSkyDaoImpl();
	}
	@Override
	public TataSkyBean getRecord(int patientId) throws TataSkyException {
		// TODO Auto-generated method stub
//		return null;
		return tsd.getRecord(patientId);
	}

	@Override
	public boolean rechargeTatasky(int id, int amount) throws TataSkyException {
		// TODO Auto-generated method stub
		return tsd.rechargeTatasky(id, amount);
	}

}
