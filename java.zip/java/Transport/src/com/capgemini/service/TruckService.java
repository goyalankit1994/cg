package com.capgemini.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TruckBean;
import com.capgemini.dao.ITruckDao;
import com.capgemini.dao.TruckDao;

public class TruckService implements ITruckService {
	ITruckDao dao = new TruckDao();

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {

		return dao.retrieveTruckDetails();
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		return dao.bookTrucks(bookingBean);
	}

	@Override
	public void setDao(ITruckDao Dao) {
		this.dao = dao;
		
	}

	@Override
	public boolean Validation(String bean) {
		String idPattern = "[A-Z]{1}[0-9]{6}";
		if (!Pattern.matches(idPattern, bean)) {
			System.out.println("invalid customer id ");
			return false;
		}
		return true;
	}

	@Override
	public void closeconn() throws BookingException {
		dao.closeconn();
		
	}

	@Override
	public boolean validatemobilenumber(String num) {
		String mobile = "[7-9][0-9]{9}";
		if(!Pattern.matches(mobile, num))
		{
			System.out.println("invalid mobile number");
			return false;
		}
				
		return true;
	}

	@Override
	public boolean validateDate(LocalDate date) {
		LocalDate today = LocalDate.now();
		Period diff = date .until(today);
		if(diff.getDays() < 0||diff.getMonths() < 0 ||diff.getYears() <0)
		{
			return true;
		}

	
	else
		System.out.println("invalid date");
	return false;
	

}

}

