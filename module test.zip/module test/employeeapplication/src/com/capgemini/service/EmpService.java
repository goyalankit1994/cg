package com.capgemini.service;

import java.util.List;

import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;

public interface EmpService {

	boolean validateName(String name);

	boolean saveEmp(Emp emp) throws EmpException;

	List<Emp> getEmpList() throws EmpException;

	void closeReaderWriter() throws EmpException;

	boolean deleteEmp(int id);

	boolean validateDesignation(String designation);

	boolean validateSalary(String next);

}
