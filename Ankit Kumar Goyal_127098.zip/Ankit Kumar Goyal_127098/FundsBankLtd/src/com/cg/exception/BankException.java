package com.cg.exception;

public class BankException extends Exception {
	String message;
	public BankException(String message)
		{
			this.message=message;
		}
	public String getMessage() {
				// TODO Auto-generated method stub
		return message;
		}
			
			
		}



