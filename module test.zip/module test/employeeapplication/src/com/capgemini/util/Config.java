package com.capgemini.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Config {

	//public static final String CHOICE = "DATABASE";
	//public static final String CHOICE = "FILE";
	Properties props = new Properties();
	
	public Config(){
		try {
			props.load(new FileInputStream("Config.txt"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
	
	public Properties getProps(){
		return props;
	}
}
