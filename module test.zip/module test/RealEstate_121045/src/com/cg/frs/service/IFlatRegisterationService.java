package com.cg.frs.service;

import java.util.List;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegisterationException;

/**
 * 
 * @author Dushyant
 * Interface for service layer class
 *
 */
public interface IFlatRegisterationService {

	boolean validateFlatType(String flatType);

	boolean validateFlatArea(String flatArea);

	boolean validateDesiredRentAmount(String desiredRentAmount);

	boolean validateDesiredDepositeAmount(String desiredDepositeAmount, Double desiredRentAmount);

	boolean validateOwnerID(String ownerID, List<Integer> ownerIdlist);

	boolean registerFlat(FlatRegistrationDTO flat) throws FlatRegisterationException;

	List<Integer> getAllOwnerIds() throws FlatRegisterationException;

}
