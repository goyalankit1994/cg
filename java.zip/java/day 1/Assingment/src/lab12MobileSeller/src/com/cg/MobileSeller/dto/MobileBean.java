package com.cg.MobileSeller.dto;

public class MobileBean {
private int mobileid;
private String name;
private int price;
private String Quantity;

public MobileBean(int mobileid, String name, int price, String quantity) {
	super();
	this.mobileid = mobileid;
	this.name = name;
	this.price = price;
	this.Quantity = quantity;
}

public MobileBean()
{
	
}

public int getMobileid() {
	return mobileid;
}

public void setMobileid(int mobileid) {
	this.mobileid = mobileid;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}

public String getQuantity() {
	return Quantity;
}

public void setQuantity(String quantity) {
	Quantity = quantity;
}

@Override
public String toString() {
	return "MobileBean [mobileid=" + mobileid + ", name=" + name + ", price="
			+ price + ", Quantity=" + Quantity + "]";
}

}
