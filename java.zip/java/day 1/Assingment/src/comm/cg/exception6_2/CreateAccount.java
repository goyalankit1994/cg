package comm.cg.exception6_2;

public class CreateAccount {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Account acc;
			try{
				acc = new Account(2000,new Person("smith",16 ));
				acc.deposit(2000);
				System.out.println(acc.getAccBalance());
				System.out.println(acc);
			}
			catch(AccountException e)
			{
				System.out.println(e.message);
			}
			
			
			Account acc1;
			try
			{
				acc1 = new Account(3000,new Person("Kathy",11));
				acc1.withdraw(3000);
				System.out.println(acc1.getAccBalance());
				System.out.println(acc1);
			}
			catch(AccountException e)
			{
				System.out.println(e.message);
			}
			
		
		}

	}
