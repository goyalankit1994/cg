package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.FinanceException;

public interface ILoanService {

	boolean validateCustomer(Customer customer);

	boolean validateEmail(String email);

	boolean validateMobile(String mobile);

	long insertCust(Customer customer) throws FinanceException;

	boolean validateLoanAmount(String loanAmount);

	boolean validateLoanDuration(String loanDuration);

	double calculateEMI(double loanAmount, int duration);

	long applyLoan(Loan loan) throws FinanceException;

}
