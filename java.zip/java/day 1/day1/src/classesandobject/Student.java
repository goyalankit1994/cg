package classesandobject;

public class Student {
	private int stuid;
	 private String stuname;
	 public Student()
	 {
		 stuid = 1;
		 stuname = "ankit";
	 }
	 public Student(int id, String name)
	 {
		 stuid = id;
		 stuname=name;
	 }
	public int getStuid() {
		return stuid;
	}
	public void setStuid(int stuid) {
		this.stuid = stuid;
	}
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

}
