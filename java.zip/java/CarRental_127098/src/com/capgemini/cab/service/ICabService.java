package com.capgemini.cab.service;

import java.sql.SQLException;

import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.exception.CabException;
import com.capgemini.cabs.bean.CabRequest;

public interface ICabService {
	Boolean addCabRequestDetails(CabRequest cabRequest)throws CabException,SQLException;
	CabRequest getRequestDetails(int requestId)throws CabException,SQLException;
	
	boolean isValidEnquiry(CabRequest req);
	void setDao(ICabRequestDAO dao);
	

}
