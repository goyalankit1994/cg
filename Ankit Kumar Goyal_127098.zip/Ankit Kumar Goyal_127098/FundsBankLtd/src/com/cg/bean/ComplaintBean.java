package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity
@Table(name="complaint")
@Component
public class ComplaintBean {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "complaintid")
	private int complaintid;
	@Column(name = "accountid",length=10)
	private int accountid;
	@NotEmpty(message="Branch Code is Manadatory")
	@Column(name = "branchcode" ,length=20)
	private String branchcode;
	@NotEmpty(message="Email is mandatory")
	@Email(message="Enter valid email id ")
	@Column(name = "emailid",length=20)
	private String emailid;
	@NotEmpty(message="Select any 1 Category")
	@Column(name = "category",length=20)
	private String category;
	@NotEmpty(message="Enter Description")
	@Column(name = "description",length=20)
	private String description;
	@Column(name = "priority",length=20)
	private String priority;
	@Column(name = "status",length=20)
	private String status;
	public int getComplaintid() {
		return complaintid;
	}
	public void setComplaintid(int complaintid) {
		this.complaintid = complaintid;
	}
	public int getAccountid() {
		return accountid;
	}
	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}
	public String getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ComplaintBean [complaintid=" + complaintid + ", accountid="
				+ accountid + ", branchcode=" + branchcode + ", emailid="
				+ emailid + ", category=" + category + ", description="
				+ description + ", priority=" + priority + ", status=" + status
				+ "]";
	}
	

}
