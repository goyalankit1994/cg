package lab10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Config {
	public Properties props = new Properties();
	public Config() {
	try {
		props.load(new FileInputStream("PersonProps.properties"));
		
	
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
	}
	public Properties getProps(){
		return props;
	}
	
}
