package com.cg.frs.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegisterationException;
import com.cg.frs.service.FlatRegisterationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;

/**
 * 
 * @author Dushyant
 * @version 1.0
 * This class Contains the main function
 */
public class Client {

	static Scanner input = new Scanner(System.in);
	static boolean execute = true;

	static IFlatRegisterationService flatRegisterationService = new FlatRegisterationServiceImpl();

	public static void main(String[] args) {
		String choice = null;

		while (execute) {
			System.out.println("**************************");
			System.out.println("1. Register Flat");
			System.out.println("2. Exit");
			System.out.println("Enter Your Choice : ");
			choice = input.next();
			executeChoice(choice);
		}
	}

	/**
	 * This executes the menu as per the choice
	 * @param choice
	 */
	private static void executeChoice(String choice) {
		boolean isValid = false;
		FlatRegistrationDTO flat = new FlatRegistrationDTO();
		List<Integer> ownerIdlist = null;

		switch (choice) {

		case "1":
			String ownerID = null;
			String flatType = null;
			String flatArea = null;
			String desiredRentAmount = null;
			String desiredDepositeAmount = null;

			System.out.println("*******Flat Resgisteration**********");
			if (ownerIdlist == null) {
				try {
					ownerIdlist = flatRegisterationService.getAllOwnerIds();
				} catch (FlatRegisterationException e) {
					System.err.println(e.getMessage());
				}
			}
			while (!isValid) {
				System.out.print("Existing Owner IDS are :- [");
				for (int i = 0; i < ownerIdlist.size(); i++) {
					if (i == ownerIdlist.size() - 1)
						System.out.print(ownerIdlist.get(i) + "]");
					else
						System.out.print(ownerIdlist.get(i) + ",");
				}
				System.out.println("\nEnter Owner ID From Above List :");
				ownerID = input.next();
				isValid = flatRegisterationService.validateOwnerID(ownerID,
						ownerIdlist);
				if (!isValid) {
					System.err
							.println("No Owner ID Exist OR enter owner ID correctly");
				}
			}
			flat.setOwnerID(Integer.parseInt(ownerID));
			isValid = false;

			while (!isValid) {
				System.out.println("Select Flat Type (1 - 1BHK, 2 - 2BHK) : ");
				flatType = input.next();
				isValid = flatRegisterationService.validateFlatType(flatType);
				if (!isValid) {
					System.err.println("Select Flat Type Either 1 or 2");
				}
			}
			flat.setFlatType(Integer.parseInt(flatType));
			isValid = false;

			while (!isValid) {
				System.out.println("Enter Flat Area In sq. ft. : ");
				flatArea = input.next();
				isValid = flatRegisterationService.validateFlatArea(flatArea);
				if (!isValid) {
					System.err
							.println("Flat Area Can Have Only Four Digits OR Enter Flat Area Correctly");
				}
			}
			flat.setFlatArea(Integer.parseInt(flatArea));
			isValid = false;

			while (!isValid) {
				System.out.println("Enter Desired Rent Amount Rs : ");
				desiredRentAmount = input.next();
				isValid = flatRegisterationService
						.validateDesiredRentAmount(desiredRentAmount);
				if (!isValid) {
					System.err.println("Enter Rent Amount Correctly");
				}
			}
			flat.setRentAmount(Double.parseDouble(desiredRentAmount));
			isValid = false;

			while (!isValid) {
				System.out.println("Enter Desired Deposite Amount : ");
				desiredDepositeAmount = input.next();
				isValid = flatRegisterationService
						.validateDesiredDepositeAmount(desiredDepositeAmount,
								flat.getRentAmount());
				if (!isValid) {
					System.err
							.println("Deposite Amount Cannot Be Less Than Rent Amount Or Enter Deposite Amount Correctly");
				}
			}
			flat.setDepositeAmount(Double.parseDouble(desiredDepositeAmount));
			isValid = false;

			try {
				isValid = flatRegisterationService.registerFlat(flat);
				System.out.println("Flat Registeration Successful");
			} catch (FlatRegisterationException e) {
				System.err.println("Flat Registeration Failed");
				System.err.println(e.getMessage());
			}

			break;

		case "2":
			System.out.println("Thanks For Using the Application");
			execute = false;
			input.close();
			break;
		default:
			System.err.println("Invalid Choice");
			break;
		}
	}
}
