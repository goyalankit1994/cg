package comm.cg.inheritence.shape;

public class Circle extends Shape
{
private double radius;
public Circle()
{
	
}
public Circle(double radius)
{
	this.radius=radius;
	
}
public double getRadius() {
	return radius;
}
public void setRadius(double radius) {
	this.radius = radius;
}
@Override
public String toString() {
	return "Circle [radius=" + radius + "]";
}
@Override
public double calArea()
{

	return  this.radius*this.radius*3.14;
	}
}
