package com.cg.lab11.exception;

public class PurchaseOrderException extends Exception{
	String msg;
	public PurchaseOrderException(String msg) {
		this.msg = msg;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		//return super.getMessage();
		return msg;
	}
}
