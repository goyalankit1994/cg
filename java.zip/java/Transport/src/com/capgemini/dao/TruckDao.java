package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.Exception.BookingException;
import com.capgemini.Loger.MyLogger;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TruckBean;
import com.capgemini.dbutil.DbUtill;


public class TruckDao implements ITruckDao {
	Logger logger = MyLogger.getLoggerInsatnce();
	Connection con;
	public TruckDao()
	{
		con = DbUtill.getConnection();
		if(con!=null)
		{
			logger.info("obtained connection");
		}
	}

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		String sql = "SELECT * FROM TruckDetails ";
		List<TruckBean> list = new ArrayList<TruckBean>();
		try
		{
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			while(result.next())
			{
				TruckBean truckBean = new TruckBean();
				truckBean.setTruckId(result.getInt(1));
				truckBean.setTrucktype(result.getString(2));
				truckBean.setOrigin(result.getString(3));
				truckBean.setDestination(result.getString(4));
				truckBean.setCharges(result.getFloat(5));
				truckBean.setAvailablenos(result.getInt(6));
				list.add(truckBean);
				logger.info("fetch record"+truckBean);
			}
		}
	catch(Exception e)
		{
		logger.error("exception occured during get by id"+e.getMessage());
		e.printStackTrace();
		}
		return list;
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		String sql = "INSERT INTO bookingdetails VALUES(bookind_id_seq.NEXTVAL,?,?,?,?,?)";
		try
		{
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1,bookingBean.getCustid());
			pstmt.setLong(2,bookingBean.getCustMobile());
			if(ValidateTruckId(bookingBean.getTruckid()))
					pstmt.setInt(3,bookingBean.getTruckid());
			if(ValidateAvailability(bookingBean))
			pstmt.setInt(4,bookingBean.getNooftrucks());
			pstmt.setDate(5,Date.valueOf(bookingBean.getDateoftransport()));
			int row = pstmt.executeUpdate();
			if(row == 0)
				throw new BookingException("booking not cancel");
			else
			{
				logger.info("inserted record"+bookingBean);
				String sql1 = "UPDATE truckdetails set availablenos=availablenos-? where truckid = ?";
				PreparedStatement pstmt1 = con.prepareStatement(sql1);
				pstmt1.setInt(1,bookingBean.getNooftrucks());
				pstmt1.setInt(2,bookingBean.getTruckid());
				int row1 = pstmt1.executeUpdate();
				if(row1 ==0)
					throw new BookingException("not updated successfully");
				else
				{
					String sql2 = "Select MAX(bookingId) FROM bookingdetails";
					PreparedStatement pstmt2 = con.prepareStatement(sql2);
					ResultSet res = pstmt2.executeQuery();
					if(res.next())
						System.out.println("booking id is :"+res.getInt(1));
					return 1;	
				}
					
			}
		}
		catch(Exception e)
		{
			logger.error("exception occured"+e.getMessage());
			e.printStackTrace();
		}
		return 0 ;
	}
	public boolean ValidateTruckId(int truckId) throws BookingException
	{
		try
		{
			String sql ="SELECT * FROM TRUCKDETAILS WHERE truckid = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, truckId);
			int row = pstmt.executeUpdate();
			if(row ==0)
			{
				throw new BookingException("CUSTID = "+truckId+"does not exist");
				
			}
		}
		catch(SQLException e)
		{
			logger.error("exception occured"+e.getMessage());
			throw new BookingException(e.getMessage());
		}
		return true;
	}
	public boolean ValidateAvailability(BookingBean bean) throws BookingException
	{
		try
		{
			String sql = "SELECT AVAILABLENOS FROM TRUCKDETAILS WHERE TRUCKID = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bean.getTruckid());
			ResultSet result = pstmt.executeQuery();
			int freeTruck = 0;
			if(result.next())
			freeTruck = result.getInt(1);
			if(bean.getNooftrucks()==0||freeTruck==0||freeTruck<bean.getNooftrucks())
			{
				throw new BookingException("free trucks are "+freeTruck+"and requested trucks are "+bean.getNooftrucks());
				
			}
			
				}
		catch(SQLException e)
		{
			logger.error("exception occured "+e.getMessage());
			throw new BookingException(e.getMessage());
		}
		return true;
	}

	@Override
	public void closeconn() throws BookingException {
		try
		{
			con.close();
		}
		catch(SQLException e)
		{
			throw new BookingException("connection not closed");
		}
		
	}

}
