package lab13;

public class MyRunnable implements Runnable {
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("run...." + i);
			try {
				Thread.sleep(2);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		
		Runnable mr = new MyRunnable();
		Thread t = new Thread(mr);
		t.start();
		for (int i = 0; i < 10; i++) {
			System.out.println("main...." + i);
			try {
				Thread.sleep(2);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
