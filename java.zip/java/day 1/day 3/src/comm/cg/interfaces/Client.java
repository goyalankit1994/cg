package comm.cg.interfaces;

public class Client {

	public static void main(String[] args) {
	Service ref = new Serivceimpl();
	System.out.println(ref.add(1, 2));
	System.out.println(ref.sub(1, 2));
	//ref.multiply(3,4);

	}

}
