package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.FinanceException;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {

	static Scanner input = new Scanner(System.in);
	static boolean execute = true;

	static ILoanService lService = new LoanService();

	static long custId;
	static long loanId;

	public static void main(String[] args) {
		String choice = null;

		while (execute) {
			System.out.println("\n\nXYZ Finance Company Welcomes you");
			System.out.println("1. Register Customer");
			System.out.println("2. Apply for Loan");
			System.out.println("3. Exit");
			System.out.println("Enter Your Choice : ");
			choice = input.next();
			executeChoice(choice);
		}
	}

	private static void executeChoice(String choice) {
		boolean isValid = false;
		String name = null;
		String address = null;
		String email = null;
		String mobile = null;
		String loanAmount = null;
		String loanDuration = null;

		switch (choice) {
		case "1":
			Customer customer = new Customer();
			System.out.println("******Customer Details********");

			while (!isValid) {
				System.out.println("Enter Customer Name : ");
				name = input.next();
				customer.setCustName(name);
				System.out.println("Enter Address : ");
				address = input.next();
				customer.setAddress(address);
				isValid = lService.validateCustomer(customer);
				if (!isValid) {
					System.out.println("Enter Name and Address Correctly");
				}
			}
			isValid = false;

			while (!isValid) {
				System.out.println("Enter Email : ");
				email = input.next();
				isValid = lService.validateEmail(email);
				if (!isValid) {
					System.out.println("Enter Email Correctly");
				}
			}
			customer.setEmail(email);
			isValid = false;

			while (!isValid) {
				System.out.println("Enter Mobile : ");
				mobile = input.next();
				isValid = lService.validateMobile(mobile);
				if (!isValid) {
				System.out.println("Enter Mobile Number Correctly");
				}
			}
			customer.setMobile(Long.parseLong(mobile));
			isValid = false;

			try {
				custId = lService.insertCust(customer);
				if (custId != 0) {
					System.out
							.println("\nCustomer Information saved successfully");
					System.out.println("Your Customer Id is " + custId);
				} else {
					System.err.println("Customer Information Not Saved");
				}
			} catch (FinanceException e) {
				System.err.println(e.getMessage());
			}
			break;

		case "2":
			Loan loan = new Loan();

			loan.setCustId(custId);

			while (!isValid) {
				System.out.println("Enter the Loan Amount : ");
				loanAmount = input.next();
				isValid = lService.validateLoanAmount(loanAmount);
				if (!isValid) {
					System.out.println("Enter Loan Amount Correctly");
				}
			}
			isValid = false;
			loan.setLoanAmount(Double.parseDouble(loanAmount));

			while (!isValid) {
				System.out.println("Enter the Loan Duration : ");
				loanDuration = input.next();
				isValid = lService.validateLoanDuration(loanDuration);
				if (!isValid) {
					System.out.println("Enter Loan Duration Correctly");
				}
			}
			isValid = false;
			loan.setDuration(Integer.parseInt(loanDuration));

			double eMI = lService.calculateEMI(loan.getLoanAmount(),
					loan.getDuration());

			System.out.println("For loan Amount " + loan.getLoanAmount()
					+ " and " + loan.getDuration() + " Years duration");
			System.out.println("Your EMI per month will be " + eMI);
			System.out.println("Do You Want to apply For Loan now? (Yes/No) ");
			String wantLoan = input.next();

			if (wantLoan.equalsIgnoreCase("yes")) {
				try {
					loanId = lService.applyLoan(loan);
					if (loanId != 0) {
						System.out.println("Your Loan request is generated");
						System.out.println("your Loan ID is " + loanId);
					} else {
						System.err.println("Unable to generate Loan request ");
					}
				} catch (FinanceException e) {
					System.err.println(e.getMessage());
				}	
			} else if (wantLoan.equalsIgnoreCase("no")) {
				System.out.println("Existing Loan Procedure");
			} else {
				System.err.println("Invalid Input");
			}

			break;

		case "3":
			System.out.println("Thanks for using the application");
			execute = false;
			break;

		default:
			System.err.println("Invalid Choice");
			break;
		}

	}
}
