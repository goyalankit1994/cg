package com.cg.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTest {
	  Calculator obj = null;
	@Before
 	 public void init()
	{
		 obj = new Calculator();
		System.out.println("At bfore");
	}

	@Test
	public void testAdd() {
		assertNotEquals(0,obj.add(2,4));
	}
	//@Ignore
	@Test
	public void testMultiply() {
		assertNotEquals(0,obj.multiply(3, 8));
	}

	@Test(expected = ArithmeticException.class)
	public void testDivide() {
		assertEquals(0,obj.divide(4, 2));
	}
	@After                              //static method can be used after class and before class
	 public  void destroy()
	{
		obj = null;
		System.out.println("at after");
	}

}
