package com.cg.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
@Entity
@Table(name="cabrequest")
@Component
public class CabRequest {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "requestId")
	private int requestId;	
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-Z]{1}[a-z]{2,20}", message="First word should be capital and minimum three words is required")
	//@Size(min=4,max=20,message="Minimum 4 and Maximum 20 characters required")
	@Column(name = "customerName")
	private String customerName;
	@Column(name = "phoneNumber")
	@NotEmpty(message="Phone number is mandatory")
	@Pattern(regexp="[0-9]{10}",message="10 digits required")
	private String phoneNumber;
	@Column(name = "dateOfRequest")
	private LocalDate dateOfRequest;
	@Column(name = "requestStatus")
	private String requestStatus;
	@Column(name = "cabNumber")
	private String cabNumber;
	@Column(name = "addOfPick")
	@NotEmpty(message="Address is mandatory")
	private String addOfPick;
	@Column(name = "pincode")
	@NotEmpty(message="Pincode is mandatory")
	@Pattern(regexp="[0-9]{6}",message="6 digits required")
	private String pincode;
	
	
	
	
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getDateOfRequest() {
		return dateOfRequest;
	}
	public void setDateOfRequest(LocalDate dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public String getAddOfPick() {
		return addOfPick;
	}
	public void setAddOfPick(String addOfPick) {
		this.addOfPick = addOfPick;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "CabRequest [requestId=" + requestId + ", customerName="
				+ customerName + ", phoneNumber=" + phoneNumber
				+ ", dateOfRequest=" + dateOfRequest + ", requestStatus="
				+ requestStatus + ", cabNumber=" + cabNumber + ", addOfPick="
				+ addOfPick + ", pincode=" + pincode + "]";
	}
	
	
	

}
