package com.capgemini.onlinegaming.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.onlinegaming.bean.GameBean;
import com.capgemini.onlinegaming.bean.UsersBean;
import com.capgemini.onlinegaming.dbutil.DBUtil;
import com.capgemini.onlinegaming.exception.GameException;



public class ProcessDaoImpl implements ProcessDao {
Connection con;
	
	public ProcessDaoImpl()
	{
		con = DBUtil.getConnection();
	}

	@Override
	public long insertUser(UsersBean bean) throws GameException {

		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		int user_id=0;
		int queryResult=0;
		try
		{		
			String sql ="INSERT INTO users VALUES(seq_users.NEXTVAL,?,?)";
			preparedStatement=con.prepareStatement(sql);

			preparedStatement.setString(1,bean.getName());			
			preparedStatement.setString(2,bean.getAddress());
			preparedStatement.setInt(3,bean.getCard_amt());			
			
			queryResult=preparedStatement.executeUpdate();
		
			String sql1="SELECT seq_users.CURRVAL FROM DUAL";
			preparedStatement = con.prepareStatement(sql1);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				 user_id=resultSet.getInt(1);
						
			}
			if(queryResult==0)
			{
				
				throw new GameException("Inserting donor details failed ");

			}
			}
		catch(SQLException e)
		{
			
			throw new GameException("not inserted");
		}
	
		return 0;
	}

	@Override
	public List<GameBean> getAllRecord() throws GameException {
		List<GameBean> list = new ArrayList<>();
		try {
			String sql = "SELECT * FROM ONLINEGAMES";
			Statement statement = con.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				GameBean bean = new GameBean();
				bean.setName(result.getString(1));
				bean.setAmount(result.getInt(2));
				list.add(bean);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}
}


