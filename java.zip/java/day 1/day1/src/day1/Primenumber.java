package day1;
public class Primenumber {

	public static void main(String[] args) 
	{
	int n,div;
	for(n=2;n<=100;n++)
	{
		int isPrime = 0;
		for(div=2;div<n/2;div++)
		{
			if(n%div==0)
			{
				isPrime = 1;
				break;
			}
	}
		if(isPrime == 0 && n!=1)
		System.out.println("prime numbers are " +n);
		// TODO Auto-generated method stub}

}
}
}