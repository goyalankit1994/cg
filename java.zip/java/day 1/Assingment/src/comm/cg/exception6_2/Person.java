package comm.cg.exception6_2;

public class Person {
	private String name;
	private float age;
	
	public Person()  //default constructor
	{
		
	}
	
	public Person(String name , float age) throws AccountException //parameterized constructor
	{
		//super();
		this.name = name;
		if(age<15)
		{
			throw new AccountException(name +" Age is not valid to open an account");
		}
		else
		{
		this.age = age;
		}
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
}
