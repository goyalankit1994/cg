package lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class UserDate {

	public static void main(String[] args) {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc  = new Scanner(System.in);
		System.out.println("Enter Date 1 ::");
		String udate = sc.next();
		LocalDate date = LocalDate.parse(udate,format);
		System.out.println("date 1 :"+date);
		System.out.println("Enter Date 2 ::");
		String udate1 = sc.next();
		LocalDate date1 = LocalDate.parse(udate1,format);
		System.out.println("date 2 is : "+date1);
		 Period diff = date.until(date1);
		 System.out.println("diff in date are " +diff.getDays()+ "days" +diff.getMonths() +"months"+diff.getYears()+"years");
		
		

	}

}
