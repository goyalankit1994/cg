/**
 * 
 */
package com.capgemini.xyz.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.xyz.exception.FinanceException;
import com.sun.swing.internal.plaf.metal.resources.metal;

/**
 * @author Dushyant
 * @version 1.0
 * This Class creates an SQL connection to oracle database and returns it 
 */

public class DBUtil {
	static Connection conn;
	static Logger logger = Logger.getLogger(DBUtil.class);
	
	
	public static Connection getConnection() throws FinanceException{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			if (conn == null || conn.isClosed()) {
				conn = DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
				logger.info(Messages.CONNECTION_ESTABLISHED);
			}
		} catch (SQLException e) {
			logger.error(Messages.DB_CONN_ERROR + e);
			throw new FinanceException(Messages.DB_CONN_ERROR);
		} catch (ClassNotFoundException e) {
			logger.error(Messages.CLASS_NOT_FOUND_ERROR + e);
			throw new FinanceException(Messages.CLASS_NOT_FOUND_ERROR);
		}
		return conn;
	}
}

