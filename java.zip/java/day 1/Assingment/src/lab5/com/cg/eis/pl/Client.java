package lab5.com.cg.eis.pl;

import java.util.Scanner;

import lab5.com.cg.eis.bean.Employee;
import lab5.com.cg.eis.service.Service;
import lab5.com.cg.eis.service.ServiceInterface;
public class Client {
 static ServiceInterface Service1 = new Service();
	public static void main(String[] args) {
		Employee emp = new Employee();
		Scanner input = new Scanner(System.in);
		System.out.println("----------------Enter employee details------------------------ ");
		System.out.println("enter id of employee");
		emp.id = input.nextInt();
		System.out.println("Enter name of employee");
		emp.name=input.next();
		System.out.println("enter salary of employee");
		emp.salary=input.nextDouble();
		System.out.println("enter designation of employee");
		emp.designation=input.next();
		emp.setInsuranceScheme(Service1.getInsuranceScheme(emp.getSalary(),emp.getDesignation()));
		//Service1. getInsuranceScheme(emp.salary , emp.designation );
		//emp.getInsuranceScheme();
		if ( emp.getInsuranceScheme() != "N")
			System.out.println("\nScheme : " + emp.getInsuranceScheme());
		else
			System.out.println("\nScheme : No Scheme");
		System.out.println("Details of employee");
		System.out.println("Employee id is "+emp.id);
		System.out.println("Employee name is :"+emp.name);
		System.out.println("Employee salary is :" +emp.salary);
		System.out.println("Employee designation is :"+emp.designation);
		System.out.println("Insurance scheme given to employee is :"+emp.InsuranceScheme);
		
		

	}

}
