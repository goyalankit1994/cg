package lab6;

public class PersonMain {

	public static void main(String[] args) {
		Person per;
	try
	{
		per = new Person("","goyal","male","8239161121") ;
        System.out.println("Person Details");
		   System.out.println("---------------------------");
		   System.out.println("first name is ::" +per.getFname());
		   System.out.println("last name is ::"+per.getLname());
		  System.out.println("gender is ::"+per.getGender());
		  System.out.println("mobile no is ::"+per.getMobileno());
	}
catch(PersonException e)
	{
	System.out.println(e.message);
	}
	}

}
