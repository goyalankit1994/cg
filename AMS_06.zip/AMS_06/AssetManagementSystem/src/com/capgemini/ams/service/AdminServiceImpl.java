package com.capgemini.ams.service;


import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.dao.AdminDAOImpl;
import com.capgemini.ams.dao.IAdminDAO;
import com.capgemini.ams.exception.AssetException;

public class AdminServiceImpl implements IAdminService {

	IAdminDAO adminDao;
	public AdminServiceImpl() {
		// TODO Auto-generated constructor stub
	adminDao = new AdminDAOImpl();
	}
	
	public void setDao(AdminDAOImpl adminDao) {
		// TODO Auto-generated method stub
		this.adminDao = adminDao;
	}

	
	@Override
	public boolean addAsset(Asset asset) throws AssetException {
		// TODO Auto-generated method stub
		return adminDao.addAsset(asset);
	}

	@Override
	public boolean updateAsset(int assetId, int quantity) throws AssetException {
		// TODO Auto-generated method stub
		return adminDao.updateAsset(assetId,quantity);
	}

	@Override
	public boolean allocateAsset(int requestId, LocalDate releaseDate) throws AssetException{
		// TODO Auto-generated method stub
		return adminDao.allocateAsset(requestId,releaseDate);
	}

	@Override
	public boolean updateStatus(int requestId) throws AssetException {
		// TODO Auto-generated method stub
		return adminDao.updateStatus(requestId);
	}

	@Override
	public boolean generateReport() throws AssetException {
		// TODO Auto-generated method stub
		return adminDao.generateReport();
	}

	


}
