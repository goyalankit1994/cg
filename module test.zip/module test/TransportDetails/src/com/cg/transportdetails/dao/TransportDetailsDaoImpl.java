package com.cg.transportdetails.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.transportdetails.dbutil.DbUtil;
//import com.cg.patientdetails.dbutil.DbUtil;
import com.cg.transportdetails.dto.BookingBean;
import com.cg.transportdetails.dto.TruckBean;
import com.cg.transportdetails.exception.TransportException;

public class TransportDetailsDaoImpl implements TransportDetailsDao{

	Connection con;
	public TransportDetailsDaoImpl() {
		// TODO Auto-generated constructor stub
		con = DbUtil.getConnection();
	}
	
	@Override
	public List<TruckBean> retrieveTransportDetails() throws TransportException {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM TRUCKDETAILS";
		List<TruckBean> list = new ArrayList<TruckBean>();
		try{
		Statement stmt= con.createStatement();
		ResultSet result=stmt.executeQuery(sql);
//		System.out.println("hi"+result.next());
		while(result.next())
		{
			TruckBean truckBean=new TruckBean();
			truckBean.setTruckid(result.getInt(1));
			truckBean.setTrucktype(result.getString(2));
			truckBean.setOrigin(result.getString(3));
			truckBean.setDestination(result.getString(4));
			truckBean.setCharges(result.getFloat(5));
			truckBean.setAvailableNos(result.getInt(6));
			list.add(truckBean);
//			System.out.println("Truct Id= "+result.getInt(1)+" Truct Type "+result.getString(2)+" ORIGIN= "+result.getString(3));
//			System.out.println(" Destination= "+result.getString(4)+" Charges "+result.getFloat(5)+" Available No of Trucks "+result.getInt(6));
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws TransportException {
		// TODO Auto-generated method stub

		String sql="INSERT INTO BOOKINGDETAILS VALUES(book_seq.NEXTVAL,?,?,?,?,?)";
		try{
			PreparedStatement pstmt=con.prepareStatement(sql);
			//pstmt.setInt(1, bookingBean.getBookingId());
			pstmt.setString(1,bookingBean.getCustId());
			pstmt.setLong(2, bookingBean.getCustMobile());
			if(validateTruckId(bookingBean.getTruckId()))
				pstmt.setInt(3,bookingBean.getTruckId());
			if(validateAvailability(bookingBean))
				pstmt.setInt(4, bookingBean.getNoOfTruck());
			pstmt.setDate(5, Date.valueOf(bookingBean.geDateOfTransport()));
			
			int row = pstmt.executeUpdate();
			if(row==0)
				throw new TransportException("Booking not cancel");
			else
			{
				String sql1="Update truckdetails set availablenos=availablenos-? where truckid=?";
				PreparedStatement pstmt1= con.prepareStatement(sql1);
				
				pstmt1.setInt(1, bookingBean.getNoOfTruck());
				pstmt1.setInt(2,bookingBean.getTruckId());
				
				int row1=pstmt1.executeUpdate();
				if(row==0)
					throw new TransportException("NOt Updated Successfully");
				else		
				{
					String sql2="Select max(bookinid) from bookingdetails";
					PreparedStatement pstmt2=con.prepareStatement(sql2);
					ResultSet rs= pstmt2.executeQuery();
					if(rs.next())
						System.out.println("Booking id is "+rs.getInt(1));
//					int bookingid=
					return 1;
				}
		
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
//		System.out.println();
		return 0;
	}
	
	public boolean validateTruckId(int truckid) throws TransportException
	{
		try {
			String sql="SELECT * FROM truckDetails WHERE truckid=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, truckid);
			int row = pstmt.executeUpdate();
			if(row==0)
				throw new TransportException("cust id = "+truckid+" does not exists");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new TransportException(e.getMessage());
		}
		return true;
		
	}
	
	public boolean validateAvailability(BookingBean bean) throws TransportException
	{
		try {
			String sql="SELECT availablenos FROM TruckDetails Where truckid=?";
			PreparedStatement pstmt= con.prepareStatement(sql);
			pstmt.setInt(1, bean.getTruckId());
			ResultSet result=pstmt.executeQuery();
			int freeTrucks=0;
			if(result.next())
				freeTrucks=result.getInt(1);
			if(bean.getNoOfTruck()==0 || freeTrucks==0 || freeTrucks<bean.getNoOfTruck())
			{
				throw new TransportException("free trucks are "+freeTrucks+" and requested trucks are "+bean.getNoOfTruck());

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new TransportException(e.getMessage());
		}
		return true;
	}

}
