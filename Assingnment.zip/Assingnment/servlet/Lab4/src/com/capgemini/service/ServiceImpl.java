package com.capgemini.service;

import com.capgemini.bean.Bean;
import com.capgemini.dao.DAOImpl;
import com.capgemini.dao.IDAO;

public class ServiceImpl implements IService {

	IDAO Dao = new DAOImpl();
	
	@Override
	public boolean insert(Bean bean) {
		
		return Dao.insert(bean);
	}

}
