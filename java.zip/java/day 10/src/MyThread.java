
public class MyThread implements Runnable {
	
@Override
public void run()
{
	System.out.println("current thread ="+Thread.currentThread().getName());
	System.out.println("current thread="+Thread.currentThread().getPriority());
	for(int i=0;i<20;i++)
	{
		System.out.println("current thread in for "+Thread.currentThread().getName());
		System.out.println(i);
		try {
			Thread.currentThread().join(200);
			//Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	System.out.println("alive thread = "+Thread.currentThread().isAlive());
}
}
