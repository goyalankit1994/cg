package com.cg.DthRecharge.Service;

import com.cg.DthRecharge.Exception.DthException;
import com.cg.DthRecharge.dao.DthDao;
import com.cg.DthRecharge.dto.DthRechargeBean;




public interface DthService {
	public DthRechargeBean getRecord(int userid)
			throws DthException;
	public boolean Recharge() throws DthException;
	public int CheckBalance (int userid)
	        throws DthException;
	public void setDao(DthDao dao);
}
