package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.ComplaintBean;
import com.cg.dao.ICustomerDao;
import com.cg.exception.BankException;
@Service
@Transactional
public class CustomerServiceImpl  implements ICustomerService{
	@Autowired
	private ICustomerDao Dao;


	@Override
	public ComplaintBean raiseCustomerComplaint(ComplaintBean bean)
			throws BankException {
		// TODO Auto-generated method stub
		return Dao.raiseCustomerComplaint(bean);
	}

	@Override
	public ComplaintBean checkComplaintStatus(int complaintid)
			throws BankException {
		// TODO Auto-generated method stub
		return Dao.checkComplaintStatus(complaintid);
	}

	@Override
	public int getComplaintId(ComplaintBean bean) throws BankException {
		// TODO Auto-generated method stub
		return Dao.getComplaintId(bean);
	}

}
