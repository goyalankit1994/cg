package com.cg.MobileSeller.Service;

import java.util.List;
import java.util.Map;

import com.cg.MobileSeller.Exception.MobileException;
import com.cg.MobileSeller.dao.MobileDao;
import com.cg.MobileSeller.dto.MobileBean;
import com.cg.MobileSeller.dto.PurchaseBean;

public interface MobileInterface {
	boolean validateName(String cname);
	
	boolean validateMailId(String mailid);
	

	boolean validatePhoneNo(String phoneNo);

	boolean validateMobileId(String temp);

	boolean saveCust(PurchaseBean cus) throws MobileException;
	

	Map<Integer, Integer> getMobiles() throws  MobileException;
	

	List<MobileBean> getMobList() throws  MobileException;

	boolean deleteMobile(int mobileid_delete) throws  MobileException;
	

	List<MobileBean> getMobPriceList(int p1, int p2) throws  MobileException;
	

	boolean checkMobileId(int mobileId) throws  MobileException;

	void setDao(MobileDao dao);

	
	
	
}
