package com.capgemini.dao;

import com.capgemini.bean.Bean;

public interface IDAO {

	boolean insert(Bean bean);

}
