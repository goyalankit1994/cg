package com.cg.lab11.dao;

import java.util.ArrayList;

import com.cg.lab11.dto.MobileAppBean;
import com.cg.lab11.dto.PurchaseDetailsBean;
import com.cg.lab11.exception.PurchaseOrderException;

public interface MobileAppDao {
	public boolean purchaseMobile(PurchaseDetailsBean bean) throws PurchaseOrderException;
	public boolean updateMobileDb(PurchaseDetailsBean bean) throws PurchaseOrderException;
	public boolean searchMobile(int min, int max) throws PurchaseOrderException;
	public ArrayList<MobileAppBean> getAllMobileRecords() throws PurchaseOrderException; 
	public boolean deleteMobile(int mobileId)throws PurchaseOrderException;
}
