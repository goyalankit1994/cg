package lab6.com.cg.eis.pl;

import java.util.Scanner;

import lab6.com.cg.eis.bean.Employee;
import lab6.com.cg.eis.bean.EmployeeException;
import lab6.com.cg.eis.service.Service;
import lab6.com.cg.eis.service.ServiceInterface;

public class Client {

	static ServiceInterface eService = new Service();

	public static void main(String[] args) {

		Employee emp = new Employee();
		Scanner input = new Scanner(System.in);

		System.out.println("Enter Employee Details : ");
		System.out.println("Enter ID :");
		emp.setId(input.nextInt());
		System.out.println("Enter Name : ");
		emp.setName(input.next());
		System.out.println("Enter Designation : ");
		emp.setDesignation(input.next());
		while (true) {
			System.out.println("Enter Salary : ");
			try {
				emp.setSalary(input.nextDouble());
				break;
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
		emp.setInsuranceScheme(eService.getInsuranceScheme(emp.getSalary(),
				emp.getDesignation()));
		System.out.println("\n********Entered Employee Details**********");
		System.out.println("\nID : " + emp.getId());
		System.out.println("\nName : " + emp.getName());
		System.out.println("\nDesignation : " + emp.getDesignation());
		System.out.println("\nSalary : " + emp.getSalary());
		if (emp.getInsuranceScheme() != "N")
			System.out.println("\nScheme : " + emp.getInsuranceScheme());
		else
			System.out.println("\nScheme : No Scheme");
		input.close();
	}
}
