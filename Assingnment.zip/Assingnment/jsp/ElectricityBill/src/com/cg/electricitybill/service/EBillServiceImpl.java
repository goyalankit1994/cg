package com.cg.electricitybill.service;

import java.util.List;

import com.cg.electricitybill.bean.BillDetailsBean;
import com.cg.electricitybill.bean.ConsumersBean;
import com.cg.electricitybill.dao.EBillDao;
import com.cg.electricitybill.dao.EBillDaoImpl;
import com.cg.electricitybill.exception.ElectricityException;


public class EBillServiceImpl implements EBillService {
	EBillDao dao;
	private final double perUnitCharge = 5;
	public EBillServiceImpl() {
		// TODO Auto-generated constructor stub
		dao = new EBillDaoImpl();
	}

	@Override
	public List<ConsumersBean> getConsumers() throws ElectricityException {
		// TODO Auto-generated method stub
		return dao.getConsumers();
	}

	@Override
	public ConsumersBean searchConsumer(int consumer_num)
			throws ElectricityException {
		// TODO Auto-generated method stub
		return dao.searchConsumer(consumer_num);
	}

	@Override
	public List<BillDetailsBean> getBillDetails(int cnum)
			throws ElectricityException {
		// TODO Auto-generated method stub
		return dao.getBillDetails(cnum);
	}

	@Override
	public int generateNextBill(BillDetailsBean nextBill)
			throws ElectricityException {
		// TODO Auto-generated method stub
		return dao.generateNextBill(nextBill);
	}

	@Override
	public int calculateUnitConsumed(int lastMonthMeterReading,
			int currentMonthMeterReading) throws ElectricityException {
		
		if (lastMonthMeterReading > currentMonthMeterReading)
			throw new ElectricityException("Current reading Cannot be less than last Month reading");
		return (currentMonthMeterReading - lastMonthMeterReading);
	}

	@Override
	public double calculateNetAmount(int unitConsumed) {
	
	
		return (unitConsumed * perUnitCharge);
		}

}
