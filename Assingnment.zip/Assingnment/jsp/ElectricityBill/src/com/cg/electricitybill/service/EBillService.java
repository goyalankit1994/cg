package com.cg.electricitybill.service;

import java.util.List;

import com.cg.electricitybill.bean.BillDetailsBean;
import com.cg.electricitybill.bean.ConsumersBean;
import com.cg.electricitybill.exception.ElectricityException;

public interface EBillService {
	List<ConsumersBean>getConsumers()throws ElectricityException; // to fetch data from consumerbean
	public ConsumersBean searchConsumer(int consumer_num) throws ElectricityException; //fetch by consumer number

	public List<BillDetailsBean> getBillDetails(int cnum) throws ElectricityException; // fetch bill details

	public int generateNextBill(BillDetailsBean nextBill) throws ElectricityException; 
	
	int calculateUnitConsumed(int lastMonthMeterReading,
			int currentMonthMeterReading) throws ElectricityException;

	double calculateNetAmount(int unitConsumed);
	

}
