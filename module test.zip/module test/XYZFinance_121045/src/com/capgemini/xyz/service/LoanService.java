package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.FinanceException;

/**
 * @version 1.0
 * @author Dushyant
 * This is the service class for ExecuterMain
 */
public class LoanService implements ILoanService {

	ILoanDao lDao = new LoanDao();
	final double rate = 0.095;
	
	@Override
	public boolean validateCustomer(Customer customer) {
		return (customer.getCustName().matches("^[A-Z][a-z]{1,25}$"))&&
				(customer.getAddress().matches("[A-Za-z0-9\\_,\\s]{1,40}"));
	}

	/**
	 * This Function Validates the email id
	 */
	@Override
	public boolean validateEmail(String email) {
		return email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}

	/**
	 * This Function Validates the Mobile number that it should start with 9,8 or 7 and it should be of length 10
	 */
	@Override
	public boolean validateMobile(String mobile) {
		return mobile.matches("[7-9]{1}[0-9]{9}");
	}

	/**
	 * this Function Insert the customer information into database
	 * @throws FinanceException 
	 */
	@Override
	public long insertCust(Customer customer) throws FinanceException {
		return lDao.insertCust(customer);
	}

	/**
	 * This Function Validates the loan Amount
	 */
	@Override
	public boolean validateLoanAmount(String loanAmount) {
		return loanAmount.matches("[1-9]{1}[0-9]{0,19}");
	}

	/**
	 * this Function validates the loan duration 
	 */
	@Override
	public boolean validateLoanDuration(String loanDuration) {
		return loanDuration.matches("[1-9]{1,5}");
	}

	/**
	 * this Method calculate EMI based on amount and duration
	 */
	@Override
	public double calculateEMI(double loanAmount, int duration) {
		return (loanAmount * rate * (1 + rate) * duration)/(((1 + rate) * duration) - 1);
	}

	/**
	 * This method insert loan information to database
	 * @throws FinanceException 
	 */
	@Override
	public long applyLoan(Loan loan) throws FinanceException {
		return lDao.applyLoan(loan);
	}
}
