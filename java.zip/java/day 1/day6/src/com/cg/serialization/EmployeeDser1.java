package com.cg.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class EmployeeDser1 {

	public static void main(String[] args) {
		Employee ref = null;
		File file = new File("serl.txt");
		FileInputStream fin = null;
		ObjectInputStream bin = null;
		try
		{
			fin = new FileInputStream(file);
			bin = new ObjectInputStream(fin);
			ref = (Employee)bin.readObject();
			System.out.println(ref);
		}
		catch(IOException | ClassNotFoundException e)
		{
			System.out.println(e.getMessage());
		}
finally
{
	try
	{
		bin.close();
		fin.close();
	}
	catch (IOException e)
	{
		System.out.println(e.getMessage());
	}
}
	}

}
