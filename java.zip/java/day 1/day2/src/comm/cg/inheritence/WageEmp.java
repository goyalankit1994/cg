package comm.cg.inheritence;

public class WageEmp  extends Employee
{
	private int hour;
	private int rate;
public WageEmp(int id,String name,int hr,int rt)
{
	super(id,name);
	hour=hr;
	rate=rt;
}

	public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	@Override
	public double calsal()
	{
		return(hour*rate);
	}

	@Override
	public String toString() {
		return ""+super.toString()+ "WageEmp [hour=" + hour + ", rate=" + rate + "]";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
}
