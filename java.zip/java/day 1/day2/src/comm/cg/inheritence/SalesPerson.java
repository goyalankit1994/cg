package comm.cg.inheritence;

public class SalesPerson extends WageEmp
{
int comm;
int sales;
public SalesPerson(int id,String name,int hr,int rt,int com,int sale)
{
	super(id,name,hr,rt);
	this.comm=com;
	this.sales=sale;
	}
@Override
public double calsal()
{
	return super.calsal()+(sales-comm);
	
}
@Override
public String toString() {
	return "SalesPerson [comm=" + comm + ", sales=" + sales + "]";
}
public int getComm() {
	return comm;
}
public void setComm(int comm) {
	this.comm = comm;
}
public int getSales() {
	return sales;
}
public void setSales(int sales) {
	this.sales = sales;
}

}
