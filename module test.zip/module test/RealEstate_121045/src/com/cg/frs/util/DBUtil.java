
package com.cg.frs.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.frs.exception.FlatRegisterationException;

/**
 * @author Dushyant
 * Creates Connection and return it
 *
 */
public class DBUtil {

	static Connection conn;
	static Logger logger = Logger.getLogger(DBUtil.class);
	
	public static Connection getConnection() throws FlatRegisterationException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			if (conn == null || conn.isClosed()) {
				conn = DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
				logger.info(Messages.CONNECTION_ESTABLISHED);
			}
		} catch (SQLException e) {
			logger.error(Messages.DB_CONN_ERROR + e);
			throw new FlatRegisterationException(Messages.DB_CONN_ERROR);
		} catch (ClassNotFoundException e) {
			logger.error(Messages.CLASS_NOT_FOUND_ERROR + e);
			throw new FlatRegisterationException(Messages.CLASS_NOT_FOUND_ERROR);
		}
		return conn;
	}
}
