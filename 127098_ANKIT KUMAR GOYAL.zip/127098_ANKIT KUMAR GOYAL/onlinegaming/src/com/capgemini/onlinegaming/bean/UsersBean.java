package com.capgemini.onlinegaming.bean;

public class UsersBean {
	private int user_id;
	private String user_name;
	private String address;
	private int card_amt;
	public int getId() {
		return user_id;
	}
	public void setId(int id) {
		this.user_id = id;
	}
	public String getName() {
		return user_name;
	}
	public void setName(String name) {
		this.user_name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getCard_amt() {
		return card_amt;
	}
	public void setCard_amt(int card_amt) {
		this.card_amt = card_amt;
	}
	@Override
	public String toString() {
		return "UsersBean [id=" + user_id + ", name=" + user_name + ", address="
				+ address + ", card_amt=" + card_amt + "]";
	}
	public UsersBean() {
		super();
	}
	

}
