package lab5.com.cg.eis.service;

public interface ServiceInterface {
	public String getInsuranceScheme(double salary , String designation );

	
	
}
