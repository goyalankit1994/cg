package comm.cg.objectclass;

public class Demo {
private	int number;
private String name;
 public Demo(int number1,String name1)
 {
	number = number1;
	 name= name1;
 }
 
@Override
public String toString() {
	return "number=" + number + " name=" + name ;
}
@Override
public boolean equals(Object obj)
{
	boolean flag=false;
	if(obj instanceof Demo)
	{
		Demo ref2=(Demo)obj;
		if(this.number==ref2.number && this.name.equals(ref2.name))
			{
			flag=true;
			return true;
		}
	}
	 
	return flag;
}

}
