package com.capgemini.xyz.exception;

public class FinanceException extends Exception {

	public FinanceException(String message) {
		super(message);
	}
	
}
