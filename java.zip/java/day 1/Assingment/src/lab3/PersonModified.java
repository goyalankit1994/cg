package lab3;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PersonModified {
	 String firstName; 
	String lastName;
	LocalDate dateOfBirth;
	PersonModified()
	{
		
	}
	PersonModified(String firstname,String lastname )
	{
		this.firstName=firstname;
		this.lastName=lastname;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void calculateAge(String DateOfBirth)
	{
		Period period;
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate formattedDateOfBirth = LocalDate.parse(DateOfBirth, format);
		this.dateOfBirth = formattedDateOfBirth;
		LocalDate currentDate = LocalDate.now();
		period = dateOfBirth.until(currentDate);
//		return period;
		System.out.println("Age : Year : " + period.getYears() + " Months : " + period.getMonths() + " Days : " + period.getDays());
	}
	public String getFullName()
	{
		return firstName+" "+lastName;
	}
	@Override
	public String toString() {
		return "PersonModified [firstName=" + firstName + ", lastName="
				+ lastName + ", dateOfBirth=" + dateOfBirth + "]";
	}
	
	
}
