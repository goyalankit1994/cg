package com.cg.eis.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	Map<Integer, Employee> empMap = new HashMap<Integer,Employee>();

	@Override
	public Map<Integer, Employee> addEmployee(Employee emp) {
		empMap .put(emp.getId(), emp);
		return empMap;
	}
	
	

	@Override
	public boolean printEmployeeBasedOnInsuranceScheme(
			Map<Integer, Employee> empMap, String insuranceScheme) {
		boolean isSuccessful = false;
		this.empMap = empMap;
		Iterator<Entry<Integer, Employee>> i = this.empMap.entrySet().iterator();
		while (i.hasNext()){
			Employee emp = new Employee();
			//Map.Entry<Integer, Employee> empEntry = (Map.Entry<Integer, Employee>) i.next();
			Entry<Integer, Employee> empEntry = (Entry<Integer, Employee>) i.next();
			emp = empEntry.getValue();
			if ( emp.getInsuranceScheme().equalsIgnoreCase(insuranceScheme)){
				System.out.println(emp);
				isSuccessful = true;
			}
		}
		return isSuccessful;
	}

	
	@Override
	public Map<Integer, Employee> deleteEmployee(int id,
			Map<Integer, Employee> empMap) {
		Set<Integer> empMapSet = this.empMap.keySet();
		if (empMapSet.contains(id)){
			this.empMap.remove(id);
		} else {
			System.out.println("No Record Found");
		}
		return this.empMap;
	}
	

	@Override
	public void sortEmployeeOnSalary(Map<Integer, Employee> empMap) {
		this.empMap = empMap;
		List<Employee> empList = new ArrayList<Employee>();
		Iterator<Entry<Integer, Employee>> empMapIterator = this.empMap.entrySet().iterator();
		while (empMapIterator.hasNext()){
			Employee emp = new Employee();
			Entry<Integer, Employee> empEntry = (Entry<Integer, Employee>) empMapIterator.next();
			emp = empEntry.getValue();
			empList.add(emp);
		}
		Collections.sort(empList, new EmployeeComparator());
		System.out.println(empList);
	}
}

