package comm.cg.Exception;

public class DivisionDemo  {

	public static void main(String[] args) {
	int res =0;
	int num1 = 6, num2=0;
try{
	res = num1/num2;                     //divide by zero exception
}  
catch(ArithmeticException|NullPointerException e1) // cascade 2 exception
{
	System.out.println("exception is ="+e1.getMessage());
	
}
//catch (RuntimeException e2)
//{
//	
//}
//catch(Exception e)
//{
//	
//}
finally
{
	System.out.println("finally");
}
	System.out.println("after division ::");
	System.out.println("res = "+res);
	}

}
