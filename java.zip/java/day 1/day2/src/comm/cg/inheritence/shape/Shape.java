package comm.cg.inheritence.shape;

public abstract class Shape {


 public Shape()
 {
	
}
 abstract public double calArea();
 //{
	//System.out.println("Area is :"+calArea());
	//return calArea();
	//}
}