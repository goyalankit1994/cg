package com.cg.controller;


import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.TraineeBean;
import com.cg.exception.TraineeException;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeBean trainee;
	@Autowired
	TraineeService service;
	private int id;
	String domain[]=new String[]{"JAVA","SAP",".NET","TESTING"};
	@RequestMapping(value="/showPage")
	public String display(@RequestParam("userName")String userName, @RequestParam("password") String password,Model model)
	{
		if(userName.equals("angoyal") && password.equals("admin"))
		{
			return "listofoperation";
		}
		else
		{
			String message="Wrong id and password";
			model.addAttribute("message10", message);
			return "error";
		}
	}

	@RequestMapping(value="/home")
	public String display()
	{
		
		return "listofoperation";
		
		
	}
	@RequestMapping(value="/back")
	public String displayPerviousPage()
	{
		
		return "listofoperation";
		
		
	}
	@RequestMapping(value="/backtologin")
	public String displayPerviousPage1()
	{
		
		return "login";
		
		
	}
	
	@RequestMapping(value="/addTraineeForm")
	public String showTraineeForm(Model model)
	{
		model.addAttribute("trainee2", trainee);
		model.addAttribute("domains", domain);  //dropdown
		
		return "addtraineedetails" ;
	}
	
	
	
	@RequestMapping(value="/insertTrainee")
	public String insertSucess(@ModelAttribute("trainee2")@Valid  TraineeBean bean,BindingResult result,Model model) throws TraineeException
	{
		if(result.hasErrors())
		{
			System.out.println("eeror in validation");
			model.addAttribute("domains", domain); //drop down
			return "addtraineedetails";
		}
		else
		{
		try
		{
			System.out.println("inserted successfully");
			service.addTraineeDetails(bean);
			model.addAttribute("trainee", bean);
			String	message = "Trainee record successfully added..";
			model.addAttribute("message",message);
		}
		catch (TraineeException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
		
		return "success";
		
	}
	@RequestMapping(value="/deleteTraineeForm")
	public String delteTraineeForm1(Model model)
	{
		model.addAttribute("trainee3", trainee);
		return "deletetrainee" ;
	}
	@RequestMapping(value="/deleteOperation")
	public String deleteOperation(@RequestParam("id") int id, Model model) throws TraineeException
	{
			this.id = id;
			trainee = service.getDetails(id);
			
			model.addAttribute("trainee",trainee);
			return "deletetrainee";
		}
	
	@RequestMapping(value="/deleteTrainee")
	public String deleteTrainee(@ModelAttribute("trainee") TraineeBean trainee,Model model) throws TraineeException
	{
			boolean flag = service.removeTrainee(id);
			String	message = "Trainee record successfully deleted..";
			model.addAttribute("message",message);
			return "success";
	
}

	
	@RequestMapping(value="/retrieveTraineeForm")
	public String delteTraineeForm(Model model)
	{
		model.addAttribute("trainee4", trainee);
		return "details" ;
	}
	
	@RequestMapping(value="/fetchSuccess")
	public String reteriveSucess(Model model,TraineeBean bean) throws TraineeException
	{ 
		bean=service.getDetails(bean.getId());
		model.addAttribute("gettrainee",bean);
		System.out.println("fetched succesfully!");
		return "details";
	}
	@RequestMapping(value="/retrieveAllTraineeForm")
	public String reteriveallTrainee(Model model) throws TraineeException
	{
		ArrayList<TraineeBean> list1 = service.getallTraineeDetails();
		model.addAttribute("trainee5", list1);
		return "reterivealltrainee" ;
	}
	@RequestMapping(value="/modifyTraineeForm")
	public String modifyTrainee(Model model)
	{
		return "modifytrainee" ;
	}
	@RequestMapping(value="/modifyOperation")
	public String modifyOperation(@RequestParam("id") int id, Model model) throws TraineeException
	{
			this.id = id;
			trainee = service.getDetails(id);
			
			model.addAttribute("trainee",trainee);
			return "modifytrainee";
		}
	
	@RequestMapping(value="/modifyTrainee")
	public String modifyTrainee(@ModelAttribute("trainee") TraineeBean trainee, Model model) throws TraineeException
	{
			boolean flag = service.modifyTrainee(this.id,trainee);
			String	message = "Trainee record successfully updated..";
			model.addAttribute("message",message);
			return "success";
	
}
	}

