package comm.cg.inheritence;

public class CreateEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Employee emp1=new Employee();
		//System.out.println(emp1.calsal());
		//Employee emp2=new Employee();
		//System.out.println(emp2.calsal());
	//	WageEmp wEmp = new WageEmp(102,"sharvari",90,200);
//Employee emp = new Employee(100,"siya");
 WageEmp wEmp = new WageEmp(102,"sharvari",90,200);
//System.out.println("emp :"+emp);
System.out.println("wEmp="+wEmp);

	}

}
