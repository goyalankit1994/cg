package com.ch.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class MenuDriven {
	static Properties prop = new Properties();
	static String driver;
	static String user;
	static String pass;
	static String url;
	static
	{
		try{
		prop.load(new FileInputStream("jdbc.property"));
		driver = prop.getProperty("driver");
		pass = prop.getProperty("pass");
		user = prop.getProperty("user");
		url = prop.getProperty("url");
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
public static void connect()
{
	try
	{
		Class.forName(driver);
		Connection con =DriverManager.getConnection(url,user,pass);
		Statement stmt = con.createStatement();
		//ResultSet result =  stmt.executeQuery(sql);
	}
	catch(SQLException|ClassNotFoundException e)
	{
		e.printStackTrace();
	}
}
	public static void insert()
	{
		try
		{
			Connection con =DriverManager.getConnection(url,user,pass);
			String sql = "INSERT INTO emp VALUES(?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			Scanner sc = new Scanner(System.in);
			System.out.println("enter id and name");
			int id = sc.nextInt();
			String name = sc.next();
			pstmt.setInt(1,id);
			pstmt.setString(2,name);
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				System.out.println("no of row inserted are "+row);
			}
				}
		catch(Exception e)
		{
		e.printStackTrace();
		}
}
	public static void delete()
	{
		try
		{
		Connection con =DriverManager.getConnection(url,user,pass);
		Scanner sc = new Scanner(System.in);
		String sql = "DELETE FROM Emp WHERE id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		System.out.println("enter id to delete");
		int id = sc.nextInt();
		pstmt.setInt(1,id);
		int row = pstmt.executeUpdate();
		if(row>0)
		{
			System.out.println("no of row deleted  are "+row);
		}
			
		
		//ResultSet result =  stmt.executeQuery(sql);
}
	catch(Exception e)
	{
	e.printStackTrace();
	}
	}
	public static void update()
	{
		try
		{
		Connection con =DriverManager.getConnection(url,user,pass);
		String sql = "UPDATE  Emp SET name = ? where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		String name = sc.next();
		System.out.println("Enter id");
		int id = sc.nextInt();
		pstmt.setString(1,name);
		pstmt.setInt(2,id);
		int row = pstmt.executeUpdate();
		if(row>0)
		{
			System.out.println("no of row updated  are "+row);
		}
}
	catch(Exception e)
	{
	e.printStackTrace();
	}

	}
	public static void display()
	{
		try{
		Connection con =DriverManager.getConnection(url,user,pass);
		Statement stmt = con.createStatement();
		String sql = "SELECT * FROM Emp";
		ResultSet result =  stmt.executeQuery(sql);
		
		
		while(result.next())
		{
			System.out.println("id is   "+result.getInt(1));
			System.out.println("Name is "+result.getString(2));
		}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
public static void main(String[] args) {
			
			Scanner sc = new Scanner(System.in);
			System.out.println("enter 1 to insert details in employee table");
			System.out.println("enter 2 to delete data from table");
			System.out.println("enter 3 to update details in table");
			System.out.println("enter 4 to display all details");
			System.out.println("enter your choice");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 1:
				insert();;
				break;
			case 2:
				delete();
				break;
			case 3:
				update();
				break;
			case 4:
				display();
				break;
			default:
				System.out.println("wrong choice");
					
			}
			
		
}
}
	


