import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestMultiply {
	CalMul ref;
	@Before
	public void init()
	{
		ref = new CalMul();
	}

	@Test
	public void test() {
		assertNotEquals(0,ref.multiply(5, 6));
		fail("Not yet implemented");
	}

}
