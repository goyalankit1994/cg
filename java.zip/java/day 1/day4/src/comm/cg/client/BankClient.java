package comm.cg.client;

import comm.cg.Exception.BankAccount;
import comm.cg.Exception.BankException;

public class BankClient {

	public static void main(String[] args) {
		BankAccount obj = new BankAccount(2000);
		System.out.println("current balance = "+obj.getBalance());
		try {
			obj.withdraw(4000);
		} catch (BankException e) {
			
			e.getMessage();
		}
		System.out.println("after withdraw:::");
		System.out.println("current bal = "+obj.getBalance());
	}

}
