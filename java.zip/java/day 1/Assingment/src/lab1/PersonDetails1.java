package lab1;

public class PersonDetails1 {
	private String fname;
	private String lname;
	private String gender;
	private String mobileno;
	public PersonDetails1()
	{
	
	}
	public PersonDetails1(String fname,String lname,String gender,String mobileno )
	{
		this.fname=fname;
		this.lname=lname;
		this.gender=gender;
		this.mobileno=mobileno;
		
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public void printdetails()
	{
		System.out.println("person details");
		System.out.println("--------------------------");
		System.out.println("name is:"+fname);
		System.out.println("last name is "+lname);
		System.out.println("gender is:"+gender);
		System.out.println("mobile no is :"+mobileno);
		
	}

	}


