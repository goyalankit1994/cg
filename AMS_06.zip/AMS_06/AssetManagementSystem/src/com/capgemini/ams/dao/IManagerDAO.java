package com.capgemini.ams.dao;

import com.capgemini.ams.exception.AssetException;

public interface IManagerDAO {

	int raiseRequest(int assetId, int quantity, int mgrCode, int empNum) throws AssetException;

}
