package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;
import com.capgemini.util.DBUtil;

public class EmpDAOJdbcimpl implements EmpDAO {

	private String insertQuery = "insert into newemp(id,name,designation,salary) values(?,?,?,?)";
	private String selectQuery = "select id,name,designation,salary from newemp";
	private String deleteQuery = "delete from newemp where id = ?";
	private Connection conn = null;
	Logger logger = Logger.getLogger(EmpDAOJdbcimpl.class);
	
	@Override
	public boolean saveEmp(Emp emp) throws EmpException {
		boolean saved = false;
		conn = DBUtil.getConnection();
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt = conn.prepareStatement(insertQuery);
			pstmt.setInt(1, emp.getId());
			pstmt.setString(2, emp.getName());
			pstmt.setString(3, emp.getDesignation());
			pstmt.setDouble(4, emp.getSalary());
			int rows = pstmt.executeUpdate();
			if (rows > 0){
				saved = true;
				conn.commit();
				logger.info("Emp saved " + emp);
			}
		} catch (SQLIntegrityConstraintViolationException e) {
			logger.error("Primary Key voilation" + e);
			throw new EmpException("Primary Key voilation");
		} catch (SQLException e) {
			logger.error("Error Inserting Values" + e);
			throw new EmpException("Error inserting values");
		}
		return saved;
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		List<Emp> elist = new ArrayList<Emp>();
		conn = DBUtil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs= stmt.executeQuery(selectQuery );
			while (rs.next()) {
				Emp emp = new Emp(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4));
				elist.add(emp);
				logger.info("Data Read For " + emp);
			}
		} catch (SQLSyntaxErrorException e) {
			logger.error("Table Dropped After Establishing Connection " + e);
			throw new EmpException("Error getting Data From Db");
		} catch (SQLException e) {
			logger.error("Error getting Data From Db" + e);
			throw new EmpException("Error getting Data From Db");
		}
		return elist;
	}

	@Override
	public void closeReaderWriter() throws EmpException {
		try {
			if (conn != null){
				conn.close();
				logger.info("Connection Terminated");
			}
			logger.info("Unbale to terminate connection as connection not established");
		} catch (SQLException e) {
			logger.error("Connection Cannot be terminated" + e);
			throw new EmpException("Connection Cannot be terminated");
		}
	}

	@Override
	public boolean deleteEmp(int id) {
		boolean saved = false;
		try {
			conn = DBUtil.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(deleteQuery);
			pstmt.setInt(1, id);
			int rows = pstmt.executeUpdate();
			if (rows > 0){
				saved = true;
				logger.info("Emp with id " + id + " deleted");
			}
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return saved;
	}
}
