package com.cg.lab11.dto;

public class MobileAppBean {
	private int moibleid;
	private String name;
	private String quantity;
	private double price;
	
	public int getMoibleid() {
		return moibleid;
	}
	
	public void setMoibleid(int moibleid) {
		this.moibleid = moibleid;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getQuantity() {
		return quantity;
	}
	
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "MoibleAppBean [moibleid=" + moibleid + ", name=" + name
				+ ", quantity=" + quantity + ", price=" + price + "]";
	}
	
}
