package classesandobject;

public class CreateStudent {

	public static void main(String[] args) {
		Student stu = new Student();
		System.out.println("id="+stu.getStuid());
		System.out.println("name = "+stu.getStuname());
		
		Student ref = new Student(101,"kishan");
		System.out.println("id of ref ="+ref.getStuid());
		System.out.println("name of ref="+ref.getStuname());
		// TODO Auto-generated method stub

	}

}
