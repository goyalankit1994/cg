package day2;


public class StaticDemo {
	public StaticDemo()
	{
		System.out.println("constr");
	}

	public static void main(String[] args) {
		System.out.println("main block is called");
		StaticDemo s1=new StaticDemo();
		StaticDemo s2=new StaticDemo();
		
		// TODO Auto-generated method stub

	}
	{
		System.out.println("init");
	}
	static
	{
		System.out.println("call to static block");
	}
}
		
