package com.cg.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.dto.BillDetails;
import com.cg.dto.EbillBean;
import com.cg.exception.EbillException;

public class EbillDaoImpl implements EbillDao {

	@Override
	public List<EbillBean> getAllConsumer() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EbillBean searchConsumer(int con_nu) throws EbillException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BillDetails> getBillDetails(int cnum) throws EbillException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int generateNextBill(BillDetails nextBill) throws EbillException {
		// TODO Auto-generated method stub
		return 0;
	}

}
