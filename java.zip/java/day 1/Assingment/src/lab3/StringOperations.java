package lab3;
import java.util.Scanner;
public class StringOperations {
	String userInput;
	StringBuffer userOutput;
	int i;
	
	
	public String getUserInput() {
		return userInput;
	}

	public void setUserInput(String userInput) {
		this.userInput = userInput;
	}

	public StringBuffer getUserOutput() {
		return userOutput;
	}

	public void setUserOutput(StringBuffer userOutput) {
		this.userOutput = userOutput;
	}

	
	StringOperations(String userInput, StringBuffer userOutput) {
		this.userInput = userInput;
		this.userOutput = userOutput;
	}
	
	StringOperations(){
		userInput = null;
		userOutput = new StringBuffer();
	}
	
	
	/** add the string to itself **/
	String addItself(){
		return userInput+userInput;
	}
	
	
	/** Replace Odd Characters with # **/
	StringBuffer replaceOdd(){
	int length = userInput.length();	
		for(i=0;i<length;i++)
		{
			if(i%2!=0)
				userOutput.append(userInput.charAt(i));
			else
				userOutput.append('#');
		}
			
		return userOutput;
	}
	
	/** Remove Duplicate Characters **/
	StringBuffer removeDuplicateChars(){

		for(int i = 0;i<userInput.length();i++){
			if(!(userInput.substring(0, i).contains(String.valueOf(userInput.charAt(i)))))
				userOutput.append(userInput.charAt(i));
		}
		return userOutput;
	}
	
	/** Change characters at odd places in a  string to upper case **/
	StringBuffer changeOddtoUpper(){

		userOutput = new StringBuffer();
		userOutput.append(userInput);
		
		for(int i=1;i<userInput.length();i+=2)
			userOutput.replace(i, i+1, String.valueOf (userInput.charAt(i)).toUpperCase());
				
		return userOutput;
	}

@SuppressWarnings("resource")
public static void main(String[] args) {
 
 	char choice;
 	
	StringOperations obj = new StringOperations();
	Scanner input= new Scanner(System.in);
	
	while(true){
		System.out.println("1. Add String to Itself");
		System.out.println("2. Replace Odd Characters with #");
		System.out.println("3. Remove Duplicate Characters ");
		System.out.println("4. Change characters at odd places in a  string to upper case");
		
		System.out.println("Enter String: ");
		obj.setUserInput(input.next());
		
		System.out.println("Enter your choice: ");
		choice = input.next().charAt(0);
		
		switch(choice)
		{
			case '1': System.out.println(obj.addItself());
					break;
			
			case '2': System.out.println(obj.replaceOdd());
					break;
			
			case '3': System.out.println(obj.removeDuplicateChars());
					break;
			
			case '4': System.out.println(obj.changeOddtoUpper());		
					break;
			
			default: System.out.println("Invalid Choice!");
					break;		
			
		}
		
		System.out.println("Want to Continue?(y/n)  ::");
		choice = input.next().charAt(0);
		if(choice == 'n' || choice == 'N')	break;
		
	}
	
}

}
