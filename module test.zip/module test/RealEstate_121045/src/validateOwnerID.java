import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cg.frs.service.FlatRegisterationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;


public class validateOwnerID {

	String id;
	List<Integer> idList = new ArrayList<Integer>();
	IFlatRegisterationService flatRegisteration;
	@Before
	public void setUp() throws Exception {
		id = "4";
		idList.add(1);
		idList.add(2);
		idList.add(3);
		flatRegisteration = new FlatRegisterationServiceImpl();
	}

	@Test
	public void test() {
		boolean isValid = flatRegisteration.validateOwnerID(id,idList);
		assertTrue(isValid);
	}

}
