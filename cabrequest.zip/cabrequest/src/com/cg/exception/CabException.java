package com.cg.exception;

public class CabException extends Exception{

		String message;
		public CabException(String message)
		{
			this.message=message;
		}
		@Override
		public String getMessage() {
			// TODO Auto-generated method stub
			return message;
		}
		
		
	}


