package com.cg.onlineshopping.exception;

public class ShoppingException extends Exception{

	String message;
	
	public ShoppingException(String msg)
	{
		this.message = msg;
	}
	@Override
	public String getMessage()
	{
		return message;
	}
}
