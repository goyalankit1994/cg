package com.capgemini.onlinegaming.bean;

public class GameBean {
	private String name;
	private int amount;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "OnlineGames [name=" + name + ", amount=" + amount + "]";
	}
	public GameBean() {
		super();

	}
	
	

}

