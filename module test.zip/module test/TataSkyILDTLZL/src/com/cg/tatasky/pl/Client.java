package com.cg.tatasky.pl;

import java.util.Scanner;

import com.cg.tatasky.dto.TataSkyBean;
import com.cg.tatasky.service.TataSkyService;
import com.cg.tatasky.service.TataSkyServiceImpl;

public class Client {
	static TataSkyService tss = new TataSkyServiceImpl();
	public static void main(String[] args) // throws TataSkyException
	{
		int choice=0;
		
		try(Scanner sc = new Scanner(System.in))
		{
			
		
			do
			{
				System.out.println("1-Get Record ");
				System.out.println("2-Recharge ");
				System.out.println("Enter Your Choice ");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1: 
						System.out.println("Enter User ID ");
						int uid=sc.nextInt();
						TataSkyBean record=tss.getRecord(uid);
						System.out.println(record);
						break;
				case 2:
						System.out.println("Enter User Id ");
						int uid1=sc.nextInt();
						int amount=sc.nextInt();
						tss.rechargeTatasky(uid1, amount);
						break;
				default:
						
				}
//				sc.close();
			}while(choice!=0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
