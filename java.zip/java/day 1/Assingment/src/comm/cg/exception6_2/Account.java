package comm.cg.exception6_2;

public class Account extends Person {
	private double accNum;
	private double balance;
	Person accHolder;
	
	public Account() {
		super();
	}
	
	public Account( double balance, Person accHolder) {
		//super();
		this.accNum = Math.random();
		this.balance = balance;
		this.accHolder = accHolder;
	}
	
	public double getAccNum() {
		return accNum;
	}
	public void setAccNum(double accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	
	public void deposit(double amount)
	{
		this.balance=this.balance+amount;
	}
	
	public void withdraw(double amount)
	{
		
		if(amount<this.balance-500)
			this.balance=this.balance-amount;
		else
			System.out.println("Not enough balance");
	}
	
	public double getAccBalance()
	{
		return balance;
	}
	
	@Override
	public String toString() {
		return "Account1 [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	
	
}
