package com.cg.MobileSeller.dto;

public class PurchaseBean {
	/*
	 * initialization
	 */
		private String cname;
		private String mailid;
		private String phoneno;
		private int mobileId;
		/*
		 * getter for customer name
		 */
		public String getCname() {
			return cname;
		}
		/*
		 * setter for Customer Name
		 */
		public void setCname(String cname) {
			this.cname = cname;
		}
		/*
		 * getter for maildId
		 */
		public String getMailid() {
			return mailid;
		}
		/*
		 * setter for mailid
		 */
		public void setMailid(String mailid) {
			this.mailid = mailid;
		}
		/*
		 * getter for Phone No
		 */
		public String getPhoneno() {
			return phoneno;
		}
		/*
		 * setter for Phone No
		 */
		public void setPhoneno(String phoneno) {
			this.phoneno = phoneno;
		}
		/*
		 * getter for MobileId
		 */
		public int getMobileId() {
			return mobileId;
		}
		/*
		 * setter for mobileID
		 */
		public void setMobileId(int mobileId) {
			this.mobileId = mobileId;
		}
		/*
		 * (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "Customer [cname=" + cname + ", mailid=" + mailid
					+ ", phoneno=" + phoneno + ", mobileId=" + mobileId + "]";
		}
		/*
		 * Constructor with fields
		 */
		public PurchaseBean(String cname, String mailid, String phoneno,
				int mobileId) {
			super();
			this.cname = cname;
			this.mailid = mailid;
			this.phoneno = phoneno;
			this.mobileId = mobileId;
		}
		public PurchaseBean() {
			super();
			// TODO Auto-generated constructor stub
		}

}
