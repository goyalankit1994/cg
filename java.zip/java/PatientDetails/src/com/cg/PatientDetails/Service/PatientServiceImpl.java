package com.cg.PatientDetails.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.PatientDeatils.dao.PatientDao;
import com.cg.PatientDeatils.dao.PatientDaoImpl;
import com.cg.PatientDetails.Exception.PatientException;
import com.cg.PatientDetails.dto.PatientBean;

public class PatientServiceImpl implements PatientService {
PatientDao dao;
public void setDao(PatientDao dao)
{
	this.dao = dao;
}
public PatientServiceImpl()
{
	dao = new PatientDaoImpl();
}
	@Override
	public boolean insertDetails(PatientBean obj) throws PatientException {
		// TODO Auto-generated method stub
		
		return dao.insertDetails(obj);
	}

	@Override
	public PatientBean getRecord(int patientid) throws PatientException {
		
		return dao.getRecord(patientid);
	}

	@Override
	public ArrayList<PatientBean> getAllRecord() throws PatientException {
		// TODO Auto-generated method stub
		return dao.getAllRecord();
	
	
	}
	//to validate
	@Override
	public boolean validatePatient(PatientBean bean) {
		String name ="[a-zA-Z]+[\\s]?[a-zA-Z]+";
		String number = "[7-9]{1}[0-9]{9}";
		String addr = "[A-z]{1}[a-zA-Z]*";
		if(!Pattern.matches(name,bean.getPname()))
			return false;
		if(!Pattern.matches(addr, bean.getAddress()))
			return false;
		if(!Pattern.matches(number, bean.getMobilenumber()))
			return false;
		return true;
		
	}
}



