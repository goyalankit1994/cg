package lab3;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class TimeZone {

	public static void main(String[] args) {
		//char choice;
Scanner sc = new Scanner(System.in);
System.out.println("enter 1 for zone America/Newyork");
System.out.println("enter 2 for zone Europe/London");
System.out.println("enter 3 for zone Asia/Tokyo");
System.out.println("enter 4 for zone US/Pacific");
System.out.println("enter 5 for zone Africa/Cairo");
System.out.println("enter 6 for zone Australia/Sydney");
		System.out.println("enter zone id");
		int zoneid =  sc.nextInt();
	switch(zoneid)
		{
		case 1:
		ZonedDateTime zonedate1 = ZonedDateTime.of(LocalDate.now(),LocalTime.now(),ZoneId.of( "America/New_York"));
		System.out.println("zonedate"+zonedate1);
		break;
		case 2:
		ZonedDateTime zonedate2 = ZonedDateTime.of(LocalDate.now(),LocalTime.now(),ZoneId.of( "Europe/London"));
		System.out.println("zonedate"+zonedate2);
		break;	
		case 3:
		ZonedDateTime zonedate3 = ZonedDateTime.of(LocalDate.now(),LocalTime.now(),ZoneId.of( "Asia/Tokyo"));
		System.out.println("zonedate"+zonedate3);
		break;	
		case 4:
		ZonedDateTime zonedate4 = ZonedDateTime.of(LocalDate.now(),LocalTime.now(),ZoneId.of( "US/Pacific"));
		System.out.println("zonedate"+zonedate4);
		break;
		case 5:
		ZonedDateTime zonedate5 = ZonedDateTime.of(LocalDate.now(),LocalTime.now(),ZoneId.of( "Africa/Cairo"));
		System.out.println("zonedate"+zonedate5);
		break;
		case 6:
		ZonedDateTime zonedate6 = ZonedDateTime.of(LocalDate.now(),LocalTime.now(),ZoneId.of( "Australia/Sydney"));
		System.out.println("zonedate"+zonedate6);
		break;
		default:
			System.out.println("INVALID ZONE");
			}
	

	}

}
