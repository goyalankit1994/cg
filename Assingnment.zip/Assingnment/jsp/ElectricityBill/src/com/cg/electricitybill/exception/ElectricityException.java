package com.cg.electricitybill.exception;

public class ElectricityException extends Exception {
	String message;
	
	public ElectricityException(String msg)
	{
		this.message = msg;
	}
	@Override
	public String getMessage()
	{
		return message;
	}
}

