package day1;
import java.util.Scanner;
public class Armstrong {

	public static void main(String[] args) {
		int number,num1,remainder,result=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 3 digit number");
		number=sc.nextInt();
		num1=number;
		while(num1!=0)
		{
			remainder=num1%10;
			result+= remainder*remainder*remainder;
			num1  = num1/ 10;
		}
		if(result == number)
			System.out.println(number+ ": is an armstrong number:" );
			else
				System.out.println(number+" : is not an armstrong number" );
		// TODO Auto-generated method stub

	}

}
