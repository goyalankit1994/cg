package comm.cg.collection;

public class WageEmp extends Employee {
int rate;
int hour;
public WageEmp(int id,String name,int rate , int hour)
{
	super(id,name);
	this.rate = rate;
	this.hour = hour;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}
public int getHour() {
	return hour;
}
public void setHour(int hour) {
	this.hour = hour;
}
@Override
public String toString() {
	return super.toString()+ "WageEmp [rate=" + rate + ", hour=" + hour + "]";
}

}
