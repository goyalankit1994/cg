package com.capgemini.ams.pl;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.AMSServiceImpl;
import com.capgemini.ams.service.AdminServiceImpl;
import com.capgemini.ams.service.AuthenticationServiceImpl;
import com.capgemini.ams.service.IAMSService;
import com.capgemini.ams.service.IAdminService;
import com.capgemini.ams.service.IAuthenticationService;
import com.capgemini.ams.service.IManagerService;
import com.capgemini.ams.service.ManagerServiceImpl;

public class Client {
	
	static IAMSService amsService = new AMSServiceImpl();
	static IAuthenticationService authService = new AuthenticationServiceImpl();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("***************** Asset Management System *******************");
	
		String userName = null;
		String password = null;
		boolean isValidUserName = false;
		boolean isValidPassword = false;
		
		Scanner sc = new Scanner(System.in);
		
		do {
			try 
			{
				System.out.print("User Name : ");
				userName = sc.next();
				
				isValidUserName = authService.validateUserName(userName);
				if (isValidUserName) 
				{
					do
					{
						System.out.print("Password : ");
						password = sc.next();
						try
						{
							isValidPassword = authService.validatePassword(password);
							if (isValidPassword)
							{	
								String userType = authService.getUserType(userName,password);
	
								if (userType.equals("Admin")) 
								{
									System.out.println("*********** Welcome to the Admin Panel ***************");
									adminOperations();
								}
								else if (userType.equals("Manager"))
								{
									int mgrCode = authService.getMgrCode(userName,password);
									
									System.out.println("*********** Welcome to the Manager Panel ***************");
							
									managerOperations(mgrCode);
								}
							}
						}
						catch (AssetException e)
						{
							System.out.println(e.getMessage());
						}
					}while(isValidPassword == false);
				}
			}
			catch (AssetException e)
			{
				System.out.println(e.getMessage());
			}
		}while (isValidUserName == false);
	}

	/*Operations performed by admin */	
	private static void adminOperations() throws AssetException {
		// TODO Auto-generated method stub
		IAdminService adminService = new AdminServiceImpl();
		String choice = null;
		
		int requestId = 0;
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		
		do
		{
			System.out.println("1. Show All Assets");
			System.out.println("2. Add Asset");
			System.out.println("3. Modify Asset ");
			System.out.println("4. Show All Requests ");
			System.out.println("5. Generate Report ");
			System.out.println("6. Logout");

				System.out.print("Enter Your Choice : ");
				choice = sc.next();
				
				switch (choice)
				{
					case "1":
						showAllAssets();
					break;
					
					case "2":
						Asset asset=new Asset();
						String assetName = null;
						System.out.println("************ Enter Asset Details ************ " );
						boolean validAssetName;
						do
						{
							System.out.print("Asset Name :");
							assetName = sc.next();						
							validAssetName = amsService.validateName(assetName);
							if(validAssetName)
							{
							}
							else
							{
								System.err.println("Asset name should contain atleast 2 characters");
							}
						}while(validAssetName == false);
						
						boolean validAssetDes;
						String assetDesc = null;
						do
						{
							System.out.print("Asset Description :");
							assetDesc = sc.next();
							validAssetDes = amsService.validateAssetDesc(assetDesc);
							if(validAssetDes)
							{}
							else
							{
								System.err.println("Asset description should contain atleast 2 characters");
							}
						}while(validAssetDes == false);
						
						boolean validQuant = false;
						int assetQuantity = 0;
						do
						{
							System.out.print("Asset Quantity : ");
							try
							{
								assetQuantity = Integer.parseInt(reader.readLine());
								validQuant = amsService.checkValidQuant(assetQuantity);
								if(validQuant)
								{}
								else
								{
									System.err.println("Asset quantity should be greater than 0 ");
								}
							} 
							catch (Exception e) 
							{
								System.err.println("Asset quantity should be number ");
							}
							
						}while(validQuant == false);
						
						asset.setAssetName(assetName);
						asset.setAssetDesc(assetDesc);
						asset.setQuantity(assetQuantity);
						
						boolean isInserted =adminService.addAsset(asset);
						if(isInserted)
						{
							System.out.println("Asset Inserted Successfully...");
						}
				
					break;
				
					case "3":
						int assetId= 0;
						boolean validateAssetId =false;
						do
						{
							System.out.print("Enter asset id to update quantity: ");
							try 
							{
								assetId = Integer.parseInt(reader.readLine());
								// Client side input validation
								validateAssetId = amsService.checkAssetId(assetId);
								if(validateAssetId)
								{}
								else
								{
									System.err.println("Asset id should be of 4 digits ");
								}
							} 
							catch (Exception e) 
							{
								System.err.println("The asset id should be number");
							}
						}while(validateAssetId == false);
						
						
						boolean isValidAsset=amsService.validateAssetId(assetId);
						
						if(isValidAsset)
						{
							validQuant = false;
							int reqQuantity = 0;
							do
							{
								System.out.print("Enter asset quantity to be added: ");
								try
								{
									reqQuantity = Integer.parseInt(reader.readLine());
									validQuant = amsService.checkValidQuant(reqQuantity);
									if(validQuant)
									{}
									else
									{
										System.err.println("Asset quantity should be greater than 0 ");
									}
								} 
								catch (Exception e) 
								{
									System.err.println("Asset quantity should be number ");
								}
							}while(validQuant == false);
							
							asset = amsService.getAssetDetailsById(assetId);
							int availQuantity = asset.getQuantity();
							int updateQuantity = availQuantity + reqQuantity;
							
							boolean isModified =adminService.updateAsset(assetId,updateQuantity);
					
							if(isModified)
							{
								System.out.println("Asset updated successfully.");
							}
						}
					break;
						
					case "4":
							showAllRequests();
							System.out.println("Enter request id to allocate assets :");
							requestId = sc.nextInt();
							
							boolean isValidRequest = amsService.validateRequestId(requestId);
							
							
							if(isValidRequest)
							{
								LocalDate releaseDate = null;
								boolean validDate = true;
								
								do{
								
								try
								{
									validDate = true;						
									DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
									
									System.out.println("Enter asset release date in (dd/MM/yyyy) format : ");
									String input = sc.next();
									
									releaseDate = LocalDate.parse(input, dateFormat);
								}
								catch(Exception e)
								{
									validDate = false;
									System.err.println("Enter the date in the given format as mentioned above");
								}
								}while(validDate == false);	
								
								boolean isAllocated = adminService.allocateAsset(requestId,releaseDate);
								if(isAllocated)
								{
									AssetRequest request = amsService.getRequestDetails(requestId);
									
									if(request!=null)
									{
										int reqAssetId = request.getAssetId();
										asset = amsService.getAssetDetailsById(reqAssetId);
										int availQuant=asset.getQuantity();
									
										int reqAssetQuant = request.getAssetQuantity();
										int assetQuant=availQuant-reqAssetQuant;
									
										boolean isModified = adminService.updateAsset(reqAssetId, assetQuant);
										
										if(isModified)
										{
											boolean isStatusUpdated = adminService.updateStatus(requestId);
											if(isStatusUpdated)
											{
												System.out.println("Asset for "+requestId+" allocated successfully");
											}
										}
									}
								}
							}
					break;
					
					case "5":
						
							boolean flag = adminService.generateReport();
							if(flag)
								System.out.println("Reports generated");
							else
								System.err.println("Reports generation failed..");
							
					break;
					
					case "6":
							System.out.println("Successfully Logged out ...");
							System.exit(0);
					break;
					
					default :
							System.err.println("Enter the correct choice ...");
							
				}
			System.out.println("Do you want to continue YES('1') NO ('0')");
			choice = sc.next();
		}while(choice.equals("1"));
	}

	private static void showAllAssets() throws AssetException {
		
		IAMSService amsService = new AMSServiceImpl();
		ArrayList<Asset> assetList = new ArrayList<Asset>();
		
		assetList = amsService.showAllAssets();
		
		System.out.println("*********** List of all assets ***************");	
		System.out.println("-------------------------------------------------------------------------------");
		/*System.out.println("AssetId"+"\t\t"+"AssetName"+"\t"+"AssetDesc"+"\t"+"Quantity");
		*/
		System.out.format("%s %15s %15s %15s ","AssetId","AssetName","AssetDesc","AsstQuantity");
		System.out.println("\n-----------------------------------------------------------------------------");
		for (Asset asset : assetList) 
		{
			System.out.format("%s %15s %15s %15s ",asset.getAssetId(),asset.getAssetName(),
					asset.getAssetDesc(),asset.getQuantity());
			System.out.println();
		}
	}

	private static void managerOperations(int mgrCode) throws AssetException 
	{
		IManagerService managerService=new ManagerServiceImpl();
		String choice = null;
		 Scanner sc = new Scanner(System.in) ;
		do {
			
			System.out.println("1. Raise a request for asset allocation");
			System.out.println("2. View status of request");
			System.out.println("3. Logout ");
			
			System.out.print("Enter Your Choice : ");
			choice = sc.next();
			
			switch (choice)
			{
			case "1":
				showAllAssets();
				BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
				boolean isValidAsset = false;
				int assetId = 0;
				do {
					
					boolean isValidAssetId = false;
					do
					{
						try{
							System.out.print("Enter asset id to raise request : ");
							assetId = Integer.parseInt(reader.readLine());
							// Client side input validation
							isValidAssetId = amsService.checkAssetId(assetId);	
							
							if(isValidAssetId)
							{
								isValidAsset = amsService.validateAssetId(assetId);
								if(isValidAsset)
								{
									isValidAssetId = true;
								}
								else
								{
									isValidAssetId = false;
									System.err.println("Invalid asset id enter once again ");
								}
							}	
							else
							{
								System.err.println("Enter 4 digits only of request id");
							}
						}
						catch(Exception e)
						{
							isValidAssetId = false;
							System.err.println("AssetId should be number of 4 digits ");
						}
						
					}while(isValidAssetId == false );

					if (isValidAsset) 
					{
						int quantity = 0;
						boolean checkQuant = false;
						boolean isAvailableQuant = false;
						do
						{
						try {
							System.out.print("Enter required quntity of asset : ");
							quantity = Integer.parseInt(reader.readLine());
							
							checkQuant = amsService.checkValidQuant(quantity);	
							if(checkQuant)
							{
								 isAvailableQuant = amsService.checkQuantity(quantity, assetId);

								if (isAvailableQuant) 
								{
									boolean checkEmpNum = false;
									do{
										try
										{
											System.out.print("Enter Employee number : ");
											int empNum = Integer.parseInt(reader.readLine());
										
											checkEmpNum = amsService.validateEmpNum(empNum); 
										
											if(checkEmpNum)
											{
												int requestId = managerService.raiseRequest(assetId, quantity, mgrCode, empNum);
				
												if (requestId != 0) 
												{
													System.out.println("Asset request raised successfully");
													System.out.println("Request Id is " + requestId);
												}
											}
											else
											{
												System.err.println("The employee number should contain 6 digits");
											}
										}
										catch(Exception e)
										{
											System.err.println("Employee number should be of 6 digits numeber");
										}
									}while(checkEmpNum == false);
								}
								else
								{
									isAvailableQuant = false;
									System.err.println("Required quantity is not available");
								}
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							System.err.println("The quantity should be number");
						} 
					}while(checkQuant == false || isAvailableQuant == false );
					
				}
				else
				{
					System.err.println("The required quantity is not available ");
				}
			}while (isValidAsset == false);
			break;
				
			case "2":
				showAllRequests();
				break;

			case "3":
				System.out.println("Successfully Logged out ...");
				System.exit(0);
				break;
				
			default:
				System.err.println("Enter the correct choice ...");
			}
			System.out.println("Do you want to continue YES('1') NO ('0')");
			choice = sc.next();
		}while(choice.equals("1"));
	}
	
	private static void showAllRequests() throws AssetException {
		
		IAMSService amsService = new AMSServiceImpl();
		ArrayList<AssetRequest> requestList = new ArrayList<AssetRequest>();
		
		requestList = amsService.showAllRequests();
		
		System.out.println("*********** List of all asset requests ***************");	
		System.out.println("-----------------------------------------------------------------------------------------------------------------------------------");
		/*System.out.println("RequstId"+"\t\t"+"AssetId"+"\t\t"+"MGR Code"+"\t"+"AssetName"+"\t"+"AssetDesc"+"\t"+"Quantity"+"\t"+"Status"+"\t"+"EmpNum");
*/		
		System.out.format("%s %15s %15s %15s %15s %15s %15s %15s","RequstId","AssetId","MGR Code","AssetName",
				"AssetDesc","Quantity","Status","EmpNum");
		System.out.println();
		System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
		for (AssetRequest request : requestList) 
		{
			System.out.format("%s %15s %15s %15s %15s %15s %15s %15s",request.getRequestId(),request.getAssetId(),
					request.getMgrCode(),request.getAssetName(),request.getAssetDesc(),request.getAssetQuantity(),request.getStatus(),request.getEmpNum());
			System.out.println();
		}
	}
}


