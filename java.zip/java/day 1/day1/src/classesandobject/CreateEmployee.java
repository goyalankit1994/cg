package classesandobject;


public class CreateEmployee {

	public static void main(String[] args) {
		
		Employee emp1=Employee.CreateEmployee();
		System.out.println("cnt="+Employee.getcnt());
		Employee emp = new Employee();
		System.out.println("cnt="+Employee.getcnt());
		System.out.println("name = "+emp.getEmpname());
		System.out.println("="+emp.getEmpid());
		
		Employee ref = new Employee(101,"kishan");
		System.out.println("id of ref ="+ref.getEmpid());
		System.out.println("name of ref="+ref.getEmpname());
		
		// TODO Auto-generated method stub

	}

}
