package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmpDAO;

public class EmpServiceImpl implements EmpService {
	
	EmpDAO empDao = new EmpDAOImpl();
	@Override
	public Character getScheme(double salary, String designation) {
		if ( salary > 5000 && salary < 20000 && designation.equals("System Associate"))
			return 'C';
		else if ( salary >= 20000 && salary < 40000 && designation.equals("Programmer"))
			return 'B';
		else if ( salary >= 40000 && designation.equals("Manager"))
			return 'A';
		else if ( salary < 50000 && designation.equals("Clerk"))
			return 'N';
		else
			return 'N';
	}

	@Override
	public boolean writeEmployee(Employee emp) {
		
		return empDao.writeEmployee(emp);
	}
}

