package comm.cg.objectclass;

public class CreateDemo {

	public static void main(String[] args) {
		Demo ref = new  Demo(10,"amit");
		System.out.println("ref="+ref);
		Demo d1 = new Demo(10,"amit");
		System.out.println("ref="+d1);
		if(ref.equals(d1))
			System.out.println("equal");
		else
			System.out.println("not equal");
		// TODO Auto-generated method stub
		System.out.println("ref="+ref);
		
		
	}

}
