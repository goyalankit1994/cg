package com.capgemini.ams.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.ams.dao.AMSDaoImpl;
import com.capgemini.ams.dao.IAMSDao;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.AMSServiceImpl;
import com.capgemini.ams.service.IAMSService;

public class AMSTest {

	AMSServiceImpl amsService;
	AMSDaoImpl amsDao;
	
	@Before
	public void init()
	{
		amsService = new AMSServiceImpl();
		amsDao = new AMSDaoImpl();
		amsService.setDao(amsDao);
	}


	@Test
	public void testShowAllAssets() throws AssetException {
		
		assertNotEquals(0, amsService.showAllAssets().size());
		
	}
	
	@Test
	public void testShowAllAssetsFail() throws AssetException {
		
		assertEquals(0, amsService.showAllAssets().size());
	}


	@Test
	public void testValidateAssetId() throws AssetException {
		assertEquals(true, amsService.validateAssetId(1002));
	}
	
	@Test
	public void testValidateAssetIdFail() throws AssetException {
		assertEquals(false, amsService.validateAssetId(0032));
	}

	@Test
	public void testCheckQuantity() throws AssetException{
		
		assertEquals(true, amsService.checkQuantity(2, 1002));
	}
	
	@Test
	public void testCheckQuantityFail() throws AssetException{
		
		assertEquals(true, amsService.checkQuantity(2, 1202));
	}

	
	@Test
	public void testShowAllRequests() throws AssetException{

		assertNotEquals(0, amsService.showAllRequests().size());
	}
	
	@Test
	public void testShowAllRequestsFail() throws AssetException{

		assertEquals(0, amsService.showAllRequests().size());
	}

	@Test
	public void testValidateRequestId()  throws AssetException{
		
		assertEquals(true, amsService.validateRequestId(1000033));
	}
	
	@Test
	public void testValidateRequestIdFail()  throws AssetException{
		
		assertEquals(false, amsService.validateRequestId(1030033));
	}

	@Test
	public void testGetRequesDetails() throws AssetException{
	
		assertNotEquals(null, amsService.getRequestDetails(1000033));
	}
	
	@Test
	public void testGetRequesDetailsFail() throws AssetException{
	
		assertEquals(null, amsService.getRequestDetails(1030033));
	}

	@Test
	public void testGetAssetDetailsById() throws AssetException {
		
		assertNotNull(amsService.getAssetDetailsById(1002));
	}
	
	@Test
	public void testGetAssetDetailsByIdFail() throws AssetException {
		
		assertNull(amsService.getAssetDetailsById(1223));
	}

}
