package com.ch.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class InserDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "sys";
			Connection con =DriverManager.getConnection(url,user,pass);
			String sql = "INSERT INTO emp VALUES(?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			Scanner sc = new Scanner(System.in);
			System.out.println("enter id and name");
			int id = sc.nextInt();
			String name = sc.next();
			pstmt.setInt(1,id);
			pstmt.setString(2,name);
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				System.out.println("no of row inserted are "+row);
			}
				
			
			//ResultSet result =  stmt.executeQuery(sql);
	}
		catch(Exception e)
		{
		e.printStackTrace();
		}

	}
}