package com.capgemini.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;

public class EmpDaoJdbcTest {

	EmpDAOJdbcimpl edj;
	Emp emp;

	@Before
	public void setUp() throws Exception {
		System.out.println("Before test");
		edj = new EmpDAOJdbcimpl();
		emp = new Emp(992, "Arpit", "CEO", 25000);
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("After test");
	}

	@Test
	@Ignore
	public void testsaveEmp() throws EmpException {
		boolean done = false;
		done = edj.saveEmp(emp);
		assertTrue(done);
	}
	
	@Test
	public void testgetEmpList() throws EmpException{
		List<Emp> elist = edj.getEmpList();
		int len = elist.size();
		assertTrue(len > 0);
	}
}
