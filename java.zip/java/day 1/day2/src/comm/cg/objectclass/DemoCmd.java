package comm.cg.objectclass;

public class DemoCmd {

	public static void main(String[] args) {
		int x = Integer.parseInt(args[0]);
		int y = Integer.parseInt(args[1]);
		int z = Integer.parseInt(args[2]);
		System.out.println("result = " +(x+y+z));
		

	}

}
