package com.capgemini.service;

import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;

public interface EmpService {

	boolean validateName(String name);

	boolean saveEmp(Emp emp);

	Emp getEmp() throws EmpException;

}
