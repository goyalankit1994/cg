import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cg.frs.exception.FlatRegisterationException;
import com.cg.frs.service.FlatRegisterationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;


public class getAllOwnerDaoTest {

	IFlatRegisterationService flatRegisteration;
	List<Integer> idList = null;
	@Before
	public void setUp() throws Exception {
		flatRegisteration = new FlatRegisterationServiceImpl();
	}

	@Test
	public void test() throws FlatRegisterationException {
		idList = flatRegisteration.getAllOwnerIds();
		assertNotNull(idList);
	}

}
