package com.cg.tatasky.dto;

public class TataSkyBean {
	private int userId;
	private String userName;
	private String mobileNumber;
	private int balance;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "TataSkyBean [userId=" + userId + ", userName=" + userName
				+ ", mobileNumber=" + mobileNumber + ", balance=" + balance
				+ "]";
	}
	
}
