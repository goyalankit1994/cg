package lab5_3;

import lab5_3.Person;

public abstract class Account  extends Person
{
	private int accno=(int) Math.floor(Math.random() *1000000); 
	private double balance;
	private Person accholder ;

	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccholder() {
		return accholder;
	}
	public void setAccholder(Person accholder) {
		this.accholder = accholder;
	}
	@Override
	public String toString() {
		return "Account [accno=" + accno + ", balance=" + balance
				+ ", accholder=" + accholder + "]";
	}
	 public abstract void Deposit(double Amount);
	
	 public abstract  void withdraw(double Amount);

}