package com.capgemini.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.capgemini.ams.DButil.DBUtil;
import com.capgemini.ams.DButil.QueryMapper;
import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

public class AMSDaoImpl implements IAMSDao {
	
	Connection con;
	Logger logger = Logger.getLogger(AMSDaoImpl.class);
	
	public AMSDaoImpl() {
		// TODO Auto-generated constructor stub
		con = DBUtil.getConnection();
	}

     
	@Override
	public ArrayList<Asset> showAllAssets() throws AssetException {
		// TODO Auto-generated method stub
		ArrayList<Asset> assetList = new ArrayList<Asset>();
		try {
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(QueryMapper.GET_ALL_ASSETS);

			while (result.next()) {
				Asset asset = new Asset();
				
				asset.setAssetId(result.getInt("ASSETID"));
				asset.setAssetName(result.getString("ASSETNAME"));
				asset.setAssetDesc(result.getString("ASSETDES"));
				asset.setQuantity(result.getInt("QUANTITY"));

				assetList.add(asset);

			}
			if (assetList.size() == 0) {
				
				logger.error("No Record Found in Asset Table");
				throw new AssetException("No Record Found in Asset Table");
			}
		} catch (SQLException e) {
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException :" + e.getMessage());

		}
		return assetList;
	}
	
	
	@Override
	public boolean validateAssetId(int assetId) throws AssetException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try {
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.VALIDATE_ASSETID);
			pstmt.setInt(1, assetId);
			ResultSet result=pstmt.executeQuery();
			
			if(result.next())
			{
				flag=true;
				logger.info("Validation successful for asset id "+assetId);
			}
			else
			{
				flag=false;
				logger.error("Validation unsuccessful for asset id "+assetId);
				//throw new AssetException("Invalid Asset id, Enter correct asset id");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException :" + e.getMessage()); 
		}
		return flag;
	}

	@Override
	public boolean checkQuantity(int quantity, int assetId) throws AssetException {
		// TODO Auto-generated method stub
		boolean flag = false;
		
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.GET_ASSET_QUANTITY);
			pstmt.setInt(1, assetId);
			ResultSet result = pstmt.executeQuery();
			if(result.next())
			{
				int availQuant = result.getInt(1);
				if(quantity <= availQuant)
				{
					flag= true;
					logger.info("Required quantity is available for asset id "+assetId);
				}
				else 
				{
					flag = false;
					logger.error("Required quantity is not available for asset id "+assetId);
					//throw new AssetException("Required Quantity Not Available");
				}
				
				
			}
			else 
			{
				flag = false;
				logger.error("Asset not found for asset id "+assetId);
				//throw new AssetException("Required Asset Not Found");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException :" + e.getMessage()); 
		}
	
		return flag;
	}

	@Override
	public ArrayList<AssetRequest> showAllRequests() throws AssetException {
		// TODO Auto-generated method stub
		ArrayList<AssetRequest> requestList = new ArrayList<AssetRequest>();
		try {
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(QueryMapper.GET_ALL_REQUESTS);

			while (result.next()) {
				AssetRequest request = new AssetRequest();
				request.setRequestId(result.getInt("REQUESTID"));
				request.setAssetId(result.getInt("ASSETID"));
				request.setMgrCode(result.getInt("MGRCODE"));
				request.setAssetName(result.getString("ASSETNAME"));
				request.setAssetDesc(result.getString("ASSETDES"));	
				request.setAssetQuantity(result.getInt("QUANTITY"));
				request.setStatus(result.getString("STATUS"));
				request.setEmpNum(result.getInt("EMPNUM"));

				requestList.add(request);

			}
			if (requestList.size() == 0) {
				
				logger.error("No Record Found in AssetRequest Table");
				throw new AssetException("No Record Found in request Table");
			}
		} catch (SQLException e) {
			
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException :" + e.getMessage());

		}

		return requestList;
	}

	@Override
	public boolean validateRequestId(int requestId) throws AssetException {
		// TODO Auto-generated method stub
		boolean flag =false;
		
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.VALIDATE_REQUEST_ID);
			pstmt.setInt(1, requestId);
			
			ResultSet result = pstmt.executeQuery();
			
			if(result.next())
			{
				flag = true;
			}
			else
			{
				flag = false;
				logger.error("Request id "+requestId +" not found");
				//throw new AssetException("Request id "+requestId +" not found");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException :" + e.getMessage());
		}
		
		return flag;
	}

	@Override
	public AssetRequest getRequesDetails(int requestId) throws AssetException {
		// TODO Auto-generated method stub
		AssetRequest request = null;
		
		
		try 
		{
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.GET_REQUEST_DETAILS);
			pstmt.setInt(1, requestId);
			
			ResultSet result=pstmt.executeQuery();
			
			if(result.next())
			{
				request=new AssetRequest();
				request.setRequestId(result.getInt("REQUESTID"));
				request.setAssetId(result.getInt("ASSETID"));
				request.setMgrCode(result.getInt("MGRCODE"));
				request.setEmpNum(result.getInt("EMPNUM"));
				request.setAssetName(result.getString("MGRCODE"));
				request.setAssetDesc(result.getString("ASSETDES"));
				request.setAssetQuantity(result.getInt("QUANTITY"));
				request.setStatus(result.getString("STATUS"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException :" + e.getMessage());
		}
		return request;
	}

	@Override
	public Asset getAssetDetailsById(int assetid) throws AssetException {
		// TODO Auto-generated method stub
		Asset asset=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.GET_ASSET_DETAILS);
			pstmt.setInt(1, assetid);
			
			ResultSet result=pstmt.executeQuery();
			if(result.next())
			{
				asset=new Asset();
				asset.setAssetId(result.getInt("ASSETID"));
				asset.setAssetName(result.getString("ASSETNAME"));
				asset.setAssetDesc(result.getString("ASSETDES"));
				asset.setQuantity(result.getInt("QUANTITY"));	
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQLException :" + e.getMessage());
		}
		
		return asset;
	}
}
