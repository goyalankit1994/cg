package com.cg.eis.bean;

public class EmployeeException extends Exception {

	public EmployeeException(String string) {
		super(string);
	}

}