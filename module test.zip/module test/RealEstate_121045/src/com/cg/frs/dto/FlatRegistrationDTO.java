package com.cg.frs.dto;

public class FlatRegistrationDTO {
	
	int ownerID;
	int flatType;
	int flatArea;
	double rentAmount;
	double depositeAmount;
	
	public FlatRegistrationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlatRegistrationDTO(int ownerID, int flatType, int flatArea,
			double rentAmount, double depositeAmount) {
		super();
		this.ownerID = ownerID;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositeAmount = depositeAmount;
	}

	public int getOwnerID() {
		return ownerID;
	}

	public void setOwnerID(int ownerID) {
		this.ownerID = ownerID;
	}

	public int getFlatType() {
		return flatType;
	}

	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}

	public int getFlatArea() {
		return flatArea;
	}

	public void setFlatArea(int flatArea) {
		this.flatArea = flatArea;
	}

	public double getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}

	public double getDepositeAmount() {
		return depositeAmount;
	}

	public void setDepositeAmount(double depositeAmount) {
		this.depositeAmount = depositeAmount;
	}

	@Override
	public String toString() {
		return "Flat [ownerID=" + ownerID + ", flatType=" + flatType
				+ ", flatArea=" + flatArea + ", rentAmount=" + rentAmount
				+ ", depositeAmount=" + depositeAmount + "]";
	}
}
