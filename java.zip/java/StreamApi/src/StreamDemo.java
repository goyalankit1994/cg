import java.util.Arrays;
import java.util.stream.Stream;


public class StreamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Integer[]arr={11,12,34,56,10};
Stream<Integer>Stream = Arrays.stream(arr);
Stream.forEach((var)->System.out.println(var));


Stream<String>atreamstr = Stream.of("capgemini","IGATE","mumbai");
Streamstr.forEach((str)->System.out.println(str.length()));
Stream<String> fstr = Stream.filter((str)->(str.length()==6));
	}

}
