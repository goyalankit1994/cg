package com.capgemini.cab.service;

import java.sql.SQLException;
import java.util.regex.Pattern;

import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.exception.CabException;
import com.capgemini.cabs.bean.CabRequest;


public class CabService implements ICabService {
	ICabRequestDAO contDao = new CabRequestDAO();

	@Override
	public Boolean addCabRequestDetails(CabRequest cabRequest) throws CabException,SQLException {
		
		 return contDao.addCabRequestDetails(cabRequest);
	}

	@Override
	public CabRequest getRequestDetails(int requestId) throws CabException,SQLException {
		// TODO Auto-generated method stub
		return contDao.getRequestDetails(requestId);
	}

	@Override
	public boolean isValidEnquiry(CabRequest req) {
		
		String name = req.getCname();
		String pnum = req.getPhonenum();
		String address = req.getPickupadd();
		
		
		
		try
		{
			validateFirstName(name);
			validatephonenumber(pnum);
			
			validateaddrss(address);
			
		}
		catch(CabException e)
		{
			System.out.println(e.getMessage());
			return false;
		}
		return true;
	}



	private void validateaddrss(String address) throws CabException {
		String paddress="[A-Z][a-z]{2,20}";
		boolean msg =Pattern.matches(paddress,address);
		if(!msg)
		{
			throw new CabException("Enter address properly");
		}
		
	}

	

	private void validatephonenumber(String pnum) throws CabException {
		String pattPhone="[0-9]{10}";
		boolean msg =Pattern.matches(pattPhone,pnum);
		if(!msg)
		{
			throw new CabException("Phone no should contain 10 digits only");
		}
	}

	private void validateFirstName(String name) throws CabException {
		String pattFName="[A-Z][a-z]{2,20}";
		boolean msg =Pattern.matches(pattFName,name);
		if(!msg)
		{
			throw new CabException("Enter first name properly");
		}
		
	}

	@Override
	public void setDao(ICabRequestDAO dao) {
	this.contDao=dao;
		
	}
	}
	


