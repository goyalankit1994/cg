import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.cg.frs.service.FlatRegisterationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;


public class validateFlatArea {

	String flatArea;
	IFlatRegisterationService flatRegisteration;
	@Before
	public void setUp() throws Exception {
		flatArea = "2500";
		flatRegisteration = new FlatRegisterationServiceImpl();
	}

	@Test
	public void test() {
		boolean isValid = flatRegisteration.validateFlatArea(flatArea);
		assertTrue(isValid);
	}

}
