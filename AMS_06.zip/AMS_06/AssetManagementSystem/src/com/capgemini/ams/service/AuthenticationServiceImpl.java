package com.capgemini.ams.service;

import oracle.net.aso.p;

import com.capgemini.ams.dao.AdminDAOImpl;
import com.capgemini.ams.dao.IAdminDAO;
import com.capgemini.ams.dao.IAuthenticationDAO;
import com.capgemini.ams.dao.IManagerDAO;
import com.capgemini.ams.dao.AuthenticationDAOImpl;
import com.capgemini.ams.dao.ManagerDAOImpl;
import com.capgemini.ams.exception.AssetException;

public class AuthenticationServiceImpl implements IAuthenticationService{

	IAuthenticationDAO loginDao;
	
	public void setDao(AuthenticationDAOImpl authDao) {

		loginDao = authDao;
	}

	
	public AuthenticationServiceImpl()
	{
		// TODO Auto-generated constructor stub
		loginDao=new AuthenticationDAOImpl(); 		
	}
	
	
	@Override
	public boolean validateUserName(String userName) throws AssetException {

		// TODO Auto-generated method stub
		
		return loginDao.validateUserName(userName);
	}


	@Override
	public boolean validatePassword(String password) throws AssetException {
		// TODO Auto-generated method stub
		return loginDao.validatePassword(password);
	}


	@Override
	public String getUserType(String userName, String password)
			throws AssetException {
		// TODO Auto-generated method stub
		return loginDao.getUserType(userName,password);
	}


	@Override
	public int getMgrCode(String userName, String password)
			throws AssetException {
		// TODO Auto-generated method stub
		return loginDao.getMgrCode(userName,password);
	}


	
}
