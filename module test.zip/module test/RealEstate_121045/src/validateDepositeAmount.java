import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.frs.service.FlatRegisterationServiceImpl;
import com.cg.frs.service.IFlatRegisterationService;


public class validateDepositeAmount {

	String deposite;
	double rent;
	IFlatRegisterationService flatRegisteration;
	@Before
	public void setUp() throws Exception {
		deposite = "3500";
		rent = 4000.00;
		flatRegisteration = new FlatRegisterationServiceImpl();
	}

	@Test
	public void test() {
		boolean isValid = flatRegisteration.validateDesiredDepositeAmount(deposite, rent);
		assertTrue(isValid);
	}

}
