package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import oracle.net.aso.p;

import com.capgemini.bean.BillDetail;
import com.capgemini.bean.Consumer;
import com.capgemini.exception.EBillException;
import com.capgemini.util.DBUtil;
import com.capgemini.util.QueryMapper;

public class EBillDAOImpl implements EBillDAO {

	private DataSource dataSource;

	public EBillDAOImpl() throws EBillException {

		dataSource = DBUtil.getDataSource();

	}

	@Override
	public List<Consumer> getAllConsumer() throws SQLException {
		List<Consumer> consumers = new ArrayList<>();
		Connection conn = dataSource.getConnection();
		Statement statement = conn.createStatement();
		ResultSet resultSet = statement
				.executeQuery(QueryMapper.GET_ALL_CONSUMERS);
		while (resultSet.next()) {
			int consumerNumber = resultSet.getInt(1);
			String consumerName = resultSet.getString(2);
			String address = resultSet.getString(3);
			Consumer consumer = new Consumer(consumerNumber, consumerName,
					address);
			consumers.add(consumer);
		}
		System.out.println(consumers);
		return consumers;
	}

	@Override
	public Consumer searchConsumer(int consumerNumber) throws EBillException {
		Consumer consumer = null;
		Connection conn;
		try {
			conn = dataSource.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(QueryMapper.SEARCH_CONSUMER);
			preparedStatement.setInt(1, consumerNumber);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()){
				String consumerName = resultSet.getString(2);
				String address = resultSet.getString(3);
				consumer = new Consumer(consumerNumber, consumerName, address);
			}
		} catch (SQLException e) {
			throw new EBillException("Error reading from database");
		}
		return consumer;
	}

	@Override
	public List<BillDetail> getBillDetails(int cnum) throws EBillException {
		List<BillDetail> billList = new ArrayList<>();
		BillDetail bill;
		Connection conn;
		try {
			conn = dataSource.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(QueryMapper.GET_BILL_DETAILS);
			preparedStatement.setInt(1, cnum);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()){
				bill = new BillDetail();
				bill.setBillNumber(resultSet.getInt(1));
				int consumerNumber = resultSet.getInt(2);
				String consumerName = resultSet.getString(3);
				String address = resultSet.getString(4);
				Consumer consumer = new Consumer(consumerNumber, consumerName,
						address);
				bill.setConsumer(consumer);
				bill.setCurrentReading(resultSet.getInt(5));
				bill.setUnitConsumed(resultSet.getInt(6));
				bill.setNetAmount(resultSet.getDouble(7));
				bill.setBillDate(resultSet.getDate(8));
				billList.add(bill);
			} 
		} catch (SQLException e) {
			throw new EBillException("Error Fetching Bill Details for Consumer ID : " + cnum);
		}
		return billList;
	}

	@Override
	public int generateNextBill(BillDetail nextBill) throws EBillException {
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(QueryMapper.GENERATE_NEXT_BILL);
			preparedStatement.setInt(1, nextBill.getConsumer().getConsumerNumber());
			preparedStatement.setInt(2, nextBill.getCurrentReading());
			preparedStatement.setInt(3, nextBill.getUnitConsumed());
			preparedStatement.setDouble(4, nextBill.getNetAmount());
			int rows = preparedStatement.executeUpdate();
			if (rows > 0){
				Statement statement = conn.createStatement();
				ResultSet resultSet = statement.executeQuery(QueryMapper.GET_BILL_NUMBER);
				if (resultSet.next())
					return resultSet.getInt(1);
			}
		} catch (SQLException e) {
			throw new EBillException("Error Generating new Bill");
		}
		return 0;
	}
}
