package com.cg.frs.exception;

public class FlatRegisterationException extends Exception {

	public FlatRegisterationException(String message) {
		super(message);
	}
	
}
