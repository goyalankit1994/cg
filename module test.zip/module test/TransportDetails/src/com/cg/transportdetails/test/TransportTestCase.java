package com.cg.transportdetails.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;

import com.cg.transportdetails.dao.TransportDetailsDao;
import com.cg.transportdetails.dao.TransportDetailsDaoImpl;
import com.cg.transportdetails.dto.BookingBean;
import com.cg.transportdetails.exception.TransportException;
import com.cg.transportdetails.service.TransportDetails;
import com.cg.transportdetails.service.TransportDetailsServiceImpl;


public class TransportTestCase {

	TransportDetails service;
	TransportDetailsDao dao;
	@Before
	public void init()
	{
		service = new TransportDetailsServiceImpl();
		dao = new TransportDetailsDaoImpl();
	service.setDao(dao);
	}
	@Test
	public void testRetrieveTransportDetails() throws TransportException{
		assertNotNull(dao.retrieveTransportDetails());
	}

	@Test
	public void testBookTrucks() throws TransportException {
		BookingBean bean= new BookingBean();
		bean.setCustId("1004");
		bean.setCustMobile(854698745);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		System.out.println("enter date ");
		String input = "2016-10-15";
		LocalDate date = LocalDate.parse(input, format);
		bean.setDateOfTransport(date);
		bean.setNoOfTruck(1);
		bean.setTruckId(10002);
		
		assertNotEquals(0, dao.bookTrucks(bean));
	}

}
