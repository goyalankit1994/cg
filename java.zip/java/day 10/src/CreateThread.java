
public class CreateThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
MyThread ref = new  MyThread();
Thread t1 = new Thread(ref);
t1.setPriority(8);
t1.start();

Thread t2 = new Thread(ref);
t2.setPriority(3);
t2.start();
	}

}
