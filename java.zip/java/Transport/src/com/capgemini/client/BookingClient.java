/**
 * 
 */
package com.capgemini.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TruckBean;
import com.capgemini.service.ITruckService;
import com.capgemini.service.TruckService;

/**
 * @author angoyal
 *
 */
public class BookingClient {
	static ITruckService tsd = new TruckService();


	public static void main(String[] args) {
		int choice = 0;
		try (BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in))) {
			do {
				System.out.println("1----Book Trucks");
				System.out.println("2----EXIT");
				System.out.println("enter your choice");
				choice = Integer.parseInt(read.readLine());
				switch (choice) {
				case 1:
					List<TruckBean> list = new ArrayList<TruckBean>();
					System.out.println("enter customer id ");
					String CustId = read.readLine();
					if(tsd.Validation(CustId))
					{
					BookingBean bean = new BookingBean();
					bean.setCustid(CustId);
					list = tsd.retrieveTruckDetails();
					for (TruckBean obj : list)
						System.out.println(obj);
				
					System.out.println("enter truck id ");
					bean.setTruckid(Integer.parseInt(read.readLine()));
					System.out.println("enter number of trucks");
					bean.setNooftrucks(Integer.parseInt(read.readLine()));
					boolean number = false;
					while(!number)
					{
						System.out.println("enter customer mobile");
						String num = read.readLine();
						number = tsd.validatemobilenumber(num);
						if(number)
						{
							bean.setCustMobile(Long.parseLong(num));
						}
						else
						{
							System.out.println("enter 10 digits mobile number");
						}
					}
					// for date validation
					boolean da = false;
					while(!da)
					{
						DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						System.out.println("enter date");
						String input =read.readLine();
						LocalDate date = LocalDate.parse(input,format);
						da=tsd.validateDate(date);
						if(da)
						{
							bean.setDateoftransport(date);
							
						}
						else
						{
							System.out.println("please enter a valid date");
						}
					}
					// end of date validation
					
					
					
					
					DateTimeFormatter format = DateTimeFormatter
							.ofPattern("yyyy-MM-dd");
					System.out.println("enter date ");
					String input = read.readLine();
					LocalDate date = LocalDate.parse(input, format);
					bean.setDateoftransport(date);
					
					
					
					int id = tsd.bookTrucks(bean);
					if (id!=0)
						System.out.println("");
					else
						throw new BookingException("Validation not successfull");
					}
					else
					{
						throw new BookingException("customer id not valid");
					}
					break;
					
				case 2:
					System.out.println("thank you for using this application");
					try
					{
						tsd.closeconn();
					}
					catch(BookingException e)
					{
						System.out.println(e.getMessage());
					}
					choice = 0;
					break;
				}
			} while (choice !=0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
