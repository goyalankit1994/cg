package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.capgemini.bean.Bean;
import com.capgemini.util.DBUtil;

public class DAOImpl implements IDAO {

	DataSource dataSource;
	private String inertQuery = "insert into registeredusers values(?,?,?,?,?,?)";
	
	public DAOImpl() {
		dataSource = DBUtil.getDataSource();
	}


	@Override
	public boolean insert(Bean bean) {
		try {
			Connection connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(inertQuery );
			preparedStatement.setString(1, bean.getFirstName());
			preparedStatement.setString(2, bean.getLastName());
			preparedStatement.setString(3, bean.getPassword());
			preparedStatement.setString(4, bean.getGender().toString());
			preparedStatement.setString(5, bean.getSkills());
			preparedStatement.setString(6, bean.getCity());
			int rows = preparedStatement.executeUpdate();
			if (rows > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
