package comm.cg.wrapper;

public class Demo {

	public static void main(String[] args) {
     Integer obj = new Integer(90);
     Integer ref = 100;
     int var=50;
     Integer ref1=new Integer(var); // built in into object (boxing)
     int val = ref1.intValue(); //(unboxing)
     if(ref1==val)
    	 System.out.println("ref1  and val are equal");
     else
    	 System.out.println("not equal");
     Integer I1 = var; // AUTOBOXING
     int x= I1; // AUTO UNBOXING
     if(I1 == x)
    	 System.out.println("x and I1 are equal");
     else
    	 System.out.println("not equal");
     Integer ref2 = new Integer(100);
     Integer ref3 = new Integer(100);
     Integer ref4= 100;
     Integer ref5 = 100;
     if(ref2==ref3)
    	 System.out.println("ref2  and ref3 are equal");
     if(ref2==ref4)
    	 System.out.println("ref2 and ref4 are equal");
     if(ref4 == ref5)
    	 System.out.println("ref4 and ref5 are equal");
     
  
    	 
     

	}

}
