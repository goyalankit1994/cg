package com.cg.eis.pl;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class Client {

	
		static EmployeeService eService = new EmployeeServiceImpl();
		public static Map<Integer, Employee> empMap = new HashMap<Integer, Employee>();
		static Scanner input = new Scanner(System.in);
		static boolean execute = true;
		static boolean isSuccessful = false;

		public static void main(String args[]) {

			String choice = null;

			while (execute) {
				System.out.println("\n1. Add Empoyee");
				System.out.println("2. Display Employee Based on Insurance Scheme");
				System.out.println("3. Delete Employee Details");
				System.out.println("4. Sort Employee Details Based on Salary");
				System.out.println("5. Exit");
				System.out.println("Enter Your Choice ");
				choice = input.next();
				executeChoice(choice);
			}

		}

		private static void executeChoice(String choice) {

			switch (choice) {
			case "1":

				Employee emp = new Employee();
				System.out.println("Enter Employee Details");
				System.out.println("Enter Employee ID : ");
				emp.setId(input.nextInt());
				System.out.println("Enter Name : ");
				emp.setName(input.next());
				System.out.println("Enter Salary : ");
				emp.setSalary(input.nextDouble());
				System.out.println("Enter Designation : ");
				emp.setDesignation(input.next());
				System.out.println("Enter Insurance Scheme : ");
				emp.setInsuranceScheme(input.next());
				
				empMap = eService.addEmployee(emp);

				System.out.println(empMap);

				break;

			case "2":
				System.out.println("Enter Insurance Scheme : ");
				String InsuranceScheme = input.next();
				
				isSuccessful = eService.printEmployeeBasedOnInsuranceScheme(empMap, InsuranceScheme);
				if (!isSuccessful){
					System.out.println("No Record Found For Entered Insurance Scheme");
				} else{
					isSuccessful = false;
				}
				
				break;

			case "3":
				System.out.println("Enter Employee ID to be deleted : ");
				int id= input.nextInt();
				empMap = eService.deleteEmployee(id, empMap);
				System.out.println("Employee Details After Deletion");
				System.out.println(empMap);
				break;
			
			case "4":
				
				eService.sortEmployeeOnSalary(empMap);
				break;
				
			case "5":
				System.out.println("Exiting Application");
				execute = false;
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
		}
	}


