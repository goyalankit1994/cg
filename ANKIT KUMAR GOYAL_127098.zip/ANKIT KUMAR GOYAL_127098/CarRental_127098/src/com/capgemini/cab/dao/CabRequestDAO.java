package com.capgemini.cab.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.cab.dbutil.DBUtill;
import com.capgemini.cab.exception.CabException;
import com.capgemini.cab.logger.MyLogger;
import com.capgemini.cabs.bean.CabRequest;


public class CabRequestDAO implements ICabRequestDAO {
	Logger logger = MyLogger.getLoggerInsatnce();
	Connection con;
	public CabRequestDAO()
	{
		con = DBUtill.getConnection();
		if(con!=null)
		{
			logger.info("obtained connection");
		}
	}

	@Override
	public Boolean addCabRequestDetails(CabRequest cabRequest) throws CabException,
	SQLException  {
	String sql = "INSERT INTO CAB_REQUEST VALUES(SEQ_REQUEST_ID.NEXTVAL,?,?,?,?,?,?,?)";
	try
	{
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1,cabRequest.getCname());
		pstmt.setString(2,cabRequest.getPhonenum());
		pstmt.setDate(3,Date.valueOf(cabRequest.getDate()));
		pstmt.setString(4,cabRequest.getRequeststatus());
		pstmt.setString(5,cabRequest.getCabnum());
		pstmt.setString(6,cabRequest.getPickupadd());
		pstmt.setString(7,cabRequest.getPincode());
		logger.info("inserted record"+cabRequest);
		//int row = pstmt.executeUpdate();
		System.out.println("Inserted Successfully");
	}
	catch ( SQLException e)
	{
		logger.error("Exception occured"+e.getMessage());
		e.printStackTrace();
	}
	return false;
}
	

	@Override
	public CabRequest getRequestDetails(int requestId) throws CabException,SQLException {
		
		Connection con = null;
		CabRequest enqry = null;
		
		String queryThree="Select * from cab_request where request_id=?";
		
		try
		{
			con = DBUtill.getConnection();
			PreparedStatement ptsm=con.prepareStatement(queryThree);
			ptsm.setInt(1,requestId );;
			ResultSet res = ptsm.executeQuery();
			
			while(res.next())
			{
				enqry=new CabRequest();
				enqry.setCname(res.getString("Cname"));
				enqry.setPhonenum(res.getString("phonenum"));
				//enqry.setDate(res.getDate("contactno"));
				enqry.setRequeststatus(res.getString("RequestStatus"));
				enqry.setCabnum(res.getString("cab number"));
				enqry.setPickupadd(res.getString("pickup"));
				enqry.setPincode(res.getString("pincode"));
				logger.info("fetch record"+enqry);
				
				
			}
			
		}
		catch(SQLException e)
		{
			logger.error("exception occured during get by id"+e.getMessage());
			System.out.println("exception occured"+e.getMessage());
		}
		return enqry;

	}
	

}
