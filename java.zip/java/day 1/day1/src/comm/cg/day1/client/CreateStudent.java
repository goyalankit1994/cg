package comm.cg.day1.client;

import comm.cg.day1.Student;
import static java.lang.Math.*;

public class CreateStudent {

	public static void main(String[] args) 
	{
		Student stu = new Student(10,"priya");
		System.out.println("id of ref ="+stu.getSid());
		System.out.println("name of ref="+stu.getSname());
		// TODO Auto-generated method stub

	}

}
