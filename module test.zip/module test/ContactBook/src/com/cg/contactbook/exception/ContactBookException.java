package com.cg.contactbook.exception;

@SuppressWarnings("serial")
public class ContactBookException extends Exception
{
	String message;
	public ContactBookException(String message)
	{
		this.message = message;
	}
	@Override
	public String getMessage() 
	{
		// TODO Auto-generated method stub
		return message;
	}
}
