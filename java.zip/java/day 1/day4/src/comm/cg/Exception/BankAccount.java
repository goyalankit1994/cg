package comm.cg.Exception;

public class BankAccount {
int balance;
public BankAccount(int balance)
{
	this.balance = balance;
	
}
public void withdraw(int amt) throws BankException
{
//	try
//	{
if(balance < amt)
		{
			throw new BankException("not enough balance");
		}
//	balance = balance -amt;
//	}
//	catch(BankException e)
//	{
//		System.out.println(e.getMessage());
//	}
}
public void deposit(int amt)
{
	balance = balance +amt;
}
public int getBalance()
{
	return balance;
}
}
