package com.cg.contactbook.service;

import java.sql.SQLException;

import com.cg.contactbook.dto.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;

public interface ContactBookService 
{
	public void addEnquiry(EnquiryBean enqry) throws ContactBookException,SQLException;
	public EnquiryBean getEnquiryDetails(int Enquiryid)throws ContactBookException;
	public boolean isValidEnquiry(EnquiryBean enqry)throws ContactBookException;
}
