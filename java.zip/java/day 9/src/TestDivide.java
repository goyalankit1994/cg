import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestDivide {
	CalDiv ref;
	@Before
	public void INIT()
	{
		ref = new CalDiv();
	}

	@Test(expected=ArithmeticException.class)
	public void testCalDivide() {
		ref.divide(6,0);
	}

}
