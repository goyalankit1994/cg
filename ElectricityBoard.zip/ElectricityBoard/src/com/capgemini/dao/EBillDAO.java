package com.capgemini.dao;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.bean.BillDetail;
import com.capgemini.bean.Consumer;
import com.capgemini.exception.EBillException;

public interface EBillDAO {
	public List<Consumer> getAllConsumer() throws SQLException;

	public Consumer searchConsumer(int consumerNumber) throws EBillException;

	public List<BillDetail> getBillDetails(int cnum) throws EBillException;

	public int generateNextBill(BillDetail nextBill) throws EBillException;
}
