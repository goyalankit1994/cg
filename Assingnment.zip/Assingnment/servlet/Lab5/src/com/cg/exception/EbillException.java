package com.cg.exception;

public class EbillException extends Exception {
	String message;
	public EbillException(String message)
	{
		this.message = message;
	}
	public String getMessage() 
	{
		// TODO Auto-generated method stub
		return message;
	}
}

