package com.capgemini.service;

import com.capgemini.dao.EmpDAO;
import com.capgemini.dao.EmpDAOimpl;
import com.capgemini.exception.EmpException;
import com.capgemini.to.Emp;

public class EmpServiceimpl implements EmpService {
	
	EmpDAO eDao;
	
	
	public EmpServiceimpl() {
		//initialize only one
		eDao = new EmpDAOimpl();
	}

	@Override
	public boolean validateName(String name) {
		
		return name.matches("[A-Z][A-Za-z]*");
	}

	@Override
	public boolean saveEmp(Emp emp) {
		boolean saved = false;
		saved = eDao.saveEmp(emp);
		return saved;
	}

	@Override
	public Emp getEmp() throws EmpException {
		return eDao.getEmp();
	}
	
	

}
