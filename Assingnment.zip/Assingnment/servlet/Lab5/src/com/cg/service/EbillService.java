package com.cg.service;

import java.util.List;

import com.cg.dto.BillDetails;
import com.cg.dto.EbillBean;
import com.cg.exception.EbillException;

public interface EbillService {
	List<EbillBean> getAllConsumer() throws EbillException;

	EbillBean searchConsumer(int con_Number) throws EbillException;

	List<BillDetails> getBillDetails(int cnum) throws EbillException;

	int calculateUnitConsumed(int lastMonthMeterReading,
			int currentMonthMeterReading) throws EbillException;

	double calculateNetAmount(int unit_Consumed);

	int generateNextBill(BillDetails nextBill) throws EbillException;
}

