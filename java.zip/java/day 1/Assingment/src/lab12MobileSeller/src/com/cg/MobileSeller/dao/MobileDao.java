package com.cg.MobileSeller.dao;

import java.util.List;
import java.util.Map;

import com.cg.MobileSeller.Exception.MobileException;
import com.cg.MobileSeller.dto.MobileBean;
import com.cg.MobileSeller.dto.PurchaseBean;

public interface MobileDao {
	public boolean saveCust(PurchaseBean cus) throws MobileException;

	Map<Integer, Integer> getMap() throws MobileException;

	List<MobileBean> getMobList() throws MobileException;

	public boolean deleteMobile(int mobileid_delete) throws MobileException;

	List<MobileBean> getMobPriceList(int p1, int p2) throws MobileException;

}
