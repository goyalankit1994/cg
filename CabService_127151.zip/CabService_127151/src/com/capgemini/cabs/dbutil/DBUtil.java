package com.capgemini.cabs.dbutil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBUtil {

	
	static Properties prop=new Properties();
	static String driver;
	static String user;
	static String pass;
	static String url;
	static Connection con;
	
	static{
		try {
			
			//To load and Fetch driver details from given file
			prop.load(new FileInputStream("jdbc.properties"));
			driver=prop.getProperty("driver");
			url=prop.getProperty("url");
			user=prop.getProperty("user");
			pass=prop.getProperty("pass");
			Class.forName(driver);
			con=DriverManager.getConnection(url, user, pass);
			
		} 
		catch (FileNotFoundException e)
		{
			
			System.out.println(e.getMessage());
		}
		catch (Exception e)
		{
			
			System.out.println(e.getMessage());
		}
	}
	
	
	public static Connection getConnection()
	{
		return con;
	}
	
	
}
