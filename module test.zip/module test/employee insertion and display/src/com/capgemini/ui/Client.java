package com.capgemini.ui;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.exception.EmpException;
import com.capgemini.service.EmpService;
import com.capgemini.service.EmpServiceimpl;
import com.capgemini.to.Emp;


public class Client {
	
	static Scanner scan = new Scanner(System.in);
	static EmpService eService = new EmpServiceimpl();
	
	public static void main(String[] args) {
		
		System.out.println("Choose option from below");
		System.out.println("1. save employee");
		System.out.println("2. Display Employee");
		System.out.println("3. Exit");
		String choice = scan.nextLine();
		executeCaseChoice(choice);
	}

	private static void executeCaseChoice(String choice) {
		// TODO Auto-generated method stub
		Emp emp = null;
		switch (choice) {
		case "1":
			System.out.println("***Save an Employee**");
			System.out.println("Enter Employee Details : ");
			System.out.println("Enter ID :");
			int id;
			String name= null;
			String designation = null;
			Double salary;
			do{
				try {
					id = Integer.parseInt(scan.next());
					break;
				} catch (InputMismatchException e) {
					System.out.println("Enter Number Only");
					//scan.nextLine();
				}
			}while(true);
			
			boolean nameValid = false;
			while(!nameValid){
				System.out.println("Enter Name :");
				name = scan.next();
				nameValid = eService.validateName(name);
				if(!nameValid)
					System.out.println("Name should start with uppercase and have alphabets only");
			}
			
			System.out.println("Enter Designation");
			designation = scan.next();
			System.out.println("Enter Salary : ");
			salary = scan.nextDouble();
			System.out.println("<ID> <Name> <Designaion> <Salary>");
			emp = new Emp(id,name,designation,salary);
			boolean saved = eService.saveEmp(emp);
			//System.out.println(emp);
			if(saved)
				System.out.println("Emp Saved");
			else
				System.out.println("Sorry...Emp could not be saved");
			break;
			
		case "2":
			try {
				emp = eService.getEmp();
			} catch (EmpException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				break;
			}
			System.out.println(emp);
			break;
			
		case "3":
			System.out.println("Thank for using this application");
			break;

		default:
			System.out.println("invalid choice");
			break;
		}
	}

}
