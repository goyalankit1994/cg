package comm.cg.inheritence;

 public abstract  class Employee {
	 private int empid;
	private String name;
	abstract  public double calsal();
	{
		
	}
	public Employee()
	{
		
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + "]";
	}
	public Employee(int empid,String name)
	{
		this.empid=empid;
		this.name=name;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
