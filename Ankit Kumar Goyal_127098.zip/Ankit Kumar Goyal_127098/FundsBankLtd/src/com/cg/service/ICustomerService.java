package com.cg.service;

import com.cg.bean.ComplaintBean;
import com.cg.exception.BankException;

public interface ICustomerService {
	public ComplaintBean raiseCustomerComplaint(ComplaintBean bean) throws BankException;
	public ComplaintBean checkComplaintStatus(int complaintid) throws BankException;
	public int getComplaintId(ComplaintBean bean) throws BankException;
}
