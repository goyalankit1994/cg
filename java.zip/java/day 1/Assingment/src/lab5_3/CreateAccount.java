package lab5_3;

import lab5_3.Account;
import lab5_3.Person;

public class CreateAccount {
public static void main(String[] args) {

			Person p = new Person("smith", 21);
			Person p1 = new Person("Kathy", 21);
			
//			Account acc = new Account(p, 2000);
//			acc.Deposit(2000);
//			Account a = new Account();
//			a.withdraw(2000);
//			if(Amount<(a.Balance-500))
//				a.Balance=a.Balance-Amount;
//			else
//				System.out.println("Not enough balance");
//			System.out.println("Available Balance in smith account  is "
//					+ acc.getBalance());
//			System.out.println("Available Balance kathy account is "
//					+ acc1.getBalance());
//			System.out.println(acc);
//			System.out.println(acc1);
//
		}

	}
	
