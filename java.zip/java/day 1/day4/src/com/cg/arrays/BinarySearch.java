package com.cg.arrays;

import java.util.Arrays;

public class BinarySearch {

	public static void main(String[] args) {
		int[]arr = {1,89,3,56,23};
		System.out.println("before sorting");
		for(int var:arr)
		{
			System.out.println(var);
		}
		Arrays.sort(arr);
		System.out.println("after sort");
		for(int var:arr)
		{
			System.out.println(var);
		}
		int[]arr1 = {1,89,3,56,23};
		for(int var:arr1)
		{
		 int n=Arrays.binarySearch(arr, 3);
		System.out.println(var);
		}
		System.out.println("location of element" + Arrays.binarySearch(arr, 3));
	}

	}

