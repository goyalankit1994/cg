package comm.cg.datetime;
import java.time.*;
public class DateDemo {

	public static void main(String[] args) {
		
		LocalDate date =LocalDate.now(); //obtain current date
		System.out.println("date is "+date);
		//to create own date
//LocalDate newDate = LocalDate.of(2017,05, 15);
//System.out.println("newDate = "+newDate);
ZonedDateTime zonedate = ZonedDateTime.now();
System.out.println("zone date time is "+zonedate);
ZonedDateTime zonedate1 = ZonedDateTime.of(LocalDate.now(),LocalTime.now(),ZoneId.of("europe/paris"));
System.out.println("zonedate"+zonedate1);

		
	}

}
