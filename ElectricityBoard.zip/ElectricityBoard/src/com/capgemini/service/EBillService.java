package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BillDetail;
import com.capgemini.bean.Consumer;
import com.capgemini.exception.EBillException;

public interface EBillService {
	List<Consumer> getAllConsumer() throws EBillException;

	Consumer searchConsumer(int consumerNumber) throws EBillException;

	List<BillDetail> getBillDetails(int cnum) throws EBillException;

	int calculateUnitConsumed(int lastMonthMeterReading,
			int currentMonthMeterReading) throws EBillException;

	double calculateNetAmount(int unitConsumed);

	int generateNextBill(BillDetail nextBill) throws EBillException;
}
