package com.cg.lab11.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.Date;

import com.cg.lab11.dto.MobileAppBean;
import com.cg.lab11.dto.PurchaseDetailsBean;
import com.cg.lab11.exception.PurchaseOrderException;
import com.cg.lab11.service.MobileAppService;
import com.cg.lab11.service.MobileAppServiceImpl;

public class Client {
	static MobileAppService mobservice= new MobileAppServiceImpl();
	public static void main(String[] args) {
		int choice=0;
		
		try(BufferedReader read= new BufferedReader(new InputStreamReader(System.in)))
		{
			do
			{
				System.out.println("1- Show Mobile ");
				System.out.println("2- Purchase Mobile");
				System.out.println("3- Search Mobile ");
				System.out.println("4- Delete Mobile ");
				System.out.println("Enter your Choice");
				choice = Integer.parseInt(read.readLine());
			
				switch(choice)
				{
				case 1:
						ArrayList<MobileAppBean> list=mobservice.getAllMobileRecords();
						for(MobileAppBean obj:list)
						{
							System.out.println("ID = "+obj.getMoibleid()+" Mobile Name= "+obj.getName()+" Quantity= "+obj.getQuantity()+" Price ="+obj.getPrice());
						System.out.println();
						}
						break;
						
				case 2: 
						PurchaseDetailsBean purchase= new PurchaseDetailsBean();
//						System.out.println("Enter Purchase Id ");
//						int pid=Integer.parseInt(read.readLine());
//						purchase.setPuchaseid(pid);
						System.out.println("Enter Customer Name: ");
						purchase.setCname(read.readLine());
						System.out.println("Enter Mail Id ");
						purchase.setMailid(read.readLine());
						System.out.println("Enter Mobile Number ");
						purchase.setMobilenumber(read.readLine());
						System.out.println("Enter Purchase Date (yyyy-mm-dd) ");
						purchase.setPurchaseDate(Date.valueOf(read.readLine()));
						System.out.println("enter Mobile Id ");
						purchase.setMobileid(Integer.parseInt(read.readLine()));
						if(mobservice.validation(purchase))
						{	
							boolean flag=mobservice.purchaseMobile(purchase);
							if(flag)
	//							System.out.println("inserted Success");
								mobservice.updateMobileDb(purchase);
							else
								System.out.println("Not Done");
						}
						else
							System.out.println("VALIDATION FAIL");
						break;
				case 3: 
						
						System.out.println("Enter The Minumum Price ");
						int min =Integer.parseInt(read.readLine());
						System.out.println("Enter MAximum price ");
						int max=Integer.parseInt(read.readLine());
						if(mobservice.searchMobile(min, max))
							System.out.println("Searching done.....");
						else
							throw new PurchaseOrderException("Not PRESENT IN THE DATABASE");
						break;
				case 4:
						System.out.println("Enter The Mobile Id ");
						int mid= Integer.parseInt(read.readLine());
						if(mobservice.deleteMobile(mid))
							System.out.println("Successfully updated ");
						else
							throw new PurchaseOrderException("Not PRESENT IN THE DATABASE");
						break;
				default:
						System.out.println("Invalid Choice ");
							
				}
				
			}while(choice!=0);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
