package com.capgemini.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.ams.DButil.DBUtil;
import com.capgemini.ams.DButil.QueryMapper;
import com.capgemini.ams.exception.AssetException;

public class AuthenticationDAOImpl implements IAuthenticationDAO{

	Connection con;
	Logger logger=Logger.getLogger(AuthenticationDAOImpl.class);
	
	public AuthenticationDAOImpl() {
		// TODO Auto-generated constructor stub
		con =DBUtil.getConnection();
	}
	
	@Override
	public boolean validateUserName(String userName) throws AssetException{
		// TODO Auto-generated method stub
		boolean flag=false;
		
		try {
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.VALIDATE_USERNAME);
			pstmt.setString(1, userName);
			ResultSet result=pstmt.executeQuery();
			
			if(result.next())
			{
				flag=true;
			}
			else
			{
				flag=false;
				throw new AssetException("Username is not valid.");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQL Exception :"+e.getMessage());
			
		}
		return flag;
	}

	@Override
	public boolean validatePassword(String password) throws AssetException {
		boolean flag=false;
		
		try {
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.VALIDATE_PASSWORD);
			pstmt.setString(1, password);
			ResultSet result=pstmt.executeQuery();
			
			if(result.next())
			{
				flag=true;
				logger.info("Password validated successfully");
			}
			else
			{
				flag=false;
				logger.error("Incorrect password");
				throw new AssetException("Incorrect password.");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQL Exception :"+e.getMessage());
		}
		return flag;
	}

	@Override
	public String getUserType(String userName, String password)
			throws AssetException {
		PreparedStatement pstmt;
		String userType=null;
		try {
			pstmt = con.prepareStatement(QueryMapper.GET_USERTYPE);
			pstmt.setString(1, userName);
			pstmt.setString(2, password);
			
			ResultSet result=pstmt.executeQuery();
			
			if(result.next())
			{
				userType=result.getString("usertype");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("SQL query execution fail");
			throw new AssetException("SQL Exception :"+e.getMessage());
		}
		return userType;
	}

	@Override
	public int getMgrCode(String userName, String password) throws AssetException {
		// TODO Auto-generated method stub
		
		int empNum = 0;
		PreparedStatement pstmt;
		
		try {
			pstmt = con.prepareStatement(QueryMapper.GET_EMP_NUM);
			pstmt.setString(1, userName);
			pstmt.setString(2, password);
			
			ResultSet result = pstmt.executeQuery();
			
			if(result.next())
			{
				empNum = result.getInt("empNum");
			}
		}
		catch(SQLException e)
		{
			logger.error("SQL query execution fail");
			throw new AssetException("SQL Exception :"+e.getMessage());
		}

		return empNum;
	}

}
