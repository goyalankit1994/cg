package lab3;
import java.util.Scanner;
public class CreatePersonModified {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		PersonModified p = new PersonModified("Ankit","Goyal");
		System.out.println("Person Details");
		System.out.println("--------------");
		System.out.println("First Name : " + p.getFirstName() );
		System.out.println("Last Name : " + p.getLastName());
	System.out.println("Enter Date of Birth (dd/mm/yyyy) : ");
		p.calculateAge(input.next());
		System.out.println("Full Name : " + p.getFullName());
		
		input.close();
	}

}
