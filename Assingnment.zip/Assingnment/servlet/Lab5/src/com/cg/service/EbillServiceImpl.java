package com.cg.service;

import java.util.List;

import com.cg.dto.BillDetails;
import com.cg.dto.EbillBean;
import com.cg.exception.EbillException;

public class EbillServiceImpl implements EbillService {

	@Override
	public List<EbillBean> getAllConsumer() throws EbillException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EbillBean searchConsumer(int con_Number) throws EbillException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BillDetails> getBillDetails(int cnum) throws EbillException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int calculateUnitConsumed(int lastMonthMeterReading,
			int currentMonthMeterReading) throws EbillException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateNetAmount(int unit_Consumed) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int generateNextBill(BillDetails nextBill) throws EbillException {
		// TODO Auto-generated method stub
		return 0;
	}

}
