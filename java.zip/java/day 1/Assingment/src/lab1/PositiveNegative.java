package lab1;

public class PositiveNegative {

	public static void main(String[] args) {
		
		if( Integer.parseInt(args[0]) > 0)
			System.out.println(args[0]+" is a positive number");
		else if(Integer.parseInt(args[0]) < 0)
			System.out.println(args[0]+" is a negative number");
		else
			System.out.println(args[0]+" is equal to zero"); 

	}

}
