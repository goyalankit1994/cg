package com.cg.onlineshopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.onlineshopping.bean.Customer;
import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.bean.Purchase;
import com.cg.onlineshopping.dbutil.DBUtil;
import com.cg.onlineshopping.exception.ShoppingException;

public class ShoppingDaoImpl implements ShoppingDao 
{
	Connection con;
	
	public ShoppingDaoImpl()
	{
		con = DBUtil.getConnection();
	}

	@Override
	public ArrayList<Product> getProducts(Customer cust) throws ShoppingException {
		// TODO Auto-generated method stub
		ArrayList<Product>list = new ArrayList<Product>();
		if(validate(cust)){
		try
		{
			String sql = "SELECT * FROM Product";
			Statement stmt = con.createStatement();
			ResultSet result =stmt.executeQuery(sql);
			while(result.next())
			{
				Product bean = new Product();
				bean.setProdId(result.getInt(1));
				bean.setProdName(result.getString(2));
				bean.setProdPrice(result.getInt(3));
				list.add(bean);
			}
			
		}
		
		catch(Exception e)
		{
			throw new ShoppingException(e.getMessage());
		}
		}
		return list;
	}

	public boolean validate(Customer bean)throws ShoppingException
	{
		boolean flag = false;
		String sql = "SELECT custName FROM CUSTOMER WHERE custId=?";
		try
		{
			PreparedStatement stmt =con.prepareStatement(sql);
			stmt.setInt(1, bean.getCustId());
			ResultSet result = stmt.executeQuery();
			if(result.next())
				flag = true;
			else
				throw new ShoppingException("invalid customer");
		}
		catch(Exception e)
		{
			throw new ShoppingException(e.getMessage());
		}
		return flag;
	} 
	@Override
	public HashMap<LocalDate,Product> purchaseProduct(int prodId, int custId)
			throws ShoppingException {
		// TODO Auto-generated method stub
		HashMap<LocalDate,Product>map = new HashMap<LocalDate,Product>();
		Product prod = getProduct(prodId);
		Customer cust = getCustomer(custId);
		String sql = "INSERT INTO purchaseDetail VALUES(pSeq_id.nextval,?,?,SYSDATE)";
		
		if(prod!=null && cust!=null)
		{
			try
			{
				PreparedStatement stmt = con.prepareStatement(sql);
				stmt.setInt(1, prod.getProdId());
				stmt.setInt(2, cust.getCustId());
				
				int row = stmt.executeUpdate();
				
				if(row>0)
				{
					map.put(LocalDate.now(),prod);
				}
				else
					throw new ShoppingException("Sorry");
			}
			catch(Exception e)
			{
				throw new ShoppingException(e.getMessage());
			}
		}
		return map;
	}
	public Product getProduct(int prodId)throws ShoppingException
	{
		Product bean = null;
		String sql = "SELECT * FROM Product WHERE prodId=?";
		try
		{
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, prodId);
			ResultSet result = stmt.executeQuery();
			if(result.next())
			{
				bean = new Product();
				bean.setProdId(result.getInt(1));
				bean.setProdName(result.getString(2));
				bean.setProdPrice(result.getInt(3));
			}
			else
				throw new ShoppingException("Invalid prodId "+prodId);
		}
		catch(Exception e)
		{
			throw new ShoppingException(e.getMessage());
		}
		return bean;
	}
	public Customer getCustomer(int custId)throws ShoppingException
	{
		Customer bean = null;
		String sql = "SELECT custName FROM Customer WHERE custId=?";
		try
		{
			PreparedStatement stmt =con.prepareStatement(sql);
			stmt.setInt(1,custId);
			ResultSet result = stmt.executeQuery();
			if(result.next())
			{
				bean = new Customer();
				bean.setCustId(custId);
				bean.setCustName(result.getString(1));
			}
		}
		catch(Exception e)
		{
			throw new ShoppingException(e.getMessage());
		}
		return bean;
	}
}
