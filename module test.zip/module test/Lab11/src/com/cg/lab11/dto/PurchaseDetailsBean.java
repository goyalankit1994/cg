package com.cg.lab11.dto;

//import java.util.Date;
import java.sql.Date;

public class PurchaseDetailsBean {
	private int puchaseid;
	private String cname;
	private Date purchaseDate;
	private String mobilenumber;
	private String mailid;
	private int mobileid;
	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public int getPuchaseid() {
		return puchaseid;
	}
	
	public void setPuchaseid(int puchaseid) {
		this.puchaseid = puchaseid;
	}
	
	public String getCname() {
		return cname;
	}
	
	public void setCname(String cname) {
		this.cname = cname;
	}
	
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	@Override
	public String toString() {
		return "PurchaseDetailsBean [puchaseid=" + puchaseid + ", cname="
				+ cname + ", purchaseDate=" + purchaseDate + ", mobilenumber="
				+ mobilenumber + ", mailid=" + mailid + ", mobileid="
				+ mobileid + "]";
	}

	
	
	
	
	
	
}
