package com.cg.jdbccollection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;
public class DisplayUsingCollection {

	static Properties prop = new Properties();
	static String driver;
	static String user;
	static String pass;
	static String url;
	static
	{
		try
		{
			prop.load(new FileInputStream("jdbc.property"));
			driver = prop.getProperty("driver");
			pass = prop.getProperty("pass");
			user = prop.getProperty("user");
			url = prop.getProperty("url");
			}
			catch(FileNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	public static void connect()
	{
		try
		{
			try
			{
				Class.forName(driver);
			}
			catch(ClassNotFoundException e)
			{
				System.out.println(e.getMessage());
				}
			Connection con = DriverManager.getConnection(url,user,pass);
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	public static void displayUsingCollections()
	{
		ArrayList<Employee> ar = new ArrayList<Employee>();
		try
		{
		Connection con =DriverManager.getConnection(url,user,pass);
		Statement st = con.createStatement();
		String sql = "SELECT * FROM emp";
		ResultSet rs =  st.executeQuery(sql);
		while(rs.next())
		{
			Employee emp1 = new Employee(rs.getInt(1),rs.getString(2));
			ar.add(emp1);
		}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		System.out.println(ar);
	}
	public static void main(String[] args) {
		
	connect();
	displayUsingCollections();

	}

}

