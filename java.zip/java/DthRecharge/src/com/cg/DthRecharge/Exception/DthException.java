package com.cg.DthRecharge.Exception;

public class DthException extends Exception{
	String message;
	public DthException(String message)
	{
		this.message=message;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}

	}
