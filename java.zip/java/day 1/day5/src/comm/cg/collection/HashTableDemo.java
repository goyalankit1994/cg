package comm.cg.collection;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class HashTableDemo {

	public static void main(String[] args) {
	Hashtable<String ,Integer> set = new Hashtable<String,Integer>();
	set.put("abc",1);
	set.put("xyz",3);
	set.put("def", 4);
	System.out.println(set);
	Set keys = set.keySet();
	Iterator keyref = keys.iterator();
	while (keyref.hasNext())
	{
		String key = (String)keyref.next();
		int val = (int) set.get(key);
		System.out.println("key =" + key + " & " + " value ="+ val);
	}
		}

	}


