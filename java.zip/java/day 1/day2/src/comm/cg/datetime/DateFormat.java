package comm.cg.datetime;
import java.time.*;
import java.time.format.*;
import java.util.Scanner;
public class DateFormat {

	public static void main(String[] args) {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc  = new Scanner(System.in);
		System.out.println("Enter Date ::");
		String input = sc.next();
		LocalDate date = LocalDate.parse(input,format);
				System.out.println(date);
		// TODO Auto-generated method stub

	}

}
