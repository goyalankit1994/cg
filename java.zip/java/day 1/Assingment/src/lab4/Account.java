package lab4;

public class Account extends Person 
{
	int accno; 
	double balance;
	Person accholder ;
	Account()
	{
		
	}
	Account(Person accholder , double balance)
	{
		this.accno =(int) Math.floor(Math.random() *1000000) ; 
		this.accholder=accholder;
		this.balance=balance;
	}
	@Override
	public String toString() {
		return "Account [accno=" + accno + ", balance=" + balance
				+ ", accholder=" + accholder + "]";
	}
	public double getAccno() {
		return accno;
	}
	public Person getAccholder() {
		return accholder;
	}
	public void setAccholder(Person accholder) {
		this.accholder = accholder;
	}
	public void setAccno(long accno) {
		this.accno =(int) accno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	 public void Deposit(double Amount)
	 {
		this.balance=this.balance+ Amount; 
	 }
	 public  void withdraw(double Amount)
	 {
		 if(Amount<(this.balance-500))
				this.balance=this.balance-Amount;
			else
				System.out.println("Not enough balance");
	 }

}
