package com.capgemini.util;

/**
 * This Class includes the error messages
 * @author Dushyant
 * @version 1.1
 * The FILE_CANNOT_CHANGED has been added
 */

public class Messages {

	public static final String DB_CONN_ERROR = "Error connecting to Database";
	public static final String CLASS_NOT_FOUND_ERROR = "Class Driver cannot be loaded";
	public static final String FILE_NOT_FOUND_ERROR = "File Not Found ";
	public static final String FILE_CANNOT_READ_ERROR = "Could not access file";
	public static final String FILE_CANNOT_CHANGE = "Could not be changed";
}
