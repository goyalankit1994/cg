package com.cg.lab11.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
//import java.util.Date;

import javax.sql.RowSet;
import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;
import java.sql.Date;
import com.cg.lab11.dbutil.DBUtil;
import com.cg.lab11.dto.MobileAppBean;
import com.cg.lab11.dto.PurchaseDetailsBean;
import com.cg.lab11.exception.PurchaseOrderException;



public class MobileDaoImpl implements MobileAppDao{
Connection con;
	
	public MobileDaoImpl() {
		// TODO Auto-generated constructor stub
		con=DBUtil.getConnection();
	}

	@Override
	public boolean purchaseMobile(PurchaseDetailsBean bean) throws PurchaseOrderException {
		// TODO Auto-generated method stub
		
		String sql="INSERT INTO purchasedetails VALUES(purchase_id_seq.nextval,?,?,?,?,?)";
		try{
			PreparedStatement pstmt=con.prepareStatement(sql);
//			pstmt.setInt(1, bean.getPuchaseid());
			pstmt.setString(1, bean.getCname());
			pstmt.setString(2, bean.getMailid());
			pstmt.setString(3, bean.getMobilenumber());
			pstmt.setDate(4,bean.getPurchaseDate());
			pstmt.setInt(5, bean.getMobileid());
			int row =pstmt.executeUpdate();
			if(row!=0){
				System.out.println(row+ " Inserted ");
				return true;
			}
			else
				throw new PurchaseOrderException("Not Inserted ");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateMobileDb(PurchaseDetailsBean bean) throws PurchaseOrderException {
		// TODO Auto-generated method stub
		try
		{
			String sql="UPDATE MOBILES SET QUANTITY=QUANTITY-1 WHERE MOBILEID=?";
			PreparedStatement pstmt= con.prepareStatement(sql);
			pstmt.setInt(1, bean.getMobileid());
			int row=pstmt.executeUpdate();
			if(row==0)
				throw new PurchaseOrderException("Updation Problem");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean searchMobile(int min, int max) throws PurchaseOrderException {
		// TODO Auto-generated method stub
		try{
			String sql="SELECT * FROM MOBILES WHERE PRICE BETWEEN ? AND ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, min);
			pstmt.setInt(2, max);
			ResultSet rs= pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println("Mobile Id= "+rs.getInt(1)+"\t NAME = "+rs.getString(2)+"\tPRICE = "+rs.getInt(3)+"\t Quantity = "+rs.getString(4));
			}
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public ArrayList<MobileAppBean> getAllMobileRecords()
			throws PurchaseOrderException
	{
		ArrayList<MobileAppBean> list = null;
		
		try
		{
			String sql="SELECT * FROM mobiles";
			Statement stmt= con.createStatement();
			ResultSet result= stmt.executeQuery(sql);
			list = new ArrayList<MobileAppBean>();
			while(result.next())
			{
				MobileAppBean bean = new MobileAppBean();
				bean.setMoibleid(result.getInt(1));
				bean.setName(result.getString(2));
				bean.setPrice(result.getInt(3));
				bean.setQuantity(result.getString(4));
				
				list.add(bean);
			
			}
			if(list.size()==0)
				throw new PurchaseOrderException("NO RECORD FOUND");
		}
		catch( PurchaseOrderException e )
		{
			System.out.println(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public boolean deleteMobile(int mobileId) throws PurchaseOrderException {
		// TODO Auto-generated method stub
		try
		{
			String sql="DELETE MOBILES WHERE MOBILEID=? ";
			PreparedStatement pstmt= con.prepareStatement(sql);
			pstmt.setInt(1, mobileId);
			int row=pstmt.executeUpdate();
			if(row!=0)
				return true;
			else
				throw new PurchaseOrderException("DATA NOT PRESENT ");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
}
