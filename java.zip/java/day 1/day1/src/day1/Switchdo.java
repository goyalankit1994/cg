package day1;
import java . util. Scanner;
public class Switchdo {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int choice=0;
		int num1=6,num2=3,result=0;
		do
		{
			System.out.println("1-add");
			System.out.println("1-sub");
			System.out.println("1-multiply");
			System.out.println("enter your choice");
			choice=sc.nextInt();
		switch(choice)
		{
		case 1:  result= num1+num2;
		System.out.println("result is = " +result);
		break;
		case 2:  result= num1-num2;
		System.out.println("result is = " +result);
		break;
		case 3:  result= num1*num2;
		System.out.println("result is = " +result);
		break;
		default:System.out.println("wrong choice");
		}
		System.out.println("do you want to continue 1-yes 0-no");
		choice=sc.nextInt();
		}while(choice!=0);
	}

}
