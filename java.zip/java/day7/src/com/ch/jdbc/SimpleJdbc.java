package com.ch.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class SimpleJdbc {
	static Properties prop = new Properties();
	static String driver;
	static String user;
	static String pass;
	static String url;
	static
	{
		try{
		prop.load(new FileInputStream("jdbc.property"));
		driver = prop.getProperty("driver");
		pass = prop.getProperty("pass");
		user = prop.getProperty("user");
		url = prop.getProperty("url");
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	

	public static void main(String[] args) {
		try
		{
			Class.forName(driver);
			Connection con =DriverManager.getConnection(url,user,pass);
			Statement stmt = con.createStatement();
			String sql = "SELECT * FROM emp";
			ResultSet result =  stmt.executeQuery(sql);
			while(result.next())
			{
				System.out.println(result.getInt(1));
				System.out.println(result.getString(2));
				
			}
		}
catch(SQLException|ClassNotFoundException e)
		{
		e.printStackTrace();
		}
	}

}
