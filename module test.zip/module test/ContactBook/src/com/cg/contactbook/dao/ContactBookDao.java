package com.cg.contactbook.dao;

import java.sql.SQLException;

import com.cg.contactbook.dto.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;

public interface ContactBookDao 
{
	public void addEnquiry(EnquiryBean enqry)throws ContactBookException,SQLException;
	public EnquiryBean getEnquiryDetails(int Enquiryid)throws ContactBookException;
}
