package com.capgemini.ams.DButil;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class DBUtil {
	static Properties prop = new Properties();
	static String driver;
	static String url;
	static String user;
	static String password;
	static Connection con;
	static Logger logger = Logger.getLogger(DBUtil.class);

	static 
	{

		try
		{
			prop.load(new FileInputStream("jdbc.properties"));
			
			driver=prop.getProperty("driver");
			user=prop.getProperty("username");
			url=prop.getProperty("url");
			password=prop.getProperty("password");
			
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,password);
			
			logger.info("Database connection established");
		}
		catch(Exception e)
		{
			logger.error("Database connection can not be established");
			System.out.println(e.getMessage());
		}
		
	}
	public static Connection getConnection()
	{
		return con;
	}
}
