package lab3;

import java.util.Scanner;

public class PositiveString {
	String str;
	Boolean isPositiveString(String str)
	{
		
		for(int i=1;i<str.length();i++)
			
			if(str.substring(i-1,i).compareToIgnoreCase(str.substring(i,i+1))>0)
				return false;
	
		return true;
}
	public static void main(String[] args) {
		boolean value;
		PositiveString obj = new PositiveString();
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter String :");
		String str = input.nextLine();
		
		value = obj.isPositiveString(str);
		System.out.println("Is String provided positive :" + value);

	}

}
