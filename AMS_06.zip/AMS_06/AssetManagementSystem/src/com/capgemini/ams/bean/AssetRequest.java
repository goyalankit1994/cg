package com.capgemini.ams.bean;

public class AssetRequest {
	
	private int requestId;
	private int assetId;		//Referred from Asset bean
	private String assetName;	//Referred from Asset bean
	private int mgrCode;		//Referred from Employee bean
	private String assetDesc;
	private int assetQuantity;
	private String status;
	private int empNum; 
	
	public AssetRequest() {
		super();
	}
	
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public int getAssetId() {
		return assetId;
	}
	public int getEmpNum() {
		return empNum;
	}

	public void setEmpNum(int empNum) {
		this.empNum = empNum;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public int getMgrCode() {
		return mgrCode;
	}
	public void setMgrCode(int mgrCode) {
		this.mgrCode = mgrCode;
	}
	public String getAssetDesc() {
		return assetDesc;
	}
	public void setAssetDesc(String assetDesc) {
		this.assetDesc = assetDesc;
	}
	public int getAssetQuantity() {
		return assetQuantity;
	}
	public void setAssetQuantity(int assetQuantity) {
		this.assetQuantity = assetQuantity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
