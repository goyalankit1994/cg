package com.cg.contactbook.service;

import java.sql.SQLException;
import java.util.regex.Pattern;

import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.dto.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao contDao = new ContactBookDaoImpl();
	
	
	@Override
	public void addEnquiry(EnquiryBean enqry) throws ContactBookException,
			SQLException {
		// TODO Auto-generated method stub
		contDao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int Enquiryid)
			throws ContactBookException {
		// TODO Auto-generated method stub
		return contDao.getEnquiryDetails(Enquiryid);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		// TODO Auto-generated method stub
		
		String fname = enqry.getFname();
		String lname = enqry.getLname();
		String phone = enqry.getContactno();
		String pLoc = enqry.getpLocation();
		String pDom = enqry.getpDomain();
		try
		{
			validateFirstName(fname);
			validateLastName(lname);
			validateContactNo(phone);
			validatePLocation(pLoc);
			validatePDomain(pDom);
		}
		catch(ContactBookException e)
		{
			System.out.println(e.getMessage());
			return false;
		}
		return true;
	}
	
	public boolean validateContactNo(String contactNo)throws ContactBookException
	{
		String pattPhone="[0-9]{10}";
		boolean msg =Pattern.matches(pattPhone,contactNo);
		if(!msg)
		{
			throw new ContactBookException("Phone no should contain 10 digits only");
		}
		return true;
	}
	
	public boolean validateFirstName(String fName)throws ContactBookException
	{
		String pattFName="[A-Z][a-z]{2,20}";
		boolean msg =Pattern.matches(pattFName,fName);
		if(!msg)
		{
			throw new ContactBookException("Enter first name properly");
		}
		return true;
	}
	
	public boolean validateLastName(String lName)throws ContactBookException
	{
		String pattLName="[A-Z][a-z]{2,20}";
		boolean msg =Pattern.matches(pattLName,lName);
		if(!msg)
		{
			throw new ContactBookException("Enter last name properly");
		}
		return true;
	}
	
	public boolean validatePLocation(String pLocation)throws ContactBookException
	{
		String pattLoc="[A-Z][a-z]{2,20}";
		boolean msg =Pattern.matches(pattLoc,pLocation);
		if(!msg)
		{
			throw new ContactBookException("Enter location properly");
		}
		return true;
	}
	
	public boolean validatePDomain(String pDomain)throws ContactBookException
	{
		String pattDom="[A-Z][a-z]{2,20}";
		boolean msg =Pattern.matches(pattDom,pDomain);
		if(!msg)
		{
			throw new ContactBookException("Enter domain properly");
		}
		return true;
	}

}
