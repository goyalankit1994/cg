package com.cg.lab11.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.lab11.dao.MobileAppDao;
import com.cg.lab11.dao.MobileDaoImpl;
import com.cg.lab11.exception.PurchaseOrderException;
import com.cg.lab11.service.MobileAppService;
import com.cg.lab11.service.MobileAppServiceImpl;

public class MobileJunitTest {
	
	MobileAppDao dao;
	MobileAppService service;
	@Before
	public void init()
	{
		dao= new MobileDaoImpl();
		service = new MobileAppServiceImpl();
		service.setDao(dao);
		
	}
	@Test
	public void testPurchaseMobile() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchMobile() throws PurchaseOrderException {
		assertNotEquals(false   , service.searchMobile(14000, 40000));
	}
	@After
	public void destroy()
	{
		service=null;
		dao=null;
	}

}
