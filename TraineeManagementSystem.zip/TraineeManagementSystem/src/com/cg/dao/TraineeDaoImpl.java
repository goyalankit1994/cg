


package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.bean.TraineeBean;
import com.cg.exception.TraineeException;

@Repository
public class TraineeDaoImpl implements TraineeDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public TraineeBean addTraineeDetails(TraineeBean bean)throws TraineeException {
		entityManager.persist(bean);
		entityManager.flush();
		System.out.println("in dao"+bean);
		
			
	
		return bean;
	}

	@Override
	public boolean removeTrainee(int id) throws TraineeException {
		
		TraineeBean traineeTemp = entityManager.find(TraineeBean.class, id);
		entityManager.remove(traineeTemp);
		entityManager.flush();
		System.out.println("removed trainee with "+id);
		
		return true;
	}

	@Override
	public TraineeBean getDetails(int id) throws TraineeException {
	TraineeBean bean = new TraineeBean();
	bean=entityManager.find(TraineeBean.class, id);
	System.out.println("getdetails"+bean);
	
		return bean;
	}

	@Override
	public ArrayList<TraineeBean> getallTraineeDetails()throws TraineeException {
		String sql="select t from TraineeBean t";
		Query qry=entityManager.createQuery( sql);
		ArrayList<TraineeBean> list=(ArrayList<TraineeBean>) qry.getResultList();
		
		System.out.println(list);
		return list;
	}

	@Override
	public boolean modifyTrainee(int id, TraineeBean trainee)
			throws TraineeException {
		entityManager.merge(trainee);
		return true;
	}

	

}
