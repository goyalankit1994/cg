package com.cg.onlineshopping.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.onlineshopping.bean.Customer;
import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.bean.Purchase;
import com.cg.onlineshopping.exception.ShoppingException;

public interface ShoppingService {

	ArrayList<Product>getProducts(Customer bean)throws ShoppingException;
	HashMap<LocalDate,Product> purchaseProduct(int prodId,int custId)throws ShoppingException;
	
}
