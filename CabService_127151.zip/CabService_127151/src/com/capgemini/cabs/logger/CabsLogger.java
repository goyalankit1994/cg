package com.capgemini.cabs.logger;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.HTMLLayout;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;




public class CabsLogger {
	
static Logger logger=Logger.getLogger(CabsLogger.class);
	
	static
	{
		Layout  layout=new HTMLLayout();
		Appender appender=null;
		try{
			appender=new FileAppender(layout, "log.html");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		logger.addAppender(appender);
	}
	

	public static Logger getLoggerInstance()
	{
		return logger;
	}

}
