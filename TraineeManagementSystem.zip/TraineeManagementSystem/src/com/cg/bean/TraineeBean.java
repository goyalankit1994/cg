package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
@Entity
@Table(name="trainee")
@Component
public class TraineeBean {
	@Id
	@SequenceGenerator(name="seq1",sequenceName="ID_SEQUENCE",allocationSize=10)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")
	@Column(name="id",length=20)
	private int id;
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-Z]{1}[a-z]{2,20}", message="First word should be capital and minimum three words is required")
	@Column(name="name",length=20)
	private String name;
	@NotEmpty(message="domain cannot be left empty")
	@Column(name="domain")
	private String domain;
	@NotEmpty(message="please provide your current location") 
	@Column(name="location",length=20)
	private String location;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "TraineeBean [id=" + id + ", name=" + name + ", domain="
				+ domain + ", location=" + location + "]";
	}
	

}
