package com.capgemini.cab.exception;

public class CabException extends Exception {
	String message;
	public CabException(String message)
	{
		this.message=message;
	}
	
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}
}
	


