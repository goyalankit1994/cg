package com.capgemini.util;

public interface URLMapper {

	String SHOW_CONSUMER_LIST = "views/Show_Consumer_List.jsp";
	String SEARCH_CONSUMER = "/views/Search_Consumer.jsp";
	String SHOW_CONSUMER = "views/Show_Consumer.jsp";
	String SHOW_BILL = "/views/Show_Bill.jsp";
	String GENERATE_NEXT_BILL = "/views/generateNextBill.jsp";
	String BILL_GENERATED = "/views/billGenerated.jsp";

}
