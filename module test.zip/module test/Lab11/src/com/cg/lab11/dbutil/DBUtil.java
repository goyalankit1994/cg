package com.cg.lab11.dbutil;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBUtil {
	static Properties prop = new Properties();
	static String driver;
	static String url;
	static String user;
	static String password;
	static Connection con;
	static 
	{
		
		
		try
		{
			prop.load(new FileInputStream("jdbc.properties"));
			driver=prop.getProperty("driver");
			user=prop.getProperty("username");
			url=prop.getProperty("url");
			password=prop.getProperty("password");
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,password);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static Connection getConnection()
	{
		return con;
	}
}
