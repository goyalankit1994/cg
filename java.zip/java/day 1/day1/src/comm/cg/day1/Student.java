package comm.cg.day1;

public class Student {
	int sid;
	String sname;
	public Student()
	{
		sid = 1;
		sname = "ankit";
	}
	//parameterised constructor
	public Student(int id,String name)
	{
		sid =id;
		sname = name;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	

}
