package com.cg.transportdetails.dto;

import java.time.LocalDate;

public class BookingBean {

	private int bookingId;
	private String custId;
	private long custMobile;
	private int truckId;
	private int noOfTruck;
	private LocalDate dateOfTransport;
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public long getCustMobile() {
		return custMobile;
	}
	public void setCustMobile(long custMobile) {
		this.custMobile = custMobile;
	}
	public int getTruckId() {
		return truckId;
	}
	public void setTruckId(int truckId) {
		this.truckId = truckId;
	}
	public int getNoOfTruck() {
		return noOfTruck;
	}
	public void setNoOfTruck(int noOfTruck) {
		this.noOfTruck = noOfTruck;
	}
	public LocalDate geDateOfTransport() {
		return dateOfTransport;
	}
	public void setDateOfTransport( LocalDate dateOfTransport) {
		this.dateOfTransport = dateOfTransport;
	}
	@Override
	public String toString() {
		return "BookingBean [bookingId=" + bookingId + ", custId=" + custId
				+ ", custMobile=" + custMobile + ", truckId=" + truckId
				+ ", noOfTruck=" + noOfTruck + ", LocalDatedateOfTransport="
				+ dateOfTransport + "]";
	}
	
}
