package comm.cg.interfaces;

public interface Service {
	int add(int x, int y);
	int var =20;
	int sub(int x,int y);
	// new method in java 8
	default void method()
	{
		System.out.println("default method");
	}
	static void fun()
	{
		System.out.println("static method");
	}

}
