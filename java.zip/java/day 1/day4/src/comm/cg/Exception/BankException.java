package comm.cg.Exception;

public class BankException extends Exception 
{
	String message;
	public BankException(String msg)
	{
		this.message=msg;
	}
public String getMessage()
{
	return message;
}
}
