package com.cg.contactbook.pl;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.contactbook.dto.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.service.ContactBookService;
import com.cg.contactbook.service.ContactBookServiceImpl;

public class Client 
{
	public static void main(String[] args)
	{
		boolean flag;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner (System.in);
		ContactBookService contSer = new ContactBookServiceImpl();
		System.out.println("Global Recruitment");
		
		int choice;
		
		do{
			printOptions();   //display menu
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				//accepts all details
				EnquiryBean enqry = new EnquiryBean();
				
				System.out.println("Enter your first name");
				String fname = sc.next();
				
				System.out.println("Enter your last name");
				String lname = sc.next();
				
				System.out.println("Enter your contact number");
				String phoneNo = sc.next();
				
				System.out.println("Enter your domain");
				String domain = sc.next();
				
				System.out.println("Enter your city");
				String city = sc.next();
				
				enqry.setFname(fname);
				enqry.setLname(lname);
				enqry.setContactno(phoneNo);
				enqry.setpDomain(domain);
				enqry.setpLocation(city);
				try{
				flag = contSer.isValidEnquiry(enqry);
				if(flag)
				{
					
						contSer.addEnquiry(enqry);
				}
				}	catch(SQLException | ContactBookException e)
					{
						System.out.println(e.getMessage());
					}
				
				
				break;
				
			case 2:
				//search details
				int id;
				System.out.println("Enter an id to search");
				id=sc.nextInt();
				try{
				EnquiryBean empDetail=contSer.getEnquiryDetails(id);
				if(empDetail==null)
				{
					System.out.println("sorry no details found \n");
				}
				else
				{
					System.out.println("First Name"+empDetail.getFname());
					System.out.println("Last Name"+empDetail.getLname());
					System.out.println("Phone No"+empDetail.getContactno());
					System.out.println("Domain"+empDetail.getpDomain());
					System.out.println("City"+empDetail.getpLocation());
				}
				
				}catch(ContactBookException e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
			case 0:
				System.out.println("Thank you for selecting us");
				System.exit(0);
				break;
			}
		}while(choice!=0);
	}
	
	public static void printOptions()
	{
		System.out.println("1.Enter Enquiry Details");
		System.out.println("2.View Enquiry Details on id");
		System.out.println("0.Exit");
		System.out.println("***************");
	}
}
