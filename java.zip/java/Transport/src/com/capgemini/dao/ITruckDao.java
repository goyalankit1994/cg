/**
 * 
 */
package com.capgemini.dao;

import java.util.List;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TruckBean;

/**
 * @author angoyal
 *
 */
public interface ITruckDao {
	List<TruckBean> retrieveTruckDetails() throws BookingException;
	int bookTrucks(BookingBean bookingBean) throws BookingException;
	public void closeconn() throws BookingException;

}
