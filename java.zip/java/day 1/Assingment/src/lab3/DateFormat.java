package lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateFormat {

	public static void main(String[] args) {
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc  = new Scanner(System.in);
		System.out.println("Enter Date ::");
		String date1 = sc.next();
		LocalDate date= LocalDate.parse(date1,format);
		System.out.println("date 1 is :"+date);
		LocalDate today =LocalDate.now(); 
		System.out.println("date is "+today);
		 Period diff = date.until(today); 
		 System.out.println("diff in date are " +diff.getDays()+ "days" +diff.getMonths() +"months"+diff.getYears()+"years");
	}

}
