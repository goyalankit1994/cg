import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.FinanceException;

/**
 * 
 */

/**
 * @author Dushyant
 * JUnit to test ApplyLoan() method in DAO Layer
 */
public class ApplyLoanTest {

	Loan loan;
	ILoanDao loadDao;
	
	@Before
	public void setUp() throws Exception {
		
		//Valid Input
		//loan = new Loan(12000,10001,12);
		
		//invalid Input
		loan = new Loan();
		
		loadDao = new LoanDao();
	}

	@Test
	public void test() throws FinanceException {
		long id = loadDao.applyLoan(loan);
		if ( id != 0){
			assertTrue(true);
		}
		else {
			assertTrue(false);
		}
	}

}
