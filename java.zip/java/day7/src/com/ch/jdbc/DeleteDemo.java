package com.ch.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class DeleteDemo {

	public static void main(String[] args) {
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "system";
		String pass = "sys";
		Connection con =DriverManager.getConnection(url,user,pass);
		String sql = "DELETE FROM Emp WHERE id=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1,101);
		int row = pstmt.executeUpdate();
		if(row>0)
		{
			System.out.println("no of row deleted  are "+row);
		}
			
		
		//ResultSet result =  stmt.executeQuery(sql);
}
	catch(Exception e)
	{
	e.printStackTrace();
	}

}
}
	
