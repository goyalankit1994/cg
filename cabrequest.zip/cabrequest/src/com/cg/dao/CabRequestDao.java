package com.cg.dao;

import com.cg.bean.CabRequest;
import com.cg.exception.CabException;

public interface CabRequestDao {
	
	public CabRequest addCabRequestDetails(CabRequest cabRequest) throws CabException;
	public CabRequest getRequestDetails(int requestId) throws CabException;
	public int getRequestId(CabRequest cabs) throws CabException ; 
	
	

}
